using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.DataFile;

public class DataFile<T>
    : FileWrapper
    where T : class
{
    private T value;

    public DataFile(IFile file, DataFileNodeType<T> nodeType)
        : this(file, null, nodeType)
    {
    }

    public DataFile(IFile file, T value, DataFileNodeType<T> nodeType)
        : base(file)
    {
        File = file;
        this.value = value;
        NodeType = nodeType;

        if (nodeType.AutoLoad) Load();

        if (NodeType.AutoLoad) File.Activity += File_Activity;
    }

    public virtual T Value
    {
        get
        {
            using (GetAutoLock().Lock())
            {
                return value;
            }
        }
        set
        {
            using (GetAutoLock().Lock())
            {
                this.value = value;
            }
        }
    }

    public new DataFileNodeType<T> NodeType { get; }

    public virtual IFile File { get; set; }

    public virtual T GetValue(DataFileLoadFlags loadFlags)
    {
        if (loadFlags == DataFileLoadFlags.Refresh)
        {
            Load();

            return Value;
        }

        if (loadFlags == DataFileLoadFlags.RefreshIfNull)
        {
            if (Value == null) Load();

            return Value;
        }

        return Value;
    }

    public override INode? Refresh()
    {
        base.Refresh();

        Load();

        return this;
    }

    private void File_Activity(object sender, NodeActivityEventArgs eventArgs)
    {
        if (!NodeType.AutoLoad) return;

        if (eventArgs.Activity == FileSystemActivity.Changed)
        {
            using (GetAutoLock().Lock())
            {
                Load();
            }
        }
        else if (eventArgs.Activity == FileSystemActivity.Created)
        {
            using (GetAutoLock().Lock())
            {
                Load();
            }

            ;
        }
        else if (eventArgs.Activity == FileSystemActivity.Deleted)
        {
            using (GetAutoLock().Lock())
            {
                value = null;
            }
        }
        else if (eventArgs.Activity == FileSystemActivity.Renamed)
        {
            using (GetAutoLock().Lock())
            {
                value = null;
            }
        }
    }

    public virtual void Save()
    {
        using (GetAutoLock().Lock())
        {
            ActionUtils.ToRetryAction<object>
            (
                delegate { NodeType.Save(this); },
                NodeType.RetryTimeout,
                e => e is IOException
            )(null);
        }
    }

    public virtual void Load()
    {
        if (!Attributes.Exists)
            value = null;
        else
            ActionUtils.ToRetryAction<object>
            (
                delegate
                {
                    using (GetAutoLock().Lock())
                    {
                        try
                        {
                            value = NodeType.Load(this);
                        }
                        catch (NodeNotFoundException)
                        {
                            Attributes.Refresh();

                            if (!Attributes.Exists)
                            {
                                value = null;
                            }
                        }
                    }
                },
                NodeType.RetryTimeout,
                e => e is IOException
            )(null);
    }
}