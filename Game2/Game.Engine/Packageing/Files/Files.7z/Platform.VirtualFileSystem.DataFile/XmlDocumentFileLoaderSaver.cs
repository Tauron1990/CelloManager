using System.Xml;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.DataFile;

public class XmlDocumentFileLoaderSaver
    : IDataFileLoaderSaver<XmlDocument>
{
    public static XmlDocumentFileLoaderSaver Instance { get; } = new();

    public virtual XmlDocument Load(DataFile<XmlDocument> dataFile)
    {
        using (var reader = dataFile.File.GetContent().GetReader(FileShare.Read))
        {
            var document = new XmlDocument();

            document.Load(reader);

            return document;
        }
    }

    public virtual void Save(DataFile<XmlDocument> dataFile)
    {
        using (var writer = dataFile.File.GetContent().GetWriter(FileShare.None))
        {
            dataFile.Value.Save(writer);
        }
    }
}