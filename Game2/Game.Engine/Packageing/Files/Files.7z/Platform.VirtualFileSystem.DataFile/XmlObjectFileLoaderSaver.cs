using Platform.Xml.Serialization;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.DataFile;

public class XmlObjectDataFileLoaderSaver<T>
    : IDataFileLoaderSaver<T>
    where T : class, new()
{
    public XmlObjectDataFileLoaderSaver()
        : this(XmlSerializer<T>.New())
    {
    }

    public XmlObjectDataFileLoaderSaver(XmlSerializer<T> serializer)
        : this(serializer, serializer)
    {
    }

    public XmlObjectDataFileLoaderSaver(XmlSerializer<T> serializer, XmlSerializer<T> deserializer)
    {
        Serializer = serializer;
        Deserializer = deserializer;
    }

    public virtual XmlSerializer<T> Deserializer { get; set; }
    public virtual XmlSerializer<T> Serializer { get; set; }

    public virtual T Load(DataFile<T> dataFile)
    {
        const int retrycount = 10;

        for (var i = 0; i < retrycount; i++)
        {
            try
            {
                using (var reader = dataFile.File.GetContent().GetReader())
                {
                    var retval = Deserializer.Deserialize(reader);

                    if (retval is IObjectWithGeneratedDefaults)
                        if (((IObjectWithGeneratedDefaults)retval).RequiresGeneratedDefaults)
                        {
                            ((IObjectWithGeneratedDefaults)retval).GenerateDefaults();

                            Save(dataFile, retval);
                        }

                    return retval;
                }
            }
            catch (Exception)
            {
                if (i == retrycount - 1) throw;
            }

            Thread.Sleep(500);
        }

        throw new InvalidOperationException();
    }

    public virtual void Save(DataFile<T> dataFile)
    {
        if (!dataFile.ParentDirectory.Exists) dataFile.ParentDirectory.Create(true);

        using (var writer = dataFile.File.GetContent().GetWriter())
        {
            Serializer.Serialize(dataFile.Value, writer);
        }
    }

    protected virtual void Save(DataFile<T> dataFile, T value)
    {
        using (var writer = dataFile.File.GetContent().GetWriter())
        {
            Serializer.Serialize(value, writer);
        }
    }
}