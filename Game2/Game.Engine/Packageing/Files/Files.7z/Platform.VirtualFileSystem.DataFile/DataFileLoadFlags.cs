namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.DataFile;

public enum DataFileLoadFlags
{
    None,
    RefreshIfNull,
    Refresh
}