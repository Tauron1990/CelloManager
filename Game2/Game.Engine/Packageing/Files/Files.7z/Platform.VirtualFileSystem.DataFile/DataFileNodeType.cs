namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.DataFile;

public class DataFileNodeType<T>
    : NodeType
    where T : class
{
    public DataFileNodeType(IDataFileLoaderSaver<T> loaderSaver)
        : this(loaderSaver, false, null as NodeType)
    {
    }

    public DataFileNodeType(IDataFileLoaderSaver<T> loaderSaver, NodeType innerNodeType)
        : this(loaderSaver, false, innerNodeType)
    {
    }

    public DataFileNodeType(IDataFileLoaderSaver<T> loaderSaver, bool autoLoad)
        : this(loaderSaver, autoLoad, null as NodeType)
    {
    }

    public DataFileNodeType(IDataFileLoaderSaver<T> loaderSaver, bool autoLoad, NodeType innerNodeType)
        : this(loaderSaver, autoLoad, TimeSpan.FromSeconds(10), innerNodeType)
    {
    }

    public DataFileNodeType(IDataFileLoaderSaver<T> loaderSaver, bool autoLoad, TimeSpan retryTimeOut)
        : this(loaderSaver.Load, loaderSaver.Save, autoLoad, retryTimeOut, null as NodeType)
    {
    }

    public DataFileNodeType(IDataFileLoaderSaver<T> loaderSaver, bool autoLoad, TimeSpan retryTimeOut, NodeType innerNodeType)
        : this(loaderSaver.Load, loaderSaver.Save, autoLoad, retryTimeOut, innerNodeType)
    {
    }

    public DataFileNodeType(Func<DataFile<T>, T> loader, Action<DataFile<T>> saver, bool autoLoad, TimeSpan retryTimeOut)
        : this(loader, saver, autoLoad, retryTimeOut, null as NodeType)
    {
    }

    public DataFileNodeType(Func<DataFile<T>, T> loader, Action<DataFile<T>> saver, bool autoLoad, TimeSpan retryTimeOut, NodeType innerNodeType)
        : base(innerNodeType)
    {
        Save = saver;
        Load = loader;
        AutoLoad = autoLoad;
        RetryTimeout = retryTimeOut;
    }

    public virtual Type DataType => typeof(T);

    public virtual bool AutoLoad { get; }
    public virtual TimeSpan RetryTimeout { get; set; }
    public virtual Func<DataFile<T>, T> Load { get; }
    public virtual Action<DataFile<T>> Save { get; }

    public override int GetHashCode()
    {
        return base.GetHashCode();
    }

    public override bool Equals(object obj)
    {
        if (obj == null) return false;

        if (obj == this) return true;

        return false;
    }
}