using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Network;

public class NetworkNodeAndFileAttributes
    : DictionaryBasedNodeAttributes
{
    private readonly INode node;

    private bool refresh;

    [ThreadStatic]
    private int updateContextCount;

    public NetworkNodeAndFileAttributes(INode node)
    {
        this.node = node;

        updateContextCount = 0;
    }

    public override void OnAttributeValueChanged(DictionaryBasedNodeAttributesEventArgs eventArgs)
    {
        if (eventArgs.UserSet && updateContextCount == 0) Update();

        base.OnAttributeValueChanged(eventArgs);
    }

    public override INodeAttributesUpdateContext AquireUpdateContext()
    {
        return new NetworkNodeAttributesUpdateContext(this);
    }

    private IEnumerable<Pair<string, object>> GetAttributesPairs()
    {
        foreach (var attribute in node.Attributes)
            if (!attribute.Key.Equals("exists")
                && !attribute.Key.Equals("length"))
                yield return new Pair<string, object>(attribute.Key, attribute.Value);
    }

    public override INodeAttributes Refresh()
    {
        lock (SyncLock)
        {
            refresh = true;
        }

        return this;
    }

    public override T GetValue<T>(string attributeName)
    {
        lock (SyncLock)
        {
            if (refresh)
            {
                refresh = false;

                lock (SyncLock)
                {
                    var networkFileSystem = (NetworkFileSystem)node.FileSystem;

                    Clear();

                    try
                    {
                        using (var clientContext = networkFileSystem.GetFreeClientContext())
                        {
                            foreach (var attribute in clientContext.NetworkFileSystemClient.GetAttributes(
                                         ((NetworkNodeAddress)node.Address).RemoteUri, node.NodeType))
                                SetValue(attribute.Name, attribute.Value, false);
                        }
                    }
                    catch (NodeNotFoundException)
                    {
                        // Shouldn't actually get here

                        SetValue("exists", false);
                    }
                }
            }
        }

        return base.GetValue<T>(attributeName);
    }

    public virtual void Update()
    {
        lock (SyncLock)
        {
            var networkFileSystem = (NetworkFileSystem)node.FileSystem;

            using (var clientContext = networkFileSystem.GetFreeClientContext())
            {
                clientContext.NetworkFileSystemClient.SetAttributes
                (
                    ((NetworkNodeAddress)node.Address).RemoteUri,
                    node.NodeType,
                    GetAttributesPairs()
                );
            }

            NetworkFileSystem.RaiseActivityEvent((NetworkFileSystem)node.FileSystem,
                new FileSystemActivityEventArgs(FileSystemActivity.Changed, node.NodeType, node.Name, node.Address.AbsolutePath));
        }
    }

    private sealed class NetworkNodeAttributesUpdateContext
        : INodeAttributesUpdateContext
    {
        private readonly NetworkNodeAndFileAttributes nodeAndFileAttributes;

        private bool alreadyDisposed;

        public NetworkNodeAttributesUpdateContext(NetworkNodeAndFileAttributes nodeAndFileAttributes)
        {
            this.nodeAndFileAttributes = nodeAndFileAttributes;

            Monitor.Enter(this.nodeAndFileAttributes.SyncLock);

            this.nodeAndFileAttributes.updateContextCount++;
        }

        public void Dispose()
        {
            lock (this)
            {
                if (alreadyDisposed) return;

                alreadyDisposed = true;
            }

            Monitor.Exit(nodeAndFileAttributes.SyncLock);

            alreadyDisposed = true;

            nodeAndFileAttributes.Update();
            nodeAndFileAttributes.updateContextCount--;
        }
    }
}