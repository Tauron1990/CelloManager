using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Network;

internal class NetworkFileHashingService
    : AbstractFileHashingService
{
    public NetworkFileHashingService(IFile file, FileHashingServiceType serviceType)
        : base(file, serviceType)
    {
    }

    public override HashValue ComputeHash(long offset, long length)
    {
        try
        {
            return NetworkNode.ComputeHash(OperatingNode, ServiceType.AlgorithmName, false, offset, length, null, null);
        }
        catch (NodeNotFoundException)
        {
            NetworkNodeAndFileAttributes attributes;

            attributes = OperatingNode.Attributes as NetworkNodeAndFileAttributes;

            if (attributes != null) attributes.SetValue("exists", false);

            throw;
        }
    }
}