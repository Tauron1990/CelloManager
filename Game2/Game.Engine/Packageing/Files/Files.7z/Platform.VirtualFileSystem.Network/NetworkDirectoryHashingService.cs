using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Network;

internal class NetworkDirectoryHashingService
    : AbstractDirectoryHashingService
{
    public NetworkDirectoryHashingService(IDirectory directory, DirectoryHashingServiceType serviceType)
        : base(directory, serviceType)
    {
    }

    public override HashValue ComputeHash(long offset, long length)
    {
        return NetworkNode.ComputeHash(OperatingNode, ServiceType.AlgorithmName ?? "null", ServiceType.Recursive, offset, length,
            ServiceType.IncludedFileAttributes, ServiceType.IncludedDirectoryAttributes);
    }
}