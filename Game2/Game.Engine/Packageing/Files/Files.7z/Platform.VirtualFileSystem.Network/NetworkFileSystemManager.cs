using System.Net;
using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using Platform.Collections;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Network;

public class NetworkFileSystemManager
    : AbstractFileSystemManager
{
    private readonly IDictionary<string, IFileSystem> fileSystemCache;
    private readonly IPAddress ipAddress;

    public NetworkFileSystemManager(IPAddress ipAddress)
    {
        this.ipAddress = ipAddress;
        fileSystemCache = new TimedReferenceDictionary<string, IFileSystem>(TimeSpan.FromMinutes(5));
    }

    public override INode Resolve(string uri, NodeType nodeType, AddressScope scope, FileSystemOptions? options)
    {
        bool success;
        IFileSystem fileSystem;

        var address = LayeredNodeAddress.Parse(uri);

        lock (fileSystemCache)
        {
            success = fileSystemCache.TryGetValue(address.RootUri, out fileSystem);
        }

        if (!success)
        {
            var networkUri = string.Format("netvfs://{0}[" + uri + "]/", ipAddress);

            fileSystem = FileSystemManager.GetManager().ResolveDirectory(networkUri).FileSystem;

            lock (fileSystemCache)
            {
                fileSystemCache.Add(address.RootUri, fileSystem);
            }
        }

        return fileSystem.Resolve(address.PathAndQuery);
    }
}