using System.Net;
using System.Net.Sockets;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Network.Client;

public abstract class AbstractNetworkFileSystemClient
    : INetworkFileSystemClient
{
    private readonly string hostName;

    private readonly int port;
    private Stream readStream;
    private Stream writeStream;

    protected AbstractNetworkFileSystemClient(string hostname, int port)
    {
        if (hostname == null) throw new ArgumentNullException("hostname");

        this.port = port;
        hostName = hostname;

        TcpClient = new TcpClient();
    }

    protected AbstractNetworkFileSystemClient(IPEndPoint serverEndPoint)
    {
        ServerEndPoint = serverEndPoint;

        TcpClient = new TcpClient();
    }

    protected TcpClient TcpClient { get; private set; }

    protected virtual Stream ReadStream
    {
        get => readStream;
        set => readStream = value;
    }

    protected virtual Stream WriteStream
    {
        get => writeStream;
        set => writeStream = value;
    }

    public virtual object SyncLock => this;

    public abstract void Create(string uri, NodeType nodeType, bool createParent);

    public virtual bool Connected => TcpClient.Connected;

    public virtual IPEndPoint ServerEndPoint { get; }

    public virtual void Connect()
    {
        if (Connected) throw new InvalidOperationException();

        if (ServerEndPoint != null)
            TcpClient.Connect(ServerEndPoint);
        else
            TcpClient.Connect(hostName, port);

        readStream = TcpClient.GetStream();
        writeStream = TcpClient.GetStream();
    }

    public virtual void Disconnect()
    {
        if (ReadStream != null) ReadStream.Close();

        if (WriteStream != null) WriteStream.Close();

        TcpClient.Client.Disconnect(false);

        TcpClient.Close();
    }

    public abstract void Delete(string uri, NodeType nodeType, bool recursive);

    public abstract void Move(string srcUri, string desUri, NodeType nodeType, bool overwrite);

    public abstract void Copy(string srcUri, string desUri, NodeType nodeType, bool overwrite);

    public abstract IEnumerable<Pair<string, NodeType>> List(string uri, string regex);

    public abstract IEnumerable<NetworkFileSystemEntry> ListAttributes(string uri, string regex);

    public virtual void Dispose()
    {
        try
        {
            Disconnect();
        }
        catch
        {
        }
    }

    public abstract Stream OpenRandomAccessStream(string uri, FileMode fileMode, FileAccess fileAccess, FileShare fileShare);

    public abstract void CreateHardLink(string srcUri, string desUri, bool overwrite);

    public abstract TimeSpan Ping();

    public abstract HashValue ComputeHash(
        string uri, NodeType nodeType, string algorithm, bool recursive, long offset, long length, IEnumerable<string> fileAttributes,
        IEnumerable<string> dirAttributes);

    public abstract HashValue ComputeHash(Stream stream, string algorithm, long offset, long length);

    public abstract IEnumerable<Pair<string, object>> GetAttributes(string uri, NodeType nodeType);

    public abstract void SetAttributes(string uri, NodeType nodeType, IEnumerable<Pair<string, object>> attributes);

    public virtual void Reconnect()
    {
        ReadStream.Close();
        WriteStream.Close();

        TcpClient = new TcpClient();

        Connect();
    }
}