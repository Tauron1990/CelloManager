using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Network.Server;

public interface INetworkFileSystemServer
    : ITask, IDisposable
{
}