using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using Platform.IO;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Network;

public class NetworkFile
    : AbstractFile
{
    public NetworkFile(IFileSystem fileSystem, INodeAddress address)
        : base(address, fileSystem)
    {
    }

    public new NetworkFileSystem FileSystem => (NetworkFileSystem)base.FileSystem;

    public new NetworkNodeAddress Address => (NetworkNodeAddress)base.Address;

    protected override INodeAttributes CreateAttributes()
    {
        return new NetworkNodeAndFileAttributes(this);
    }

    public override IService GetService(ServiceType serviceType)
    {
        if (serviceType is FileHashingServiceType)
            return new NetworkFileHashingService(this, (FileHashingServiceType)serviceType);
        if (serviceType is StreamHashingServiceType) return new NetworkStreamHashingService(this, (StreamHashingServiceType)serviceType);

        return base.GetService(serviceType);
    }

    protected override IFile DoCreateHardLink(IFile targetFile, bool overwrite)
    {
        NetworkFileSystem.FreeClientContext clientContext = null;

        // Get a new client context

        if (!targetFile.FileSystem.Equals(FileSystem)) throw new NotSupportedException("CreateHardLink/ForiegnFilesystem");

        using (clientContext = FileSystem.GetFreeClientContext())
        {
            clientContext.NetworkFileSystemClient.CreateHardLink(Address.RemoteUri, ((NetworkNodeAddress)targetFile.Address).RemoteUri, overwrite);
        }

        return this;
    }

    protected override Stream DoGetInputStream(string contentName, out string encoding, FileMode fileMode, FileShare fileShare)
    {
        encoding = null;

        return DoOpenStream(contentName, fileMode, FileAccess.Read, fileShare);
    }

    protected override Stream DoGetOutputStream(string contentName, string? encoding, FileMode fileMode, FileShare fileShare)
    {
        return DoOpenStream(contentName, fileMode, FileAccess.Write, fileShare);
    }

    protected override Stream DoOpenStream(string contentName, FileMode fileMode, FileAccess fileAccess, FileShare fileShare)
    {
        Stream stream = null;
        NetworkFileSystem.FreeClientContext clientContext = null;

        // Get a new client context optimised for binary access

        clientContext = FileSystem.GetFreeClientContext(true);

        try
        {
            // Create a new RandomAcessStream based on the client

            stream = clientContext.NetworkFileSystemClient.OpenRandomAccessStream(Address.RemoteUri, fileMode, fileAccess, fileShare);

            // Make sure the client context is disposed after the stream is closed

            ((IStreamWithEvents)stream).AfterClose += delegate
            {
                clientContext.Dispose();

                if (fileAccess == FileAccess.ReadWrite || fileAccess == FileAccess.Write)
                {
                    ((NetworkNodeAndFileAttributes)Attributes).SetValue("exists", true);
                    ((NetworkNodeAndFileAttributes)Attributes).SetValue("length", stream.Length);

                    ((NetworkDirectory)ParentDirectory).AddChild(this);

                    NetworkFileSystem.RaiseActivityEvent(FileSystem,
                        new FileSystemActivityEventArgs(FileSystemActivity.Changed, NodeType, Name, Address.AbsolutePath));
                }
            };
        }
        finally
        {
            if (stream == null)
                // Explicitly dispose the client context because the
                // stream can't do it cause it doesn't exist

                clientContext.Dispose();
        }

        return stream;
    }

    //
    // Create/Delete/Copy/Move
    //

    public override INode DoCreate(bool createParent)
    {
        NetworkNode.DoCreate(this, createParent);

        return this;
    }

    protected override INode DoDelete()
    {
        NetworkNode.DoDelete(this, false);

        return this;
    }

    protected override INode DoCopyTo(INode target, bool overwrite)
    {
        NetworkNode.DoCopyTo(this, target, base.CopyTo, overwrite);

        return this;
    }

    protected override INode DoMoveTo(INode target, bool overwrite)
    {
        NetworkNode.DoMoveTo(this, target, base.MoveTo, overwrite);

        return this;
    }
}