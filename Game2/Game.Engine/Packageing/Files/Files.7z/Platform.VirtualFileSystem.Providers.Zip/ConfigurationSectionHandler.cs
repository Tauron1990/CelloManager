using System.Xml;
using Platform.Xml.Serialization;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Zip;

public class ConfigurationSectionHandler
    : IConfigurationSectionHandler
{
    public object Create(object parent, object configContext, XmlNode section)
    {
        var serializer = XmlSerializer<ConfigurationSection>.New();
        var config = serializer.Deserialize(new XmlNodeReader(section));

        config.SetXmlNode(section);

        return config;
    }
}