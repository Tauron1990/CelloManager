﻿namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Zip;

internal class StreamDataSource
    : IStaticDataSource
{
    private readonly Stream stream;

    public StreamDataSource(Stream stream)
    {
        this.stream = stream;
    }

    public Stream GetSource()
    {
        return stream;
    }
}