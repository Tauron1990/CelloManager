﻿namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Zip;

internal class ZipFileInfo
    : ZipNodeInfo
{
    public ZipFileInfo(ZipEntry zipEntry)
        : base(zipEntry)
    {
    }

    public IFile ShadowFile { get; private set; }

    public override bool Exists
    {
        get
        {
            if (ShadowFile != null) return true;

            return base.Exists;
        }
    }

    public override DateTime? DateTime
    {
        get
        {
            if (ShadowFile != null) return ShadowFile.Attributes.CreationTime;

            return base.DateTime;
        }
    }

    public virtual IFile GetShadowFile(bool createIfNecessary)
    {
        if (ShadowFile != null) return ShadowFile;

        if (!createIfNecessary) return null;

        var uniqueId = Guid.NewGuid();

        var retval = FileSystemManager.Default.ResolveFile("temp:///" + uniqueId.ToString("N") + ".zipfs.tmp");

        retval.Create();

        ShadowFile = retval;

        return retval;
    }

    public override void Create()
    {
        GetShadowFile(true).Create();

        base.Create();
    }

    public override void Delete()
    {
        base.Delete();

        if (ShadowFile != null)
            try
            {
                ShadowFile.Delete();
            }
            catch
            {
            }

        ShadowFile = null;
    }
}