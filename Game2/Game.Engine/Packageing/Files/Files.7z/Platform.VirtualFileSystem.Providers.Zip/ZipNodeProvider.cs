namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Zip;

public class ZipNodeProvider
    : AbstractMultiFileSystemNodeProvider
{
    public ZipNodeProvider(IFileSystemManager manager)
        : base(manager)
    {
    }

    public override string[] SupportedUriSchemas => new[] { "zip" };

    protected override INodeAddress ParseUri(string uri)
    {
        return LayeredNodeAddress.Parse(uri);
    }

    protected override IFileSystem NewFileSystem(INodeAddress rootAddress, FileSystemOptions? options, out bool cache)
    {
        var backingFile = Manager.ResolveFile(((LayeredNodeAddress)rootAddress).InnerUri);

        cache = true;

        return new ZipFileSystem(rootAddress, backingFile, AmmendOptionsFromAddress(backingFile.Address, options));
    }
}