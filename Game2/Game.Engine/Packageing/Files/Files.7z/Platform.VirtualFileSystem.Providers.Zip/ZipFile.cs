using ZLib = ICSharpCode.SharpZipLib.Zip;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Zip;

public class ZipFile
    : AbstractFile, IZipNode
{
    private ZLib.ZipEntry zipEntry;
    private string zipPath;

    public ZipFile(ZipFileSystem fileSystem, LayeredNodeAddress address, ZLib.ZipEntry zipEntry)
        : base(address, fileSystem)
    {
        ((IZipNode)this).SetZipEntry(zipEntry);
    }

    public override bool SupportsActivityEvents => true;

    public virtual ZLib.ZipEntry ZipEntry => zipEntry;

    string IZipNode.ZipPath => zipPath;

    protected override Stream DoGetInputStream(string contentName, out string encoding, FileMode fileMode, FileShare fileShare)
    {
        encoding = null;

        return ZipFileStream.CreateInputStream(this);
    }

    protected override Stream DoGetOutputStream(string contentName, string? encoding, FileMode fileMode, FileShare fileShare)
    {
        return ZipFileStream.CreateOutputStream(this);
    }

    protected override INodeAttributes CreateAttributes()
    {
        return new ZipFileAttributes(this);
    }

    public void SetZipEntry(ZLib.ZipEntry value)
    {
        zipEntry = value;

        if (zipEntry != null)
            zipPath = zipEntry.Name;
        else
            zipPath = Address.AbsolutePath.Substring(1);
    }

    protected override INode DoDelete()
    {
        var zipFileInfo = ((ZipFileSystem)FileSystem).GetZipFileInfo(Address.AbsolutePath);

        zipFileInfo.Delete();

        return this;
    }
}