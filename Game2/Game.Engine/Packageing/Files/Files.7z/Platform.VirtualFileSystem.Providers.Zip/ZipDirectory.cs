using Platform;
using ZLib = ICSharpCode.SharpZipLib.Zip;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Zip;

public sealed class ZipDirectory
    : AbstractDirectory, IZipNode
{
    public ZipDirectory(ZipFileSystem fileSystem, LayeredNodeAddress address, ZLib.ZipEntry zipEntry)
        : base(fileSystem, address)
    {
        ((IZipNode)this).SetZipEntry(zipEntry);
    }

    public ZLib.ZipEntry ZipEntry { get; private set; }

    public string ZipPath { get; private set; }

    void IZipNode.SetZipEntry(ZLib.ZipEntry value)
    {
        ZipEntry = value;

        if (value != null)
            ZipPath = value.Name;
        else
            ZipPath = Address.AbsolutePath.Substring(1);
    }

    protected override INode DoDelete()
    {
        return DoDelete(false);
    }

    protected override IDirectory DoDelete(bool recursive)
    {
        if (((ZipFileSystem)FileSystem).Options.ReadOnly) return base.DoDelete(recursive);

        if (!recursive)
        {
            if (GetChildren().Any()) throw new IOException("The directory is not empty");

            ((ZipFileSystem)FileSystem).GetZipDirectoryInfo(Address.AbsolutePath).Delete();
        }
        else
        {
            foreach (var item in GetChildren())
                if (item is IDirectory)
                    ((IDirectory)item).Delete(true);
                else
                    item.Delete();

            ((ZipFileSystem)FileSystem).GetZipDirectoryInfo(Address.AbsolutePath).Delete();
        }

        return this;
    }

    public override INode DoCreate(bool createParent)
    {
        if (((ZipFileSystem)FileSystem).Options.ReadOnly) return base.DoCreate(createParent);

        if (createParent)
        {
            if (!ParentDirectory.Exists) ParentDirectory.Create(true);
        }
        else
        {
            if (!ParentDirectory.Exists) throw new DirectoryNodeNotFoundException(ParentDirectory.Address);
        }

        ((ZipFileSystem)FileSystem).GetZipDirectoryInfo(Address.AbsolutePath).Create();

        return this;
    }

    public override IEnumerable<INode> DoGetChildren(NodeType nodeType, Predicate<INode> acceptNode)
    {
        INode node;
        var files = new List<IFile>();
        var directories = new HashSet<string>();

        Refresh();

        var fileSystem = (ZipFileSystem)FileSystem;

        foreach (ZLib.ZipEntry zipEntry in fileSystem.zipFile)
            if (zipEntry.Name.StartsWith(ZipPath) /* Is descendent */
                && zipEntry.Name.Length != ZipPath.Length /* Not self */)
            {
                var x = zipEntry.Name.IndexOf('/', ZipPath.Length + 1);

                if (x == -1 /* Is direct descendent File */)
                {
                    node = FileSystem.ResolveFile(FileSystemManager.SeperatorChar + zipEntry.Name);

                    if (acceptNode(node)) files.Add((IFile)node);
                }
                else if (x <= zipEntry.Name.Length - 1 /* Is direct descendent dir */)
                {
                    var s = zipEntry.Name.Substring(0, x);

                    directories.Add(s);
                }
            }

        if (nodeType.Equals(NodeType.Directory) || nodeType.Equals(NodeType.Any))
        {
            var sortedDirectories = directories.Sorted(StringComparer.InvariantCultureIgnoreCase);

            foreach (var path in sortedDirectories)
            {
                node = FileSystem.ResolveDirectory(FileSystemManager.SeperatorChar + path);

                if (acceptNode(node)) yield return node;
            }
        }

        if (nodeType.Equals(NodeType.File) || nodeType.Equals(NodeType.Any))
            foreach (var file in files)
                yield return file;
    }

    protected override INodeAttributes CreateAttributes()
    {
        return new ZipNodeAttributes(this);
    }
}