namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Zip;

internal class ZipNodeAttributes
    : AbstractTypeBasedNodeAttributes
{
    protected IZipNode zipNode;

    public ZipNodeAttributes(IZipNode zipNode)
        : base(zipNode)
    {
        this.zipNode = zipNode;
    }

    public override bool Exists
    {
        get
        {
            if (zipNode.NodeType.IsLikeDirectory)
                return ((ZipFileSystem)zipNode.FileSystem).GetZipDirectoryInfo(zipNode.Address.AbsolutePath).Exists;
            return ((ZipFileSystem)zipNode.FileSystem).GetZipFileInfo(zipNode.Address.AbsolutePath).Exists;
        }
    }

    public override DateTime? CreationTime
    {
        get
        {
            lock (SyncLock)
            {
                VerifyZipEntry();

                return zipNode.ZipEntry.DateTime;
            }
        }
        set { }
    }

    public override DateTime? LastAccessTime
    {
        get
        {
            lock (SyncLock)
            {
                VerifyZipEntry();

                return zipNode.ZipEntry.DateTime;
            }
        }
        set { }
    }

    public override DateTime? LastWriteTime
    {
        get
        {
            lock (SyncLock)
            {
                VerifyZipEntry();

                return zipNode.ZipEntry.DateTime;
            }
        }
        set { }
    }

    protected virtual void VerifyZipEntry()
    {
        if (zipNode.ZipEntry == null) throw new FileNodeNotFoundException(zipNode.Address);
    }

    public override INodeAttributes Refresh()
    {
        zipNode.SetZipEntry(((ZipFileSystem)zipNode.FileSystem).GetEntry(zipNode.ZipPath));

        return this;
    }
}