using System.Xml;
using Platform.Xml.Serialization;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Zip;

[XmlElement("Configuration")]
public class ConfigurationSection
{
    private static ConfigurationSection instance;

    public ConfigurationSection()
    {
        AutoShadowThreshold = 0;
    }

    public static ConfigurationSection Instance
    {
        get
        {
            if (instance != null) return instance;

            lock (typeof(ConfigurationSection))
            {
                try
                {
#pragma warning disable 618
                    instance = (ConfigurationSection)ConfigurationSettings.GetConfig("Platform/VirtualFileSystem/Zip/Configuration");
#pragma warning restore 618
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine(e.InnerException.Message);
                }

                if (instance == null) instance = new ConfigurationSection();
            }

            return instance;
        }
    }

    public XmlNode XmlNode { get; private set; }

    [XmlElement]
    public int AutoShadowThreshold { get; set; }


    internal virtual void SetXmlNode(XmlNode node)
    {
        XmlNode = node;
    }
}