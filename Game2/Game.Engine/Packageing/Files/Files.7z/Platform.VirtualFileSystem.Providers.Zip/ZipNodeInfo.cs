﻿namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Zip;

internal abstract class ZipNodeInfo
{
    protected bool exists;

    protected ZipNodeInfo()
    {
    }

    protected ZipNodeInfo(ZipEntry zipEntry)
    {
        ZipEntry = zipEntry;

        exists = zipEntry != null;
    }

    public string AbsolutePath { get; set; }
    public ZipEntry ZipEntry { get; set; }

    public virtual bool Exists => exists;

    public virtual DateTime? DateTime
    {
        get
        {
            if (ZipEntry != null) return ZipEntry.DateTime;

            return null;
        }
    }

    public virtual void Create()
    {
        exists = true;
    }

    public virtual void Delete()
    {
        exists = false;
    }
}