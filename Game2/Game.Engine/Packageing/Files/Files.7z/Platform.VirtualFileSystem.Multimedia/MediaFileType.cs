namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Multimedia;

public class MediaFileType
{
    public static readonly MediaFileType Auto = new(typeof(IAutoMediaFileType));
    public static readonly MediaFileType Unknown = new(typeof(IUnknownMediaFileType));
    public static readonly MediaFileType SoundFile = new(typeof(ISoundFile));
    public static readonly MediaFileType VideoFile = new(typeof(IVideoFile));

    private readonly Type runtimeType;

    protected MediaFileType(Type runtimeType)
    {
        this.runtimeType = runtimeType;
    }

    public virtual Type RuntimeType => runtimeType;

    public override int GetHashCode()
    {
        return runtimeType.GetHashCode();
    }

    public override bool Equals(object obj)
    {
        var temp = obj as MediaFileType;

        if (temp == null) return false;

        return temp.runtimeType == runtimeType;
    }

    private interface IUnknownMediaFileType
    {
    }

    private interface IAutoMediaFileType
    {
    }
}