using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using Platform;
using Platform.Threading;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Multimedia;

public abstract class AbstractMediaFile
    : FileWrapper, IMediaFile
{
	/// <summary>
	///     <see cref="TaskAsynchronisity " />
	/// </summary>
	private TaskAsynchronisity m_TaskAsynchronisity;

    public AbstractMediaFile(IFile file)
        : base(file)
    {
        ApartmentState = ApartmentState.Unknown;
    }

    public virtual void FadeToLevel(VolumeLevel targetLevel, TimeSpan time)
    {
        const int steps = 50;

        var startLevel = VolumeLevel.Average;
        var sleep = new TimeSpan(time.Ticks / steps);
        var delta = (targetLevel.Average - startLevel) / steps;
        var newLevel = startLevel + delta;

        if (newLevel < 0) newLevel = 0;

        try
        {
            for (var i = 0; i < steps; i++)
            {
                VolumeLevel = new VolumeLevel(newLevel, newLevel);

                try
                {
                    checked
                    {
                        newLevel += delta;
                    }
                }
                catch (OverflowException)
                {
                    newLevel = targetLevel.Average;
                }

                Thread.Sleep(sleep);
            }

            VolumeLevel = targetLevel;
        }
        catch (Exception)
        {
        }
    }

    public virtual void Run()
    {
        Play();

        this.WaitForAnyTaskState(PredicateUtils.ObjectEqualsAny(TaskState.Finished, TaskState.Stopped));
    }

    public abstract void Open();

    public abstract void Close();

    public virtual void WaitForFinish()
    {
        WaitForFinish(Timeout.Infinite);
    }

    public virtual bool WaitForFinish(int timeout)
    {
        return WaitForFinish(TimeSpan.FromMilliseconds(timeout));
    }

    public virtual bool WaitForFinish(TimeSpan timeout)
    {
        lock (TaskStateLock)
        {
            var taskState = TaskState;

            if (taskState == TaskState.Unknown
                || taskState == TaskState.NotStarted
                || taskState == TaskState.Stopped)
                return true;
        }

        return this.WaitForAnyTaskState(timeout, PredicateUtils.ObjectEqualsAny(TaskState.Finished, TaskState.Stopped));
    }

    public virtual void WaitForPlaybackPosition(TimeSpan position)
    {
        WaitForPlaybackPosition(position, Timeout.Infinite);
    }

    public virtual bool WaitForPlaybackPosition(TimeSpan position, int timeout)
    {
        return WaitForPlaybackPosition(position, TimeSpan.FromMilliseconds(timeout));
    }

    public virtual bool WaitForPlaybackPosition(TimeSpan position, TimeSpan timeout)
    {
        return GetWaitHandleForPlaybackPosition(position).WaitOne(timeout, false);
    }

    public abstract VolumeLevel VolumeLevel { get; set; }

    public virtual bool CanRequestTaskState(TaskState taskState)
    {
        return true;
    }

    public abstract Thread GetTaskThread();

    /// <summary>
    ///     TaskAsynchronisity
    /// </summary>
    public virtual TaskAsynchronisity TaskAsynchronisity
    {
        get => m_TaskAsynchronisity;
        set => m_TaskAsynchronisity = value;
    }

    /// <summary>
    ///     RequestedTaskState
    /// </summary>
    public abstract TaskState RequestedTaskState { get; }

    public ApartmentState ApartmentState { get; set; }

    ~AbstractMediaFile()
    {
        Close();
    }

    protected virtual WaitHandle GetWaitHandleForPlaybackPosition(TimeSpan position)
    {
        return new MeterValueEvent<TimeSpan>(Progress,
            delegate(TimeSpan value) { return value >= position; }).WaitHandle;
    }

    #region IMediaFile Members

    public virtual event EventHandler Opened;

    public virtual event EventHandler Closed;

    protected virtual void OnClosed()
    {
        if (Closed != null) Closed(this, EventArgs.Empty);
    }

    protected virtual void OnOpened()
    {
        if (Opened != null) Opened(this, EventArgs.Empty);
    }

    public virtual IMeter PlaybackMeter => Progress;

    public virtual TimeSpan PlaybackPosition
    {
        get => (TimeSpan)Progress.CurrentValue;
        set => Seek(value);
    }

    public virtual TimeSpan PlaybackLength => (TimeSpan)Progress.MaximumValue;

    public abstract void Seek(TimeSpan position);

    public override NodeType NodeType => new MediaFileNodeType(MediaFileType.Unknown);


    public virtual void Play()
    {
        Start();
    }

    #endregion

    #region ITask Members

    public virtual bool SupportsStart => true;

    public abstract object TaskStateLock { get; }

    public virtual void Start()
    {
        RequestTaskState(TaskState.Running);
    }

    public virtual void RequestTaskState(TaskState taskState)
    {
        RequestTaskState(taskState, new TimeSpan(-1));
    }

    public abstract bool RequestTaskState(TaskState taskState, TimeSpan timeout);

    public virtual void Resume()
    {
        RequestTaskState(TaskState.Running);
    }

    public virtual void Pause()
    {
        RequestTaskState(TaskState.Paused);
    }

    public abstract TaskState TaskState { get; }

    public virtual bool SupportsPause => true;

    public virtual bool SupportsStop => true;

    public virtual bool SupportsResume => true;

    /// <summary>
    ///     TaskStateChanged Event.
    /// </summary>
    public virtual event TaskEventHandler TaskStateChanged;

    /// <summary>
    ///     Raises the TaskStateChanged event.
    /// </summary>
    /// <param name="eventArgs">The <see cref="TaskEventArgs" /> that contains the event data.</param>
    protected virtual void OnTaskStateChanged(TaskEventArgs eventArgs)
    {
        if (TaskStateChanged != null) TaskStateChanged(this, eventArgs);
    }

    public virtual void Stop()
    {
        RequestTaskState(TaskState.Stopped);
    }

    public abstract IMeter Progress { get; }

    #endregion

    #region ITask Members

    /// <summary>
    ///     RequestedTaskStateChanged Event.
    /// </summary>
    public virtual event TaskEventHandler RequestedTaskStateChanged;

    /// <summary>
    ///     Raises the RequestedTaskStateChanged event.
    /// </summary>
    /// <param name="eventArgs">The <see cref="TaskEventArgs" /> that contains the event data.</param>
    protected virtual void OnRequestedTaskStateChanged(TaskEventArgs eventArgs)
    {
        if (RequestedTaskStateChanged != null) RequestedTaskStateChanged(this, eventArgs);
    }

    #endregion
}