namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Multimedia;

public interface IVideoFile
    : IMediaFile
{
}