namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Multimedia;

public class VolumeFaderServiceType
    : ServiceType
{
    public VolumeFaderServiceType()
        : base(typeof(VolumeFaderServiceType))
    {
    }
}