namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Multimedia;

public interface ISoundFile
    : IMediaFile
{
}