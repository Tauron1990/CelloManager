namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Multimedia;

public static class MediaFileMonitor
{
    public static bool WaitForPlaybackPosition(IMediaFile mediaFile, TimeSpan position, TimeSpan timeout)
    {
        return false;
    }
}