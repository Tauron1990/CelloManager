using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public delegate void FileTransferServiceEventHandler(object sender, FileTransferServiceEventArgs eventArg);

[PublicAPI]
public interface IFileTransferService : INodeCopyingService
{
    TransferState TransferState { get; }

    event FileTransferServiceEventHandler TransferStateChanged;
}