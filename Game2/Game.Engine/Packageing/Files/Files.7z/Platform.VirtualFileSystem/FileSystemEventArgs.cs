using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

/// <summary>
///     Event handler for file system activity events.
/// </summary>
/// <remarks>
///     <seealso cref="FileSystemActivityEventArgs" />
/// </remarks>
public delegate void FileSystemActivityEventHandler(object sender, FileSystemActivityEventArgs eventArgs);

/// <summary>
///     Provides state information about file system activity events.
/// </summary>
[PublicAPI]
public class FileSystemActivityEventArgs
    : EventArgs
{
    public FileSystemActivityEventArgs(FileSystemActivity activity, NodeType nodeType, string name, string path)
    {
        Activity = activity;
        Name = name;
        Path = path;
        NodeType = nodeType;
    }

    public virtual FileSystemActivity Activity { get; }

    public string Path { get; set; }
    public string Name { get; set; }
    public NodeType NodeType { get; set; }
}