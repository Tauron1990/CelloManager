using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Local;
using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.MyComputer;
using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Shadow;
using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Temp;
using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Web;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

/// <summary>
///     A default implementation of a FileSystemManager.
/// </summary>
/// <remarks>
///     <p>
///         This manager only uses the <c>Web</c> provider to resolve files.  You should extend this
///         class and call <see cref="DefaultFileSystemManager.AddProvider(INodeProvider)" />
///         to add more providers.
///     </p>
///     <p>
///         Usually you would use the <see cref="StandardFileSystemManager" />.  It uses all the standard
///         providers as well as providers configured in the application <c>config</c> file.  The
///         <see cref="StandardFileSystemManager" /> is based on this provider so will still rely on the
///         <see cref="WebNodeProvider" /> when no other providers can resolve a file.
///     </p>
/// </remarks>
public class DefaultFileSystemManager
    : StandardFileSystemManager
{
    public DefaultFileSystemManager()
    {
        AddDefaultProviders();
        ScanAssembliesAndAddProviders();
    }

    private void AddDefaultProviders()
    {
        AddProvider(new LocalNodeProvider(this));
        AddProvider(new TempNodeProvider(this));
        AddProvider(new WebNodeProvider(this));
        AddProvider(new ShadowNodeProvider(this));
        AddProvider(new MyComputerNodeProvider(this));
    }
}