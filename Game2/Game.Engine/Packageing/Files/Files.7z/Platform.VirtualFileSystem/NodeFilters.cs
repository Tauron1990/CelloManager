using System.Text.RegularExpressions;
using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public static class NodeFilters
{
    public static Predicate<INode> Any { get; } = ByNodeType(NodeType.Any);

    public static Predicate<INode> File { get; } = ByNodeType(NodeType.File);

    public static Predicate<INode> Directory { get; } = ByNodeType(NodeType.Directory);

    public static Predicate<INode> ByNodeType(NodeType nodeType) =>
        ByNodeType(value => value.Equals(NodeType.Any) || nodeType.Equals(NodeType.Any) || nodeType.Equals(value));

    public static Predicate<INode> ByNodeTypeExact(NodeType nodeType) => ByNodeType(nodeType.Equals);

    public static Predicate<INode> ByNodeType(Predicate<NodeType> acceptNodeType) => node => acceptNodeType(node.NodeType);

    public static Predicate<INode> ByNodeName(string name) => ByNodeName(name, StringComparer.CurrentCultureIgnoreCase);

    public static Predicate<INode> ByNodeName(string name, StringComparer comparer) => ByNodeName(value => comparer.Compare(value, name) == 0);

    public static Predicate<INode> ByNodeName(Predicate<string> acceptName) => node => acceptName(node.Name);

    public static Predicate<INode> BySimpleRegexNameFilter(string regex) => new SimpleRegexNameFilter(regex).Assert;

    public static bool IsSimpleRegexNameFilter(Predicate<INode> filter) => filter.Target?.GetType() == typeof(SimpleRegexNameFilter);

    public static string? GetSimpleRegexNameFilterRegexString(Predicate<INode> filter) => (filter.Target as SimpleRegexNameFilter)?.RegexString;

    private class SimpleRegexNameFilter
    {
        internal readonly string RegexString;

        public SimpleRegexNameFilter(string regex) => RegexString = regex;

        public bool Assert(INode node) => Regex.IsMatch(node.Name, RegexString,
            RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace | RegexOptions.Multiline);
    }
}