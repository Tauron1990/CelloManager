using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class FileComparingServiceType : ServiceType
{
    public FileComparingServiceType(IFile targetFile, FileComparingFlags flags)
    {
        Flags = flags;
        TargetFile = targetFile;
    }

    public virtual FileComparingFlags Flags { get; set; }
    public virtual IFile TargetFile { get; set; }
}