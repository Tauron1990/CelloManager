using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class NodeNameAndTypeComparer : IComparer<INode>
{
    private readonly StringComparer _nameComparer;

    private NodeNameAndTypeComparer(StringComparer nameComparer)
    {
        this._nameComparer = nameComparer;
    }

    public static NodeNameAndTypeComparer Default { get; } = new(StringComparer.CurrentCulture);

    public static NodeNameAndTypeComparer DefaultCaseInsensitive { get; } = new(StringComparer.CurrentCultureIgnoreCase);

    public virtual int Compare(INode? x, INode? y)
    {
        if (Equals(x?.NodeType, y?.NodeType))
            return _nameComparer.Compare(x?.Name, y?.Name);
        if (Equals(x?.NodeType, NodeType.Directory))
            return 1;
        return -1;
    }
}