using JetBrains.Annotations;
// ReSharper disable VirtualMemberCallInConstructor

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class FileTransferServiceType : ServiceType
{
    public FileTransferServiceType(IFile destination, bool verifyIntegrity = false)
        : this(destination, verifyIntegrity, 128 * 1024, 128)
    {
    }

    public FileTransferServiceType(IFile destination, bool verifyIntegrity, int bufferSize, int chunkSize)
    {
        Destination = destination;
        VerifyIntegrity = verifyIntegrity;
        BufferSize = bufferSize;
        ChunkSize = chunkSize;
        HashAlgorithmName = "md5";
        BufferSize = 4096;

        AttributesToTransfer = new[] { "CreationTime", "LastWriteTime", "LastAccessTime" };
    }

    /// <summary>
    ///     HashAlgorithmName
    /// </summary>
    public string HashAlgorithmName { get; set; }

    /// <summary>
    ///     AttributesToTransfer
    /// </summary>
    public virtual string[] AttributesToTransfer { get; set; }

    /// <summary>
    ///     BufferSize
    /// </summary>
    public virtual int BufferSize { get; set; }

    /// <summary>
    ///     VerifyIntegrity
    /// </summary>
    public virtual bool VerifyIntegrity { get; set; }

    /// <summary>
    ///     Destination
    /// </summary>
    public virtual IFile Destination { get; set; }

    /// <summary>
    ///     The size of chunks (bytes) that are transferred at once.
    /// </summary>
    public virtual int ChunkSize { get; set; }
}