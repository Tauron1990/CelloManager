using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

/// <summary>
/// </summary>
[PublicAPI]
public interface ILockingService : IService
{
    void Lock();
    void Lock(int timeout);
    void Unlock();
}