using System.Security.Cryptography;
using Game.Engine.Threading;
using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class StandardHashingService : IRunnable
{
    private readonly IFile _file;
    private readonly HashAlgorithm _hashAlgorithm;

    public StandardHashingService(INode node, string algorithm)
    {
        if (!node.NodeType.Equals(NodeType.File)) throw new ArgumentException("Node must be a File", nameof(node));

        _file = (IFile)node;
        _hashAlgorithm = HashAlgorithm.Create(algorithm) ?? throw new InvalidOperationException("No Algorithm could be Created");
    }

    public object? Value => _hashAlgorithm.Hash;

    public async Task Run()
    {
        await using var stream = _file.GetContent().GetInputStream();
        await _hashAlgorithm.ComputeHashAsync(stream);
    }
}