using System.Reflection;
using JetBrains.Annotations;
// ReSharper disable VirtualMemberCallInConstructor

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[Serializable]
[PublicAPI]
public class NodeType
{
	/// <summary>
	///     An invalid node type.
	/// </summary>
	public static readonly NodeType None = new(typeof(NodeNone));

	/// <summary>
	///     The type of any node that can be converted to <see cref="IFile" />.
	/// </summary>
	public static readonly NodeType File = new(typeof(IFile));

	/// <summary>
	///     The type of any node that can be converted to <see cref="IDirectory" />.
	/// </summary>
	public static readonly NodeType Directory = new(typeof(IDirectory));

	/// <summary>
	///     The type of any node.
	/// </summary>
	public static readonly NodeType Any = new(typeof(NodeAny));

    private static FieldInfo[]? _publicStaticFields;

    public NodeType()
        : this(default(NodeType))
    {
    }

    public NodeType(NodeType? innerType)
    {
        RuntimeType = GetType();
        InnerType = innerType;
    }

    public NodeType(Type runtimeType, NodeType? innerType = null)
    {
        RuntimeType = runtimeType;
        InnerType = innerType;
    }

    /// <summary>
    ///     Get the Common Language Runtime <c>Type</c> that represents the type of node this is.
    /// </summary>
    public virtual Type RuntimeType { get; }

    public virtual NodeType? InnerType { get; set; }

    public virtual bool IsLikeDirectory => Equals(Directory);

    public static bool IsFile(NodeType nodeType) => File.Is(nodeType);

    public static bool IsDirectory(NodeType nodeType) => Directory.Is(nodeType);

    public static bool IsFile(INode node) => File.Is(node.NodeType);

    public static bool IsDirectory(INode node) => Directory.Is(node.NodeType);

    public virtual bool Is(Type type) => type.IsAssignableFrom(RuntimeType);

    public virtual bool Is(NodeType type)
    {
        if (Equals(this, Any)) return true;

        return Equals(type, Any) || type.RuntimeType.IsAssignableFrom(RuntimeType);
    }

    public override bool Equals(object? obj)
    {
        if (obj is not NodeType nodeType) return false;

        return RuntimeType == nodeType.RuntimeType;
    }

    public override int GetHashCode() => RuntimeType.GetHashCode();

    public override string ToString()
    {
        _publicStaticFields ??= typeof(NodeType).GetFields(BindingFlags.Static | BindingFlags.Public);

        foreach (var fieldInfo in _publicStaticFields)
        {
            var nodeType = fieldInfo.GetValue(null) as NodeType;

            if (Equals(nodeType)) return fieldInfo.Name;
        }

        return RuntimeType.Name;
    }

    public static NodeType FromName(string nodeTypeName)
    {
        switch (nodeTypeName.ToUpper())
        {
            case "FILE":
            case "F":
                return File;
            case "DIRECTORY":
            case "D":
                return Directory;
            case "ANY":
            case "A":
                return Any;
            default:
                throw new NotSupportedException("NodeType_" + nodeTypeName);
        }
    }

    /// <summary>
    ///     Dummy class to represent the runtime type of <c>NodeType.None</c>.
    /// </summary>
    private static class NodeNone
    {
    }

    /// <summary>
    ///     Dummy class to represent the runtime type of <c>NodeType.Any</c>.
    /// </summary>
    private static class NodeAny
    {
    }
}