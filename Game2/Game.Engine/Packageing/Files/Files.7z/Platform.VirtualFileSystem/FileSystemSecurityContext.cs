using System.Collections.Concurrent;
using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class FileSystemSecurityContext : AccessPermissionVerifier
{
    private readonly bool _inherit;

    private ConcurrentDictionary<object, AccessPermissionVerifier> _verifiers;

    /// <summary>
    /// </summary>
    /// <param name="previousContext"></param>
    /// <param name="inherit"></param>
    internal FileSystemSecurityContext(FileSystemSecurityContext? previousContext, bool inherit)
    {
        _inherit = inherit;
        PreviousContext = previousContext;

        _verifiers = new ConcurrentDictionary<object, AccessPermissionVerifier>();
    }

    /// <summary>
    ///     PreviousContext property.
    /// </summary>
    internal virtual FileSystemSecurityContext? PreviousContext { get; }

    //internal virtual int VerifiersCount => verifiers.Count;

    public virtual bool IsEmpty => _verifiers.IsEmpty && (PreviousContext is null || PreviousContext.IsEmpty);

    public override void Dispose()
    {
        foreach (var verifier in _verifiers.Values) 
            verifier.Dispose();
        _verifiers.Clear();

        OnDisposed(EventArgs.Empty);
        
        GC.SuppressFinalize(this);
    }

    public event EventHandler? Disposed;

    /// <summary>
    ///     Raises the Disposed event.
    /// </summary>
    /// <param name="eventArgs">The <see cref="EventArgs" /> that contains the event data.</param>
    protected virtual void OnDisposed(EventArgs eventArgs) => Disposed?.Invoke(this, eventArgs);

    public virtual Guid AddPermissionVerifier(AccessPermissionVerifier verifier)
    {
        var guid = new Guid();

        AddPermissionVerifier(guid, verifier);

        return guid;
    }

    public virtual void AddPermissionVerifier(object id, AccessPermissionVerifier verifier)
    {
        if (verifier is FileSystemSecurityContext) throw new ArgumentException("Verifer is FileSystem SecurityContext", nameof(verifier));

        _verifiers.AddOrUpdate(id, _ => verifier, (_, _) => verifier);
    }

    public virtual void RemovePermissionVerifier(object id) => _verifiers.TryRemove(id, out _);

    public override AccessVerificationResult CheckAccess(AccessVerificationContext context)
    {
        foreach (var verifierEntry in _verifiers.Values)
        {
            switch (verifierEntry.CheckAccess(context))
            {
                case AccessVerificationResult.Granted:
                    return AccessVerificationResult.Granted;
                case AccessVerificationResult.Denied:
                    return AccessVerificationResult.Denied;
                case AccessVerificationResult.Undefined:
                    continue;
                default:
                    continue;
            }
        }

        if (_inherit && PreviousContext != null) return PreviousContext.CheckAccess(context);

        return AccessVerificationResult.Undefined;
    }
}