namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public enum AccessVerificationResult
{
    Undefined,
    Granted,
    Denied
}

public abstract class AccessPermissionVerifier : IDisposable
{
    public virtual void Dispose()
    {
    }

    public virtual bool HasAccess(AccessVerificationContext context) => HasAccess(context, true);

    public virtual bool HasAccess(AccessVerificationContext context, bool defaultAccess) 
        => CheckAccess(context) switch
        {
            AccessVerificationResult.Granted => true,
            AccessVerificationResult.Denied => false,
            _ => defaultAccess
        };

    public abstract AccessVerificationResult CheckAccess(AccessVerificationContext context);

    #region PredicateBased

    private class DelegateBasedAccessPermissionVerifier : AccessPermissionVerifier
    {
        private readonly Func<AccessVerificationContext, AccessVerificationResult> _verifier;

        public DelegateBasedAccessPermissionVerifier(Func<AccessVerificationContext, AccessVerificationResult> verifier) => _verifier = verifier;

        public override AccessVerificationResult CheckAccess(AccessVerificationContext context) => _verifier(context);
    }

    public static AccessPermissionVerifier FromPredicate(Func<AccessVerificationContext, AccessVerificationResult> verifier) => new DelegateBasedAccessPermissionVerifier(verifier);

    public static implicit operator AccessPermissionVerifier(Func<AccessVerificationContext, AccessVerificationResult> verifier) => new DelegateBasedAccessPermissionVerifier(verifier);

    #endregion
}