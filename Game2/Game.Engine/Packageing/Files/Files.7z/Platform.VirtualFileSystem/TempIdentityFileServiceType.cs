using JetBrains.Annotations;
// ReSharper disable VirtualMemberCallInConstructor

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class TempIdentityFileServiceType : ServiceType
{
    public TempIdentityFileServiceType(string uniqueIdentifier, IFileSystem? tempFileSystem = null)
    {
        TempFileSystem = tempFileSystem;
        UniqueIdentifier = uniqueIdentifier;
    }

    public virtual string UniqueIdentifier { get; set; }
    public virtual IFileSystem? TempFileSystem { get; set; }
}