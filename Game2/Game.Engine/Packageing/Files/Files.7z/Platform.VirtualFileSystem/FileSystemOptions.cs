using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq.Expressions;
using System.Reflection;
using FastExpressionCompiler;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[Serializable]
public class FileSystemOptions : MarshalByRefObject
{
    private static volatile FileSystemOptions? _defaultOptions;

    private static Dictionary<Type, Action<object, NameValueCollection>> _variableAdderFuncs = new();

    private FileSystemOptions(
        Type nodeCacheType, IEnumerable<Type> nodeServiceProviderTypes, IEnumerable<Type> nodeResolutionFilterTypes, IEnumerable<Type> nodeOperationFilterTypes,
        IEnumerable<Type> accessPermissionVerifierTypes, NameValueCollection variables, bool isDefault = false)
    {
        IsDefault = isDefault;
        NodeCacheType = nodeCacheType;
        Variables = new FileSystemVariablesCollection(variables);
        NodeTransformationFilterTypes = new ReadOnlyCollection<Type>(new List<Type>());
        AccessPermissionVerifierTypes = new ReadOnlyCollection<Type>(accessPermissionVerifierTypes.Distinct().ToList());
        NodeServiceProviderTypes = new ReadOnlyCollection<Type>(nodeServiceProviderTypes.Distinct().ToList());
        NodeResolutionFilterTypes = new ReadOnlyCollection<Type>(nodeResolutionFilterTypes.Distinct().ToList());
        NodeOperationFilterTypes = new ReadOnlyCollection<Type>(nodeOperationFilterTypes.Distinct().ToList());
    }

    public static FileSystemOptions Default
    {
        get
        {
            if (_defaultOptions == null)
                lock (typeof(FileSystemOptions))
                {
                    if (_defaultOptions == null)
                    {
                        var nodeServiceProviderTypes = new List<Type> { typeof(CoreNodeServicesProvider) };

                        _defaultOptions = new FileSystemOptions(typeof(DefaultNodeCache), nodeServiceProviderTypes,
                            ArraySegment<Type>.Empty, ArraySegment<Type>.Empty, ArraySegment<Type>.Empty, 
                            new FileSystemVariablesCollection(), true);
                    }
                }

            return _defaultOptions;
        }
    }

    public bool ReadOnly => false;
    public bool IsDefault { get; }

    public FileSystemVariablesCollection Variables { get; }
    public ReadOnlyCollection<Type> NodeResolutionFilterTypes { get; }
    public ReadOnlyCollection<Type> NodeTransformationFilterTypes { get; }
    public ReadOnlyCollection<Type> NodeServiceProviderTypes { get; }
    public ReadOnlyCollection<Type> NodeOperationFilterTypes { get; }
    public ReadOnlyCollection<Type> AccessPermissionVerifierTypes { get; }
    public Type NodeCacheType { get; set; }

    public override int GetHashCode()
    {
        var retval = 0;

        retval ^= IsDefault ? 1 : 0;
        retval ^= ReadOnly ? 1 : 0;
        retval ^= Variables.Count;
        retval ^= NodeResolutionFilterTypes.Count;
        retval ^= NodeTransformationFilterTypes.Count;
        retval ^= NodeServiceProviderTypes.Count;
        retval ^= NodeOperationFilterTypes.Count;
        retval ^= AccessPermissionVerifierTypes.Count;

        return retval;
    }

    public override bool Equals(object? obj)
    {
        if (obj is not FileSystemOptions typedObj) return false;

        return IsDefault == typedObj.IsDefault
               && ReadOnly == typedObj.ReadOnly
               && Variables.CollectionEquals(typedObj.Variables)
               && NodeResolutionFilterTypes.ElementsAreEqual(typedObj.NodeResolutionFilterTypes)
               && NodeTransformationFilterTypes.ElementsAreEqual(typedObj.NodeTransformationFilterTypes)
               && NodeServiceProviderTypes.ElementsAreEqual(typedObj.NodeServiceProviderTypes)
               && NodeOperationFilterTypes.ElementsAreEqual(typedObj.NodeOperationFilterTypes)
               && AccessPermissionVerifierTypes.ElementsAreEqual(typedObj.AccessPermissionVerifierTypes);
    }
    
    public FileSystemOptions AddVariables(NameValueCollection? variables)
    {
        if (variables is null) return this;

        var newVariables = new NameValueCollection(Variables) { variables };

        return new FileSystemOptions(NodeCacheType, NodeServiceProviderTypes, NodeResolutionFilterTypes, NodeOperationFilterTypes,
            AccessPermissionVerifierTypes, newVariables);
    }

    public FileSystemOptions AddVariables<T>(T variables)
    {
        if (variables == null) return this;

        var newVariables = new NameValueCollection(Variables);

        if (!_variableAdderFuncs.TryGetValue(typeof(T), out var adderFunc))
        {
            var param1 = Expression.Parameter(typeof(object));
            var param2 = Expression.Parameter(typeof(NameValueCollection));

            var setMethod = typeof(NameValueCollection)
                .GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(c => c.GetIndexParameters().Length == 1)
                .Where(c => c.GetIndexParameters()[0].ParameterType == typeof(string))
                .Where(c => c.Name == "Item")
                .Select(c => c.SetMethod)
                .Single();

            var adderCalls =
                (from property in typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                    where setMethod is not null
                    select Expression.Call(param2, setMethod, Expression.Constant(property.Name),
                        Expression.Property(Expression.Convert(param1, typeof(T)), property))).Cast<Expression>().ToList();

            adderFunc = Expression.Lambda<Action<object, NameValueCollection>>(Expression.Block(adderCalls), param1, param2).CompileFast();

            _variableAdderFuncs = new Dictionary<Type, Action<object, NameValueCollection>>(_variableAdderFuncs) { [typeof(T)] = adderFunc };
        }

        adderFunc(variables, newVariables);

        return new FileSystemOptions(NodeCacheType, NodeServiceProviderTypes, NodeResolutionFilterTypes, NodeOperationFilterTypes,
            AccessPermissionVerifierTypes, newVariables);
    }

    public FileSystemOptions ChangeNodeCacheType(Type nodeCacheType)
    {
        return new FileSystemOptions(nodeCacheType, NodeServiceProviderTypes, NodeResolutionFilterTypes, NodeOperationFilterTypes,
            AccessPermissionVerifierTypes, Variables);
    }
}