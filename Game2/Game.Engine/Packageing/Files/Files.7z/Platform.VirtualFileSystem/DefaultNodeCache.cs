namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public class DefaultNodeCache : WeakReferenceBasedNodeCache<DefaultNodeCache.DefaultNodeCacheKey>
{
    protected override DefaultNodeCacheKey GetKey(INodeAddress address, NodeType nodeType) => new(address, nodeType);

    public override void PurgeWithDescendents(INodeAddress address, NodeType nodeType)
    {
        lock (SyncLock)
        {
            var removeList = Cache.Select(c => c.Key).Where(key => key.NodeAddress.IsDescendentOf(address, AddressScope.DescendentOrSelf))
                .Where(key => key.NodeType.Is(nodeType)).ToList();

            foreach (var key in removeList) Purge(key.NodeAddress, key.NodeType);
        }
    }

    public readonly struct DefaultNodeCacheKey
    {
        public NodeType NodeType { get; }

        public INodeAddress NodeAddress { get; }

        public DefaultNodeCacheKey(INodeAddress address, NodeType nodeType)
        {
            NodeAddress = address;
            NodeType = nodeType;
        }

        public override string ToString() => NodeAddress?.ToString() ?? string.Empty;

        public override int GetHashCode() => NodeAddress.PathAndQuery.GetHashCode() ^ NodeType.GetHashCode();

        public override bool Equals(object? obj)
        {
            if (obj is not DefaultNodeCacheKey cacheKey) return false;

            return cacheKey.NodeAddress.PathAndQuery == NodeAddress.PathAndQuery && cacheKey.NodeType.Equals(NodeType);
        }

        public static bool operator ==(DefaultNodeCacheKey left, DefaultNodeCacheKey right) => left.Equals(right);

        public static bool operator !=(DefaultNodeCacheKey left, DefaultNodeCacheKey right) => !(left == right);
    }
}