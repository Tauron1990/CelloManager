using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

/// <summary>
///     Summary description for INodeCacheKeyProvider.
/// </summary>
[PublicAPI]
public interface INodeCacheKeyProvider
{
    object[] GetNodeCacheKeys();
}