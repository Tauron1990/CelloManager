namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public interface INodeAttributesUpdateContext : IDisposable
{
}