namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

/// <summary>
///     This class provides a skeletal implementation of the <c>IResolver</c> interface to minimize the
///     effort required to implement the <see cref="IResolver" /> interface.
/// </summary>
public abstract class AbstractResolver : INodeResolver
{
    public virtual IDirectory ResolveDirectory(string name) => ResolveDirectory(name, AddressScope.FileSystem);

    public virtual IFile ResolveFile(string name) => ResolveFile(name, AddressScope.FileSystem);

    public virtual IDirectory ResolveDirectory(string name, AddressScope scope) => (IDirectory)Resolve(name, NodeType.Directory, scope);

    public virtual IFile ResolveFile(string name, AddressScope scope) => (IFile)Resolve(name, NodeType.File, scope);

    public virtual INode Resolve(string name) => Resolve(name, AddressScope.FileSystem);

    public virtual INode Resolve(string name, AddressScope scope) => Resolve(name, NodeType.Any, scope);

    public virtual INode Resolve(string name, NodeType nodeType) => Resolve(name, nodeType, AddressScope.FileSystem);

    public abstract INode Resolve(string name, NodeType nodeType, AddressScope scope);
}