namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public interface INodeDeletingService : INodeTaskService
{
}