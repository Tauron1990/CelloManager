using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class FileSystemSecurityManager : IDisposable
{
    private readonly ThreadLocal<FileSystemSecurityContext?> _currentContext;

    public FileSystemSecurityManager()
    {
        GlobalContext = new FileSystemSecurityContext(null, false);
        _currentContext = new ThreadLocal<FileSystemSecurityContext?>(() => new FileSystemSecurityContext(GlobalContext, true));
    }

    public static FileSystemSecurityManager Default { get; } = new();

    public virtual bool IsActive => true;

    public FileSystemSecurityContext GlobalContext { get; }

    public virtual FileSystemSecurityContext CurrentContext => _currentContext.Value!;

    public virtual void Dispose()
    {
        GlobalContext.Dispose();
        foreach (var context in _currentContext.Values) context?.Dispose();
        _currentContext.Dispose();
    }

    public virtual FileSystemSecurityContext AcquireSecurityContext(bool inherit)
    {
        var newContext = new FileSystemSecurityContext(_currentContext.Value, inherit);
        _currentContext.Value = newContext;

        newContext.Disposed += delegate { _currentContext.Value = newContext.PreviousContext; };

        return newContext;
    }
}