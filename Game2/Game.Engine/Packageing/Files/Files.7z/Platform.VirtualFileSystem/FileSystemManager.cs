namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public static class FileSystemManager
{
    public const char SeperatorChar = '/';
    public const string SeperatorString = "/";
    public const char RootChar = '/';
    public const string RootPath = "/";

    private static IFileSystemManager _manager = new DefaultFileSystemManager();


    public static IFileSystemManager Default => GetManager();

    public static void SetDefault(IFileSystemManager manager)
        => _manager = manager;
    
    public static IFileSystemManager GetManager()
    {
        if (_manager == null) throw new InvalidOperationException("No default manager");

        return _manager;
    }
}