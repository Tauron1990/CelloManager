using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public interface IFileHashingService : IHashingService
{
    new IFile OperatingNode { get; }
}