using Game.Engine.Core;
using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using JetBrains.Annotations;

// ReSharper disable VirtualMemberCallInConstructor

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class TempIdentityFileNodeResolutionFilter : AbstractNodeResolutionFilter
{
    public TempIdentityFileNodeResolutionFilter() => QueryKey = "tempidentity";

    public virtual string? QueryKey { get; set; }

    public override INode Filter(ref INodeResolver resolver, ref INodeAddress address, ref NodeType nodeType, out bool canCache)
    {
        string value;

        canCache = false;

        if (QueryKey is null)
            return null;
        try
        {
            if (address.QueryValues[QueryKey] is null) return null;

            value = address.QueryValues[QueryKey] ?? string.Empty;
        }
        catch (KeyNotFoundException)
        {
            return null;
        }

        if (nodeType.Equals(NodeType.File))
        {
            canCache = true;

            var query = StringUriUtils.BuildQuery
            (
                address.QueryValues,
                pair => pair.Key.Equals(QueryKey, StringComparison.CurrentCultureIgnoreCase)
            );

            var uri = address.AbsolutePath + "?" + query;

            var file = resolver.ResolveFile(uri);
            var service = file?.GetService(new TempIdentityFileServiceType(value)) as ITempIdentityFileService;

            canCache = true;

            return service?.GetTempFile();
        }

        return null;
    }
}