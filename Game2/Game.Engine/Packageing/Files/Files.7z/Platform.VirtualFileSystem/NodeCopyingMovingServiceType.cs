// ReSharper disable VirtualMemberCallInConstructor

using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public abstract class NodeCopyingMovingServiceType : ServiceType
{
    protected NodeCopyingMovingServiceType(INode destination, int bufferSize)
        : this(destination, false, bufferSize)
    {
    }

    protected NodeCopyingMovingServiceType(INode destination, bool overwrite = false)
        : this(destination, overwrite, 128 * 1024)
    {
    }

    protected NodeCopyingMovingServiceType(INode destination, bool overwrite, int bufferSize, int chunkSize = 128 * 1024)
    {
        Destination = destination;
        Overwrite = overwrite;
        BufferSize = bufferSize;
        ChunkSize = chunkSize;
    }

    public virtual int ChunkSize { get; set; }
    public virtual INode Destination { get; set; }
    public virtual bool Overwrite { get; set; }
    public virtual int BufferSize { get; set; }
}