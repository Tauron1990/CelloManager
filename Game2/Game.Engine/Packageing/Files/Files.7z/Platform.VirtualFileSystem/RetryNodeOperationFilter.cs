using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class RetryNodeOperationFilter : DefaultNodeOperationFilter
{
    private const int RetryCount = 1;

    public override INode? Delete(INode thisNode, out bool operationPerformed, Func<INode> defaultOperator)
    {
        INode? retval = null;

        ActionUtils.ToRetryAction<object?>(_ => retval = defaultOperator(), RetryCount)(null);

        operationPerformed = true;

        return retval;
    }
}