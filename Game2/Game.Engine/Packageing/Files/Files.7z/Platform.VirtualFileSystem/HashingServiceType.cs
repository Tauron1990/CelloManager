using JetBrains.Annotations;
// ReSharper disable VirtualMemberCallInConstructor

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public abstract class HashingServiceType : ServiceType, ICloneable
{
    private string? _algorithmName;

    protected HashingServiceType(Type serviceType, string algorithmName = "md5")
        : base(serviceType)
    {
        AlgorithmName = algorithmName;
    }


    public virtual string? AlgorithmName
    {
        get => string.IsNullOrEmpty(_algorithmName) ? "none" : _algorithmName;
        set => _algorithmName = value;
    }

    public virtual object Clone()
    {
        return Clone(AlgorithmName);
    }

    public virtual object Clone(string? newAlgorithmType)
    {
        var retval = (HashingServiceType)MemberwiseClone();

        retval.AlgorithmName = newAlgorithmType;

        return retval;
    }
}