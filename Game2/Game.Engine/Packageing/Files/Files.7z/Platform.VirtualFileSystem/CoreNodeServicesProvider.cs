using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public class CoreNodeServicesProvider : INodeServiceProvider
{

    public virtual IService? GetService(INode node, ServiceType serviceType) =>
        node switch
        {
            IFile file when serviceType is NodeCopyingMovingServiceType => serviceType switch
            {
                NodeCopyingServiceType type => new StandardFileCopyingService(file, type),
                NodeMovingServiceType type => new StandardFileMovingService(file, type),
                _ => throw new NotSupportedException(serviceType.GetType().Name)
            },
            IFile file when serviceType is StreamHashingServiceType type => new StandardStreamHashingService(file, type),
            IFile file when serviceType is NodeDeletingServiceType => new NodeBackedFileDeletingService(file, false),
            IFile file when serviceType is FileHashingServiceType type => new StandardFileHashingService(file, type),
            IFile file when serviceType is FileTransferServiceType type => new StandardFileTransferService(file, type),
            IFile file when serviceType is FileComparingServiceType type => new StandardFileComparingService(file, type),
            IFile file when serviceType is TempIdentityFileServiceType type => new StandardTempIdentityFileService(file, type),
            IDirectory directory when serviceType is DirectoryHashingServiceType type => new StandardDirectoryHashingService(directory, type),
            IDirectory when serviceType is NodeDeletingServiceType type => new NodeBackedFileDeletingService(node, type.Recursive),
            _ => null
        };
}