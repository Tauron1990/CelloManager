namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public interface INodeServiceProvider
{
    IService? GetService(INode node, ServiceType serviceType);
}