using System.Reflection;
using System.Text.RegularExpressions;
using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.View;
using JetBrains.Annotations;

// ReSharper disable CognitiveComplexity

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class StandardFileSystemManager : AbstractFileSystemManager
{
    private static readonly Regex FileSystemProviderRegex = new(@"Platform\.VirtualFileSystem\.Providers\.([^\.]+)\.dll");

    private readonly IList<INodeProvider> _providers;

    public StandardFileSystemManager()
        : this(false)
    {
    }

    public StandardFileSystemManager(bool scanAssembliesForProviders)
    {
        _providers = new List<INodeProvider>();

        if (scanAssembliesForProviders) ScanAssembliesAndAddProviders();
    }

    public override void CloseAllFileSystems()
    {
        foreach (var provider in _providers) (provider as ViewNodeProvider)?.ViewFileSystem.Close();
    }

    public void ScanAssembliesAndAddProviders()
    {
        var location = new Uri(GetType().Assembly.GetName().CodeBase ?? string.Empty);

        try
        {
            if (string.IsNullOrEmpty(location.LocalPath)) return;
        }
        catch (InvalidOperationException)
        {
            return;
        }

        var parent = Path.GetDirectoryName(location.LocalPath) ?? string.Empty;

        foreach (var path in Directory.GetFiles(parent))
        {
            var fileName = Path.GetFileName(path);
            var match = FileSystemProviderRegex.Match(fileName);

            if (match.Success)
            {
                var assembly = Assembly.LoadFrom(Path.Combine(parent, fileName));

                foreach (var type in assembly.GetTypes())
                    if (typeof(INodeProvider).IsAssignableFrom(type) && type.IsClass && !type.IsAbstract)
                        AddProvider((Activator.CreateInstance(type, this) as INodeProvider) ??
                                    throw new InvalidOperationException("Node Provider Creation Failed"));
            }
        }
    }

    /// <summary>
    ///     Add a file system provider to this manager.
    /// </summary>
    /// <remarks>
    ///     When a provider is added, its <c>SupportedUriSchemas</c> property is used to determine
    ///     which resolution requests will be forwarded to the provider.  If more than one provider
    ///     support the same schema, the most recently added provider will be used.
    /// </remarks>
    /// <param name="provider"></param>
    public virtual void AddProvider(INodeProvider provider) => _providers.Add(provider);

    public override void AddFileSystem(IFileSystem fileSystem)
    {
        var provider = new ViewNodeProvider(this, fileSystem);

        _providers.Add(provider);
    }

    public virtual void AddFileSystem(IFileSystem fileSystem, string scheme)
    {
        var provider = new ViewNodeProvider(this, fileSystem);

        _providers.Add(provider);
    }

    public override INode Resolve(string uri, NodeType nodeType, AddressScope scope, FileSystemOptions? options)
    {
        if (string.IsNullOrEmpty(uri))
            throw new ArgumentNullException(nameof(uri));

        if (uri[0] == ' ') uri = uri.Trim();

        if (uri.Length == 0) throw new ArgumentException(uri, nameof(uri));

        foreach (var provider in _providers.Where(provider => provider.SupportsUri(uri))) return provider.Find(this, uri, nodeType, options);

        throw new NotSupportedException(uri);
    }
}