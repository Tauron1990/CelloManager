using System.Security.Cryptography;
using System.Text;
using Game.Engine.Core;
using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class StandardTempIdentityFileService : AbstractService, ITempIdentityFileService
{
    private readonly IFile _file;
    private readonly IFile _tempFile;
    private TempIdentityFileServiceType _serviceType;

    public StandardTempIdentityFileService(IFile file, TempIdentityFileServiceType serviceType)
        : base(file)
    {
        IDirectory dir;

        var buffer = new StringBuilder(file.Address.Uri.Length * 2);

        _file = file;
        _serviceType = serviceType;

        buffer.Append("$TMP_ID_");
        buffer.Append(file.Name).Append('_');

        if (serviceType.TempFileSystem is null)
        {
            buffer.Append(TextConversion.ToBase32String(HashAlgorithm.Create("md5")!.ComputeHash(Encoding.ASCII.GetBytes(file.Address.Uri)))
                .Trim('='));
            buffer.Append('_');
        }

        var s = serviceType.UniqueIdentifier
            .Any(PredicateUtils.Not<char>(char.IsLetterOrDigit).AsFunc()) 
            ? TextConversion.ToBase32String(Encoding.ASCII.GetBytes(serviceType.UniqueIdentifier)).Trim('=') 
            : serviceType.UniqueIdentifier;

        buffer.Append(s);

        if (serviceType.TempFileSystem == null)
        {
            dir = file.ParentDirectory;

            _tempFile = dir?.ResolveFile(buffer.ToString());
        }
        else
        {
            var tempFileSystem = serviceType.TempFileSystem;

            dir = tempFileSystem.ResolveDirectory("/VFSTempIdentity");

            dir?.Create();

            _tempFile = dir?.ResolveFile(buffer.ToString());
        }
    }

    public virtual IFile GetTempFile() => _tempFile;

    public virtual IFile GetOriginalFile() => _file;

    public static bool IsTempIdentityFile(string name) => name.StartsWith("$TMP_ID");
}