using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public delegate void JumpPointEventHandler(object sender, JumpPointEventArgs eventArgs);

[PublicAPI]
public class JumpPointEventArgs : EventArgs
{
    public JumpPointEventArgs(string name, INode target, INode jumpPointNode)
    {
        Name = name;
        Target = target;
        JumpPointNode = jumpPointNode;
    }

    public string Name { get; }
    public INode Target { get; }
    public INode JumpPointNode { get; }
}