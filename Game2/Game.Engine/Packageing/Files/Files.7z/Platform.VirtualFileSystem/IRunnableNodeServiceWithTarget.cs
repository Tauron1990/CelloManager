using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

/// <summary>
/// </summary>
[PublicAPI]
public interface IRunnableNodeServiceWithTarget : IRunnableNodeService
{
    INode TargetNode { get; }
}