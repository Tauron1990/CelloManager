using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class DirectoryHashingServiceType : HashingServiceType
{
    public DirectoryHashingServiceType(bool recursive, string algorithmName = "md5")
        : base(typeof(IStreamHashingService), algorithmName)
    {
        // ReSharper disable VirtualMemberCallInConstructor
        Recursive = recursive;
        IncludedFileAttributes = Array.Empty<string>();
        IncludedDirectoryAttributes = Array.Empty<string>();

        FileFilter = static _ => true;
        DirectoryFilter = static _ => true;

        // ReSharper restore VirtualMemberCallInConstructor
    }

    public virtual bool Recursive { get; set; }

    public virtual Predicate<IFile> FileFilter { get; set; }

    public virtual IEnumerable<string> IncludedFileAttributes { get; set; }

    public virtual IEnumerable<string> IncludedDirectoryAttributes { get; set; }

    public virtual Predicate<IDirectory> DirectoryFilter { get; set; }
}