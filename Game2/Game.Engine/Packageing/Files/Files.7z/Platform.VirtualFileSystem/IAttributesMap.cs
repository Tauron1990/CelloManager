using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public interface IAttributesMap
{
    object this[string name] { get; set; }

    void SetAttribute(string name, object value);
    object GetAttribute(string name);
}