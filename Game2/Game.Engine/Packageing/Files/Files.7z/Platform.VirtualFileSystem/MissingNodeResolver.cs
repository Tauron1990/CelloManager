using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public delegate INode MissingNodeResolver(IFileSystem fileSystem, INodeAddress name, NodeType nodeType);