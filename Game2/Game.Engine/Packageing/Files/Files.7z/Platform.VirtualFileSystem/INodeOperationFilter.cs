namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public interface INodeOperationFilter
{
    INode CopyTo(INode thisNode, INode target, bool overwrite, out bool operationPerformed, Func<INode, bool, INode> defaultOperator);
    INode MoveTo(INode thisNode, INode target, bool overwrite, out bool operationPerformed, Func<INode, bool, INode> defaultOperator);
    INode Create(INode thisNode, bool createParent, out bool operationPerformed, Func<bool, INode> defaultOperator);
    INode Delete(INode thisNode, out bool operationPerformed, Func<INode> defaultOperator);
    INode RenameTo(INode thisNode, string name, bool overwrite, out bool operationPerformed, Func<string, bool, INode> defaultOperator);
}