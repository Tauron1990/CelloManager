using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public interface IDirectoryHashingService
    : IHashingService
{
    new IDirectory OperatingNode { get; }
}