using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class FileHashingServiceType : HashingServiceType
{
    public FileHashingServiceType()
        : this("md5")
    {
    }

    public FileHashingServiceType(string algorithmName)
        : base(typeof(IFileHashingService), algorithmName)
    {
    }
}