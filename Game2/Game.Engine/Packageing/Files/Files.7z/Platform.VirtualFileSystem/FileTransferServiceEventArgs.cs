using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using JetBrains.Annotations;
// ReSharper disable VirtualMemberCallInConstructor

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class FileTransferServiceEventArgs
{
    public FileTransferServiceEventArgs(TransferState lastTransferState, TransferState currentTransferState)
    {
        LastTransferState = lastTransferState;
        CurrentTransferState = currentTransferState;
    }

    public virtual TransferState LastTransferState { get; set; }

    public virtual TransferState CurrentTransferState { get; set; }
}