using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public interface IService
{
    string? Name { get; set; }
}