using Game.Engine.Threading;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public interface ITaskService : IService, ITask
{
}