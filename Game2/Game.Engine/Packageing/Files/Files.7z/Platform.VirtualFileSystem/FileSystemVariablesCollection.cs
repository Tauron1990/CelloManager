﻿using System.Collections.Specialized;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public class FileSystemVariablesCollection : NameValueCollection
{
    public FileSystemVariablesCollection() => IsReadOnly = true;

    public FileSystemVariablesCollection(NameValueCollection existingValues)
        : base(existingValues) =>
        IsReadOnly = true;

    public bool CollectionEquals(FileSystemVariablesCollection nameValueCollection) => ToKeyValue().SequenceEqual(nameValueCollection.ToKeyValue());

    private IEnumerable<KeyValuePair<string, string>> ToKeyValue()
        => from key in AllKeys.OrderBy(x => x)
            where !string.IsNullOrEmpty(key)
            select new KeyValuePair<string, string>(key, this[key]);
}