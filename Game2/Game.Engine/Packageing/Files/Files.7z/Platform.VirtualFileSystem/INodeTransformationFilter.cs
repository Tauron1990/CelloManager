namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public interface INodeTransformationFilter
{
    INode Filter(INode node);
}