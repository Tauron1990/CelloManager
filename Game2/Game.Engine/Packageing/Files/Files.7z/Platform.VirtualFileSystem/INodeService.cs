using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public interface INodeService : IService
{
    INode OperatingNode { get; }
}