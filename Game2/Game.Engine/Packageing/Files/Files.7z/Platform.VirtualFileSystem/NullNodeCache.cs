using System.Collections;
using JetBrains.Annotations;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class NullNodeCache : INodeCache
{
    public virtual IEnumerator GetEnumerator() => Array.Empty<object>().GetEnumerator();

    public void Add(INodeAddress address, INode node)
    {
    }

    public INode? Get(INodeAddress address, NodeType nodeType)
    {
        return null;
    }

    public void Purge()
    {
    }

    void INodeCache.Purge(INodeAddress address, NodeType nodeType)
    {
    }

    public void PurgeWithDescendents(INodeAddress address, NodeType nodeType)
    {
    }
}