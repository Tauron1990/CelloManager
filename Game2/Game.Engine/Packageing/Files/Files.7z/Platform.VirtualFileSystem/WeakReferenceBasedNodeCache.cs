using System.Collections;
using Game.Engine.Core;
using JetBrains.Annotations;
// ReSharper disable CognitiveComplexity

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public abstract class WeakReferenceBasedNodeCache<TK> : INodeCache where TK : notnull
{
    private const int DefaultCapacity = 1024;

    protected WeakReferenceBasedNodeCache()
        : this(DefaultCapacity)
    {
    }

    protected WeakReferenceBasedNodeCache(int capacity) => Cache = new WeakReferenceDictionary<TK, INode>(capacity);

    protected WeakReferenceDictionary<TK, INode> Cache { get; }

    public virtual IEnumerator GetEnumerator() => Cache.Values.GetEnumerator();

    public virtual void Add(INodeAddress address, INode node)
    {
        lock (SyncLock)
        {
            var key = GetKey(address, node?.NodeType);
            if(key is not null && node is not null)
                Cache[key] = node;
        }
    }

    public virtual INode? Get(INodeAddress address, NodeType nodeType)
    {
        lock (SyncLock)
        {
            if (Equals(nodeType, NodeType.None)) throw new ArgumentException("Can't be None", nameof(nodeType));

            if (Equals(nodeType, NodeType.Any))
            {
                var fileKey = GetKey(address, NodeType.File);
                if (fileKey is not null && Cache.TryGetValue(fileKey, out var node)) return node;

                var dicKey = GetKey(address, NodeType.Directory);
                if (dicKey is not null && Cache.TryGetValue(dicKey, out node)) return node;

                return 
                (
                    from node2 in Cache.Values
                    let key1 = GetKey(address, node2.NodeType)
                    let key2 = GetKey(node2.Address, node2.NodeType)
                    where key1 is not null && key1.Equals(key2)
                    select node2
                ).FirstOrDefault();
            }

            var key3 = GetKey(address, nodeType);
            if (key3 is not null && Cache.TryGetValue(key3, out var node3)) return node3;

            return null;
        }
    }

    public virtual void Purge()
    {
        lock (SyncLock) Cache.Clear();
    }

    public virtual void Purge(INodeAddress address, NodeType? nodeType)
    {
        lock (SyncLock)
        {
            var key = GetKey(address, nodeType);
            if(key is not null)
                Cache.Remove(key);
        }
    }

    public virtual void PurgeWithDescendents(INodeAddress address, NodeType nodeType) => Purge();

    public virtual object SyncLock => Cache;

    protected abstract TK? GetKey(INodeAddress? address, NodeType? nodeType);
}