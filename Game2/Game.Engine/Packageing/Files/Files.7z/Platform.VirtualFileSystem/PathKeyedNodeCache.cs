using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class PathKeyedNodeCache : WeakReferenceBasedNodeCache<Tuple<string, NodeType>>
{
    public PathKeyedNodeCache()
    {
    }

    public PathKeyedNodeCache(int maxsize)
        : base(maxsize)
    {
    }

    protected override Tuple<string, NodeType> GetKey(INodeAddress address, NodeType nodeType) => Tuple.Create(address.PathAndQuery, nodeType);
}