//

using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class MultipleTaskServicesServiceEventArgs : EventArgs
{
    public MultipleTaskServicesServiceEventArgs(ITaskService taskService) => TaskService = taskService;

    public virtual ITaskService TaskService { get; }
}

[PublicAPI]
public delegate void MultipleTaskServicesServiceEventHandler(object sender, MultipleTaskServicesServiceEventArgs eventArgs);