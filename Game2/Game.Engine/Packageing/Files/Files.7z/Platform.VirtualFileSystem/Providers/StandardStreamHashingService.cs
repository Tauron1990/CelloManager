using System.Security.Cryptography;
using Platform;
using Platform.IO;
using Platform.Text;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class StandardStreamHashingService
    : AbstractStreamHashingService
{
    private readonly HashAlgorithm hashAlgorithm;
    private IFile file;

    public StandardStreamHashingService(IFile file, StreamHashingServiceType serviceType)
        : base(file, serviceType)
    {
        this.file = file;
        hashAlgorithm = (HashAlgorithm)Activator.CreateInstance(ServiceType.AlgorithmType);
    }

    public override HashValue ComputeHash()
    {
        return ComputeHash(0, -1);
    }

    public override HashValue ComputeHash(long offset, long length)
    {
        MeteringStream stream;

        if (offset == 0 && length == -1 && !OperatingStream.CanSeek)
        {
            var retval = StandardFileHashingService.GetHashFromCache(OperatingNode, ServiceType.AlgorithmName);

            if (retval != null) return retval.Value;

            stream = new MeteringStream(OperatingStream);

            return new HashValue(hashAlgorithm.ComputeHash(stream), ServiceType.AlgorithmName, 0, Convert.ToInt32(stream.ReadMeter.Value));
        }

        if (offset == 0 && length == OperatingNode.Length)
            if (StandardFileHashingService.ConfigurationSection.Default.CanCacheHash(OperatingNode))
            {
                string s;

                if ((s = Convert.ToString(OperatingNode.Attributes["extended:" + ServiceType.AlgorithmName])) != "")
                    return new HashValue(TextConversion.FromHexString(s), ServiceType.AlgorithmName, 0, -1);
            }

        if (!OperatingStream.CanSeek) throw new NotSupportedException("ComputeHash_StreamCannotSeek");

        stream = new MeteringStream(new PartialStream(OperatingStream, offset, length));

        return new HashValue(hashAlgorithm.ComputeHash(stream), ServiceType.AlgorithmName, offset, Convert.ToInt64(stream.ReadMeter.Value));
    }
}