using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public abstract class AbstractService
    : IService
{
    private readonly AutoLock autoLock;

    protected AbstractService()
    {
        autoLock = new AutoLock(SyncLock);
    }

    public string Name => GetType().Name;

    public virtual object SyncLock => this;

    public virtual IAutoLock GetAutoLock()
    {
        return autoLock;
    }

    public virtual IAutoLock AquireAutoLock()
    {
        return GetAutoLock().Lock();
    }
}