using Platform;
using Platform.IO;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class StandardFileCopyingService
    : StreamCopier, INodeCopyingService, INodeMovingService, INodeDeletingService, StreamCopier.IStreamProvider
{
    public new static readonly int DefaultBufferSize = 32 * 1024;
    private readonly NodeCopyingServiceType serviceType;

    private readonly IFile sourceFile;

    public StandardFileCopyingService(IFile sourceFile, NodeCopyingServiceType serviceType)
        : base(true, true, 128)
    {
        this.sourceFile = sourceFile;
        this.serviceType = serviceType;

        if (this.serviceType.Destination.Equals(sourceFile))
            throw new ArgumentException(string.Format("Source and destination must not be the same: {0}", ServiceType.Destination.Address.Uri));

        InitializePump();
    }

    public virtual NodeCopyingServiceType ServiceType => serviceType;

    public virtual INode OperatingNode => sourceFile;

    public virtual INode TargetNode => ServiceType.Destination;

    public override void Run()
    {
        // The follow is not concurrent safe

        ServiceType.Destination.Refresh();
        sourceFile.Refresh();

        if (!ServiceType.Overwrite && ServiceType.Destination.Exists)
            throw new IOException(string.Format("The file already exists: {0}", ServiceType.Destination.Address));

        base.Run();
    }

    Stream IStreamProvider.GetSourceStream()
    {
        if (ServiceType.BufferSize == 0)
            return sourceFile.GetContent().GetInputStream();
        return new BufferedStream(sourceFile.GetContent().GetInputStream(), ServiceType.BufferSize);
    }

    Stream IStreamProvider.GetDestinationStream()
    {
        if (ServiceType.BufferSize == 0)
            return ServiceType.Destination.GetContent().GetOutputStream();
        return new BufferedStream(ServiceType.Destination.GetContent().GetOutputStream(), ServiceType.BufferSize);
    }

    long IStreamProvider.GetSourceLength()
    {
        return sourceFile.Length ?? 0;
    }

    long IStreamProvider.GetDestinationLength()
    {
        return ((IFile)ServiceType.Destination).Length ?? 0;
    }

    protected override void SetTaskState(TaskState newState)
    {
        if (newState == TaskState.Finished) return;

        base.SetTaskState(newState);
    }

    #region ISyncLocked Members

    public virtual object SyncLock => this;

    public virtual IAutoLock GetAutoLock()
    {
        return new AutoLock(this);
    }

    public virtual IAutoLock AquireAutoLock()
    {
        return GetAutoLock().Lock();
    }

    #endregion
}