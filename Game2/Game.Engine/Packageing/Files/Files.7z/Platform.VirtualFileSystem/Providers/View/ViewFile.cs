namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.View;

public class ViewFile
    : FileWrapper
{
    private readonly ViewNodeAddress address;

    public ViewFile(ViewFileSystem fileSystem, ViewNodeAddress address, IFile wrappee)
        : base(wrappee)
    {
        this.address = address;
        this.FileSystem = fileSystem;

        NodeResolver = new ViewResolver(fileSystem, Address);
        NodeAdapter = fileSystem.ViewNodeAdapter;
    }

    public override INodeAddress Address => address;

    public override IFileSystem FileSystem { get; }
}