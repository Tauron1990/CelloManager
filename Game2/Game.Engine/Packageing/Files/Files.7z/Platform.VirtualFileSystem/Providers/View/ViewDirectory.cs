using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.View;

public class ViewDirectory
    : DirectoryDelegationWrapper
{
    private readonly ViewNodeAddress address;
    private IDirectory parentDirectory;

    public ViewDirectory(ViewFileSystem fileSystem, ViewNodeAddress address, IDirectory wrappee)
        : base(wrappee)
    {
        this.address = address;
        this.FileSystem = fileSystem;

        NodeResolver = new ViewResolver(fileSystem, Address);
        NodeAdapter = fileSystem.ViewNodeAdapter;
    }

    public override INodeAddress Address => address;

    public override IFileSystem FileSystem { get; }

    public override IDirectory ParentDirectory
    {
        get
        {
            if (parentDirectory == null)
                lock (SyncLock)
                {
                    parentDirectory = FuncUtils.VolatileAssign(() => ResolveDirectory(".."));
                }

            return parentDirectory;
        }
    }

    public override string ToString()
    {
        return Address.Uri;
    }
}