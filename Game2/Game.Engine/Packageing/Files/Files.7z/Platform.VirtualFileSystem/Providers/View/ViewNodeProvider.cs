using Platform;
using Platform.Text;
using Platform.Xml.Serialization;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.View;

public class ViewNodeProvider
    : AbstractNodeProvider
{
    private readonly string[] schemes;
    private readonly IFileSystem viewFileSystem;

    public ViewNodeProvider(IFileSystemManager fileSystemManager, Configuration config)
        : this
        (
            fileSystemManager,
            config.Scheme,
            ResolveRootDirectory(fileSystemManager, config.Uri, config.Create),
            FileSystemOptions.Default,
            config
        )
    {
    }

    public ViewNodeProvider(IFileSystemManager fileSystemManager, string scheme, IDirectory root)
        : this(fileSystemManager, scheme, root, FileSystemOptions.Default)
    {
    }

    public ViewNodeProvider(IFileSystemManager fileSystemManager, string scheme, IDirectory root, FileSystemOptions? options)
        : this(fileSystemManager, scheme, root, options, null)
    {
    }

    public ViewNodeProvider(IFileSystemManager fileSystemManager, string scheme, IDirectory root, FileSystemOptions? options, Configuration config)
        : this(fileSystemManager, CreateViewFileSystem(scheme, root, options, config))
    {
    }


    public ViewNodeProvider(IFileSystemManager fileSystemManager, IFileSystem fileSystem)
        : base(fileSystemManager)
    {
        schemes = new[]
        {
            fileSystem.RootDirectory.Address.Scheme
        };

        viewFileSystem = fileSystem;
    }

    public virtual IFileSystem ViewFileSystem => viewFileSystem;

    public override string[] SupportedUriSchemas => (string[])schemes.Clone();

    private static IDirectory ResolveRootDirectory(INodeResolver resolver, string uri, bool create)
    {
        try
        {
            return create ? resolver.ResolveDirectory(uri).Create(true) : resolver.ResolveDirectory(uri);
        }
        catch (Exception e)
        {
            Console.Error.WriteLine(e);

            throw;
        }
    }

    private static IFileSystem CreateViewFileSystem(string scheme, IDirectory root, FileSystemOptions? options, Configuration config)
    {
        if (scheme.IsNullOrEmpty()) throw new ArgumentException(string.Empty, "scheme");

        if (config != null) options = options.CreateWithAdditionalConfig(config);

        var fileSystem = root.CreateView(scheme, options);

        return fileSystem;
    }

    public override INode Find(INodeResolver resolver, string uri, NodeType nodeType, FileSystemOptions? options)
    {
        var result = uri.SplitOnFirst("://");

        if (result.Left != viewFileSystem.RootDirectory.Address.Scheme) throw new NotSupportedException(result.Left);

        return viewFileSystem.Resolve(TextConversion.FromEscapedHexString(result.Right), nodeType);
    }

    [XmlElement("Options")]
    public class Configuration
        : NodeProviderConfiguration
    {
        public Configuration()
        {
            Create = false;
            Uri = Path.GetTempPath();
            Scheme = "";
        }

        public Configuration(string scheme, string uri, bool create)
        {
            Uri = uri;
            Scheme = scheme;
            Create = create;
        }

        [XmlElement]
        [XmlVariableSubstitution]
        public virtual string Scheme { get; protected set; }

        [XmlElement]
        [XmlVariableSubstitution]
        public virtual string Uri { get; protected set; }

        public virtual bool Create { get; protected set; }
    }
}