namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public abstract class DirectoryConsulatationWrapper
    : NodeConsultationWrapper, IDirectory
{
    private NodeActivityEventHandler DirectoryActivityEvent;
    private JumpPointEventHandler JumpPointAddedEvent;
    private JumpPointEventHandler JumpPointRemovedEvent;
    private NodeActivityEventHandler RecursiveActivityEvent;

    protected DirectoryConsulatationWrapper(IDirectory innerDirectory)
        : base(innerDirectory)
    {
    }

    public new virtual IDirectory Wrappee => (IDirectory)base.Wrappee;

    public virtual event NodeActivityEventHandler RecursiveActivity
    {
        add
        {
            lock (this)
            {
                if (RecursiveActivityEvent == null) Wrappee.Renamed += DelegateRecursiveActivityEvent;

                RecursiveActivityEvent = (NodeActivityEventHandler)Delegate.Combine(RecursiveActivityEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                RecursiveActivityEvent = (NodeActivityEventHandler)Delegate.Remove(RecursiveActivityEvent, value);

                if (RecursiveActivityEvent == null) Wrappee.Renamed -= DelegateRecursiveActivityEvent;
            }
        }
    }

    /// <summary>
    ///     Delegate DirectoryActivity event
    /// </summary>
    public virtual event NodeActivityEventHandler DirectoryActivity
    {
        add
        {
            lock (this)
            {
                if (DirectoryActivityEvent == null) Wrappee.Renamed += DelegateDirectoryActivityEvent;

                DirectoryActivityEvent = (NodeActivityEventHandler)Delegate.Combine(DirectoryActivityEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                DirectoryActivityEvent = (NodeActivityEventHandler)Delegate.Remove(DirectoryActivityEvent, value);

                if (DirectoryActivityEvent == null) Wrappee.Renamed -= DelegateDirectoryActivityEvent;
            }
        }
    }

    public virtual event JumpPointEventHandler JumpPointAdded
    {
        add
        {
            lock (this)
            {
                if (JumpPointAddedEvent == null) Wrappee.JumpPointAdded += DelegateJumpPointAddedEvent;

                JumpPointAddedEvent = (JumpPointEventHandler)Delegate.Combine(JumpPointAddedEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                JumpPointAddedEvent = (JumpPointEventHandler)Delegate.Remove(JumpPointAddedEvent, value);

                if (JumpPointAddedEvent == null) Wrappee.JumpPointAdded -= DelegateJumpPointAddedEvent;
            }
        }
    }

    public virtual event JumpPointEventHandler JumpPointRemoved
    {
        add
        {
            lock (this)
            {
                if (JumpPointRemovedEvent == null) Wrappee.JumpPointRemoved += DelegateJumpPointRemovedEvent;

                JumpPointRemovedEvent = (JumpPointEventHandler)Delegate.Combine(JumpPointRemovedEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                JumpPointRemovedEvent = (JumpPointEventHandler)Delegate.Remove(JumpPointRemovedEvent, value);

                if (JumpPointRemovedEvent == null) Wrappee.JumpPointRemoved -= DelegateJumpPointRemovedEvent;
            }
        }
    }

    public virtual IEnumerable<INode> Walk()
    {
        return Wrappee.Walk();
    }

    public virtual IEnumerable<INode> Walk(NodeType nodeType)
    {
        return Wrappee.Walk(nodeType);
    }

    public virtual IEnumerable<IFile> GetFiles()
    {
        return Wrappee.GetFiles();
    }

    public virtual IEnumerable<IFile> GetFiles(Predicate<IFile> acceptFile)
    {
        return Wrappee.GetFiles(acceptFile);
    }

    public virtual IEnumerable<IDirectory> GetDirectories()
    {
        return Wrappee.GetDirectories();
    }

    public virtual IEnumerable<IDirectory> GetDirectories(Predicate<IDirectory> acceptDirectory)
    {
        return Wrappee.GetDirectories(acceptDirectory);
    }

    public virtual bool ChildExists(string name)
    {
        return Wrappee.ChildExists(name);
    }

    public virtual IEnumerable<string> GetChildNames()
    {
        return Wrappee.GetChildNames();
    }

    public virtual IEnumerable<string> GetChildNames(NodeType nodeType)
    {
        return Wrappee.GetChildNames(nodeType);
    }

    public virtual IEnumerable<string> GetChildNames(Predicate<string> acceptName)
    {
        return Wrappee.GetChildNames(acceptName);
    }

    public virtual IEnumerable<string> GetChildNames(NodeType nodeType, Predicate<string> acceptName)
    {
        return Wrappee.GetChildNames(nodeType, acceptName);
    }

    public virtual IEnumerable<INode> GetChildren()
    {
        return Wrappee.GetChildren();
    }

    public virtual IEnumerable<INode> GetChildren(NodeType nodeType)
    {
        return Wrappee.GetChildren(nodeType);
    }

    public virtual IEnumerable<INode> GetChildren(Predicate<INode> acceptNode)
    {
        return Wrappee.GetChildren(acceptNode);
    }

    public virtual IEnumerable<INode> GetChildren(NodeType nodeType, Predicate<INode> acceptNode)
    {
        return GetChildren(nodeType, acceptNode);
    }

    public virtual IDirectory Delete(bool recursive)
    {
        Wrappee.Delete(recursive);

        return this;
    }

    IDirectory IDirectory.Create()
    {
        return Wrappee.Create();
    }

    IDirectory IDirectory.Create(bool createParent)
    {
        return Wrappee.Create(createParent);
    }

    public virtual IFileSystem CreateView()
    {
        return Wrappee.CreateView();
    }

    public virtual IFileSystem CreateView(string scheme, FileSystemOptions? options)
    {
        return Wrappee.CreateView(scheme, options);
    }

    public IFileSystem CreateView(string scheme)
    {
        return Wrappee.CreateView(scheme);
    }

    public IFileSystem CreateView(FileSystemOptions? options)
    {
        return Wrappee.CreateView(options);
    }

    public virtual INode? AddJumpPoint(INode node)
    {
        return Wrappee.AddJumpPoint(node);
    }

    public virtual INode? AddJumpPoint(string name, INode node)
    {
        return Wrappee.AddJumpPoint(name, node);
    }

    IDirectory IDirectory.Refresh()
    {
        return (IDirectory)Refresh();
    }

    public override INode? Refresh()
    {
        Refresh(DirectoryRefreshMask.All);

        return this;
    }

    public virtual IDirectory Refresh(DirectoryRefreshMask mask)
    {
        Wrappee.Refresh(mask);

        return this;
    }

    private void DelegateRecursiveActivityEvent(object sender, NodeActivityEventArgs eventArgs)
    {
        OnRecursiveActivityEvent(eventArgs);
    }

    protected void OnRecursiveActivityEvent(NodeActivityEventArgs eventArgs)
    {
        lock (this)
        {
            if (RecursiveActivityEvent != null) RecursiveActivityEvent(this, eventArgs);
        }
    }

    private void DelegateDirectoryActivityEvent(object sender, NodeActivityEventArgs eventArgs)
    {
        OnDirectoryActivityEvent(eventArgs);
    }

    protected void OnDirectoryActivityEvent(NodeActivityEventArgs eventArgs)
    {
        lock (this)
        {
            if (DirectoryActivityEvent != null) DirectoryActivityEvent(this, eventArgs);
        }
    }

    private void DelegateJumpPointAddedEvent(object sender, JumpPointEventArgs eventArgs)
    {
        OnJumpPointAddedEvent(eventArgs);
    }

    protected void OnJumpPointAddedEvent(JumpPointEventArgs eventArgs)
    {
        lock (this)
        {
            if (JumpPointAddedEvent != null) JumpPointAddedEvent(this, eventArgs);
        }
    }

    private void DelegateJumpPointRemovedEvent(object sender, JumpPointEventArgs eventArgs)
    {
        OnJumpPointRemovedEvent(eventArgs);
    }

    protected void OnJumpPointRemovedEvent(JumpPointEventArgs eventArgs)
    {
        lock (this)
        {
            if (JumpPointRemovedEvent != null) JumpPointRemovedEvent(this, eventArgs);
        }
    }
}