namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public abstract class AbstractNodeService
    : AbstractService, INodeService
{
    protected AbstractNodeService(INode operatingNode)
    {
        OperatingNode = operatingNode;
    }

    public virtual INode OperatingNode { get; }
}