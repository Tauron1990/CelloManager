using Game.Engine.Core;
using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.View;
using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

/// <summary>
///     This class provides a skeletal implementation of the <c>IDirectory </c>interface to minimize the effort
///     required to implement the interface.
///     <seealso cref="IDirectory" />
/// </summary>
[PublicAPI]
public abstract class AbstractDirectory : AbstractNode, IDirectory
{
    private readonly IDictionary<string, INode> _jumpPoints = new SortedDictionary<string, INode>(StringComparer.InvariantCultureIgnoreCase);
    private NodeActivityEventHandler? _directoryActivityEvent;
    private NodeActivityEventHandler? _recursiveActivityEvent;

    protected AbstractDirectory(IFileSystem fileSystem, INodeAddress address)
        : base(fileSystem, address)
    {
    }


    protected virtual bool InvokeRecursiveActivityRequired => _recursiveActivityEvent != null;

    public virtual event NodeActivityEventHandler RecursiveActivity
    {
        add
        {
            lock (this)
            {
                PreAddActivityEvent();

                _recursiveActivityEvent += value;

                PostAddActivityEvent();
            }
        }

        remove
        {
            lock (this)
            {
                PreRemoveActivityEvent();

                _recursiveActivityEvent -= value;

                PostRemoveActivityEvent();
            }
        }
    }

    public virtual event NodeActivityEventHandler DirectoryActivity
    {
        add
        {
            lock (this)
            {
                PreAddActivityEvent();

                _directoryActivityEvent += value;

                PostAddActivityEvent();
            }
        }

        remove
        {
            lock (this)
            {
                PreRemoveActivityEvent();

                _directoryActivityEvent -= value;

                PostRemoveActivityEvent();
            }
        }
    }

    IDirectory IDirectory.Create() => (IDirectory)Create();

    IDirectory IDirectory.Create(bool createParent) => (IDirectory)Create(createParent);

    IDirectory IDirectory.Refresh() => (IDirectory)Refresh();

    public override INode Refresh()
    {
        Refresh(DirectoryRefreshMask.All);

        return this;
    }

    public virtual IDirectory Refresh(DirectoryRefreshMask mask)
    {
        if ((mask & DirectoryRefreshMask.Attributes) != 0) base.Refresh();

        return this;
    }

    public override NodeType NodeType => NodeType.Directory;

    public virtual IEnumerable<INode> Walk() => Walk(NodeType.Any);

    public virtual IEnumerable<INode> Walk(NodeType nodeType) => Walk(this, nodeType);

    public virtual bool ChildExists(string name) => Resolve(name).Exists;

    public virtual IEnumerable<IFile> GetFiles() => GetChildren(NodeType.File).Cast<IFile>();

    public virtual IEnumerable<IFile> GetFiles(Predicate<IFile> acceptFile) => GetChildren(NodeType.File).Where(node => acceptFile((IFile)node)).Cast<IFile>();

    public virtual IEnumerable<IDirectory> GetDirectories() => GetChildren(NodeType.Directory).Cast<IDirectory>();

    public virtual IEnumerable<IDirectory> GetDirectories(Predicate<IDirectory> acceptDirectory) => GetChildren(NodeType.Directory).Where(node => acceptDirectory((IDirectory)node)).Cast<IDirectory>();

    public virtual IEnumerable<INode> GetChildren() => GetChildren(NodeType.Any, NodeFilters.Any);

    public virtual IEnumerable<INode> GetChildren(NodeType nodeType) => GetChildren(nodeType, NodeFilters.Any);

    public virtual IEnumerable<INode> GetChildren(Predicate<INode> acceptNode) => GetChildren(NodeType.Any, acceptNode);

    public virtual IEnumerable<INode> GetChildren(NodeType nodeType, Predicate<INode> acceptNode)
    {
        if (!FileSystem.SecurityManager.CurrentContext.HasAccess(new AccessVerificationContext(this, FileSystemSecuredOperation.List))) yield break;

        foreach (var node in DoGetChildren(nodeType, acceptNode))
            if (FileSystem.SecurityManager.CurrentContext.HasAccess(new AccessVerificationContext(node, FileSystemSecuredOperation.View)))
                yield return node;
    }

    public virtual IEnumerable<string> GetChildNames() => GetChildNames(NodeType.Any);

    public virtual IEnumerable<string> GetChildNames(NodeType nodeType) => GetChildNames(nodeType, PredicateUtils<string>.AlwaysTrue);

    public virtual IEnumerable<string> GetChildNames(Predicate<string> acceptName) => GetChildNames(NodeType.Any, acceptName);

    public virtual IEnumerable<string> GetChildNames(NodeType nodeType, Predicate<string> acceptName) => GetChildNamesUsingNodes(nodeType, NodeFilters.ByNodeName(acceptName));

    public virtual IDirectory Delete(bool recursive) => DoDelete(recursive);

    public override IDirectory OperationTargetDirectory => this;

    public virtual IFileSystem CreateView() => CreateView(Address.Scheme);

    public virtual IFileSystem CreateView(FileSystemOptions? options) => DoCreateView(Address.Scheme, options);

    public virtual IFileSystem CreateView(string scheme) => CreateView(scheme, FileSystem.Options);

    public virtual IFileSystem CreateView(string scheme, FileSystemOptions? options) => DoCreateView(scheme, options);

    public override INode Resolve(string name, NodeType nodeType, AddressScope scope)
    {
        var nodeAddress = base.ResolveAddress(name, scope);

        if (nodeAddress.IsDescendentOf(Address, AddressScope.Descendent))
        {
            if (_jumpPoints.TryGetValue(name, out var jumpPointNode))
            {
                var relativePath = Address.GetRelativePathTo(nodeAddress);

                if (relativePath == name)
                    return jumpPointNode;
                if (Equals(jumpPointNode.NodeType, NodeType.Directory)) return jumpPointNode.Resolve(relativePath);
            }
        }

        return base.Resolve(nodeAddress, nodeType, scope);
    }

    public override INode GetDirectoryOperationTargetNode(IDirectory directory) => directory;

    protected virtual void OnRecursiveActivity(NodeActivityEventArgs eventArgs) => _recursiveActivityEvent?.Invoke(this, eventArgs);

    protected virtual void OnDirectoryActivity(NodeActivityEventArgs eventArgs) => _directoryActivityEvent?.Invoke(this, eventArgs);

    protected virtual bool ContainsShortcut(string name, NodeType nodeType)
    {
        if (Equals(nodeType, NodeType.Any)) return _jumpPoints.ContainsKey(name);

        return _jumpPoints.TryGetValue(name, out var node) && node.NodeType.Is(nodeType);
    }

    public virtual IEnumerable<INode> GetJumpPoints(NodeType nodeType) => GetJumpPoints(nodeType, PredicateUtils<INode>.AlwaysTrue);

    public virtual IEnumerable<INode> GetJumpPoints(NodeType nodeType, Predicate<INode> acceptJumpPoint) => _jumpPoints.Values.Where(node => node.NodeType.Is(nodeType) || Equals(nodeType, NodeType.Any)).Where(node => acceptJumpPoint(node));

    public virtual void DeleteAllJumpPoints()
    {
        lock (SyncLock)
        {
            foreach (var name in GetJumpPointNames(NodeType.Any).ToArray()) 
                _jumpPoints.Remove(name);
        }
    }

    public virtual void DeleteJumpPoint(string name, NodeType nodeType)
    {
        lock (SyncLock)
        {
            if (!_jumpPoints.TryGetValue(name, out var node)) return;

            _jumpPoints.Remove(name);

            OnJumpPointRemoved(new JumpPointEventArgs(name, node, node));
        }
    }

    public virtual IEnumerable<string> GetJumpPointNames(NodeType nodeType) => GetJumpPointNames(nodeType, PredicateUtils<string>.AlwaysTrue);

    public virtual IEnumerable<string> GetJumpPointNames(NodeType nodeType, Predicate<string> acceptJumpPoint)
    {
        if (Equals(nodeType, NodeType.Any))
        {
            foreach (var name in _jumpPoints.Keys.Where(acceptJumpPoint.AsFunc()))
                yield return name;
        }
        else
        {
            foreach (var name in 
                     from pair in _jumpPoints
                     where pair.Value.NodeType.Is(nodeType) && acceptJumpPoint(pair.Key)
                     select pair.Key)
                yield return name;
        }
    }

    public static IEnumerable<INode> Walk(IDirectory directory, NodeType nodeType)
    {
        var accept = NodeFilters.ByNodeType(nodeType);

        foreach (var childNode in directory.GetChildren())
        {
            if (accept(childNode)) yield return childNode;

            if (childNode is IDirectory node)
                foreach (var childChildNode in Walk(node, nodeType))
                    yield return childChildNode;
        }
    }

    protected virtual bool AcceptsRecursiveActivity(FileSystemActivityEventArgs eventArgs) => eventArgs.Path.Length != Address.AbsolutePath.Length && FileSystem.PathsEqual(eventArgs.Path, Address.AbsolutePath, Address.AbsolutePath.Length);

    protected virtual bool AcceptsDirectoryActivity(FileSystemActivityEventArgs eventArgs)
    {
        if (eventArgs.Path.Length == Address.AbsolutePath.Length) return false;

        var x = eventArgs.Path.CountChars(c => c == '/');

        switch (x)
        {
            case 1:
                return true;
            case 0:
                return false;
            default:
                x = eventArgs.Path.LastIndexOf('/');

                return FileSystem.PathsEqual(eventArgs.Path, Address.AbsolutePath, x);
        }
    }

    protected override void FileSystem_Activity(object sender, FileSystemActivityEventArgs eventArgs)
    {
        INode? node = null;

        if (AcceptsDirectoryActivity(eventArgs))
        {
            node = FileSystem.Resolve(eventArgs.Path, eventArgs.NodeType);

            if (eventArgs is FileSystemRenamedActivityEventArgs args)
                OnDirectoryActivity(new NodeActivityEventArgs(args.Activity, node, args.NewName));
            else
                OnDirectoryActivity(new NodeActivityEventArgs(eventArgs.Activity, node));
        }

        if (AcceptsRecursiveActivity(eventArgs) && InvokeRecursiveActivityRequired)
        {
            node ??= FileSystem.Resolve(eventArgs.Path, eventArgs.NodeType);

            OnRecursiveActivity(eventArgs is FileSystemRenamedActivityEventArgs args
                ? new NodeActivityEventArgs(args.Activity, node, args.NewName)
                : new NodeActivityEventArgs(eventArgs.Activity, node));
        }

        base.FileSystem_Activity(sender, eventArgs);
    }

    public abstract IEnumerable<INode> DoGetChildren(NodeType nodeType, Predicate<INode> acceptNode);

    private IEnumerable<string> GetChildNamesUsingNodes(NodeType nodeType, Predicate<INode> acceptNode) => GetChildren(nodeType, acceptNode).Select(node => node.Name);

    protected virtual IDirectory DoDelete(bool recursive) => throw new NotSupportedException();

    protected virtual IFileSystem DoCreateView(string scheme, FileSystemOptions? options) => new ViewFileSystem(scheme, this, options);


    #region JumpPoint

    public virtual event JumpPointEventHandler? JumpPointAdded;

    public virtual void OnJumpPointAdded(JumpPointEventArgs eventArgs) => JumpPointAdded?.Invoke(this, eventArgs);

    public virtual event JumpPointEventHandler? JumpPointRemoved;

    public virtual void OnJumpPointRemoved(JumpPointEventArgs eventArgs) => JumpPointRemoved?.Invoke(this, eventArgs);

    public virtual INode AddJumpPoint(INode targetNode) => AddJumpPoint(targetNode.Name, targetNode);

    public virtual INode AddJumpPoint(string name, INode targetNode)
    {
        INode? jumpPointNode;

        if (Equals(targetNode.NodeType, NodeType.File))
            jumpPointNode = new JumpPointFile((IFile)targetNode, Address.ResolveAddress(name));
        else if (Equals(targetNode.NodeType, NodeType.Directory))
            jumpPointNode = new JumpPointDirectory((IDirectory)targetNode, Address.ResolveAddress(name));
        else
            throw new NotSupportedException(targetNode.NodeType.ToString());

        if (_jumpPoints.ContainsKey(name))
        {
            OnJumpPointRemoved(new JumpPointEventArgs(name, targetNode, jumpPointNode));

            _jumpPoints.Remove(name);
        }

        _jumpPoints.Add(name, jumpPointNode);

        OnJumpPointAdded(new JumpPointEventArgs(name, targetNode, jumpPointNode));

        return jumpPointNode;
    }

    #endregion
}