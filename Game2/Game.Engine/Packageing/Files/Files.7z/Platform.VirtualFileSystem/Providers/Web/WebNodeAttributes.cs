namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Web;

public class WebNodeAttributes
    : AbstractTypeBasedNodeAttributes
{
    protected AbstractNode node;

    public WebNodeAttributes(AbstractNode node)
        : base(node)
    {
        this.node = node;
    }

    public override DateTime? LastAccessTime => DateTime.Now;

    public override DateTime? LastWriteTime => DateTime.Now;
}