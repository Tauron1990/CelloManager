namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Web;

public class WebNodeProvider
    : AbstractMultiFileSystemNodeProvider
{
    public WebNodeProvider(IFileSystemManager manager)
        : base(manager)
    {
    }

    public override string[] SupportedUriSchemas
    {
        get
        {
            return new[]
            {
                Uri.UriSchemeHttp,
                Uri.UriSchemeHttps,
                Uri.UriSchemeFtp
            };
        }
    }

    protected override INodeAddress ParseUri(string uri)
    {
        return StandardNodeAddress.Parse(uri);
    }

    protected override IFileSystem NewFileSystem(INodeAddress rootAddress, FileSystemOptions? options, out bool cache)
    {
        cache = true;

        return new WebFileSystem(rootAddress, options);
    }
}