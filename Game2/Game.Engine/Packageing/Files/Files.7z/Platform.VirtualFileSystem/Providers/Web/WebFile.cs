using System.Text.RegularExpressions;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Web;

public class WebFile
    : AbstractFile
{
    private static readonly Regex charsetRegex;
    private long contentLength = -1;
    private DateTime? creationDate;

    private bool exists;

    static WebFile()
    {
        charsetRegex = new Regex(@".*charset[=]([^ ;]*)", RegexOptions.Compiled);
    }

    public WebFile(WebFileSystem fileSystem, INodeAddress name)
        : base(name, fileSystem)
    {
    }

    public override bool SupportsActivityEvents => false;

    protected override Stream DoGetInputStream(string contentName, out string encoding, FileMode mode, FileShare sharing)
    {
        return WebFileSystem.DoGetInputStream(this, contentName, out encoding, mode, sharing, out creationDate, out exists, out contentLength);
    }

    protected override Stream DoGetOutputStream(string contentName, string? encoding, FileMode mode, FileShare sharing)
    {
        return WebFileSystem.DoGetOutputStream(this, contentName, encoding, mode, sharing);
    }

    protected override INodeAttributes CreateAttributes()
    {
        return new AutoRefreshingNodeAttributes(new WebFileAttributes(this), 1);
    }

    public override INode Delete()
    {
        throw new NotSupportedException("WebFile.Delete");
    }

    public class WebFileAttributes
        : AbstractTypeBasedFileAttributes
    {
        private readonly WebFile webFile;

        public WebFileAttributes(WebFile webFile)
            : base(webFile)
        {
            this.webFile = webFile;
        }

        public override long? Length => webFile.contentLength;

        public override DateTime? CreationTime
        {
            get => webFile.creationDate;
            set { }
        }

        public override DateTime? LastWriteTime
        {
            get => webFile.creationDate;
            set { }
        }

        public override bool Exists => webFile.exists;

        public override INodeAttributes Refresh()
        {
            lock (webFile)
            {
                try
                {
                    webFile.GetContent().GetInputStream();

                    webFile.exists = true;
                }
                catch (FileNotFoundException)
                {
                    webFile.exists = false;
                }
            }

            return this;
        }
    }
}