using System.Collections.Specialized;
using System.Text;
using Game.Engine.Core;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

/// <summary>
///     This class provides a skeletal implementation of the <c>INodeAddress</c>interface to minimize the effort
///     required to implement the interface.
///     <seealso cref="INodeAddress" />
/// </summary>
[Serializable]
public abstract class AbstractNodeAddress : INodeAddress
{
    private readonly string _absolutePath;
    private int _depth = -1;
    private string? _extension;
    private string? _nameAndQuery;
    private string? _nameWithoutQuery;
    private string? _pathAndQuery;
    private NameValueCollection? _queryValues;
    private string? _rootUri;

    // Cached calculated values.

    private string? _uri;

    /// <summary>
    ///     Initialises a new <see cref="AbstractNodeAddress" />.
    /// </summary>
    /// <param name="scheme">The scheme of the <c>FileName</c>.</param>
    /// <param name="absolutePath">The <c>AbsolutePath</c> of the <c>FileName</c>.</param>
    /// <param name="query"></param>
    protected AbstractNodeAddress(string scheme, string absolutePath, string query)
    {
        Scheme = scheme;
        _absolutePath = absolutePath;
        Query = query;
    }

    public virtual string InnerUri => "";

    public virtual string Name => NameAndQuery;

    public virtual string NameWithoutExtension
    {
        get
        {
            var s = ShortName;

            var x = s.LastIndexOf('.');

            return x >= 0 ? s[..x] : s;
        }
    }

    public virtual string NameWithoutQuery
    {
        get
        {
            if (_nameWithoutQuery is not null) return _nameWithoutQuery;
            
            lock (this)
                _nameWithoutQuery = IsRoot
                    ? _absolutePath
                    : TextConversion.FromEscapedHexString(
                        _absolutePath.Right(PredicateUtils.ObjectEquals(FileSystemManager.SeperatorChar).Not()));

            return _nameWithoutQuery;
        }
    }

    public virtual string NameAndQuery
    {
        get
        {
            if (_nameAndQuery is not null) return _nameAndQuery;
            lock (this)
            {
                if (_nameAndQuery is null)
                {
                    var nameAndQuery = ShortName + (Query.Length > 0 ? '?' + Query : "");

                    Thread.MemoryBarrier();

                    _nameAndQuery = nameAndQuery;
                }
            }

            return _nameAndQuery;
        }
    }

    public virtual string Query { get; private set; }

    public virtual NameValueCollection QueryValues
    {
        get
        {
            if (_queryValues is not null) return _queryValues;
            lock (this)
            {
                if (_queryValues is null)
                {
                    var dictionary = new NameValueCollection(StringComparer.InvariantCultureIgnoreCase);

                    foreach (var pair in StringUriUtils.ParseQuery(Query)) dictionary[pair.Key] = pair.Value;

                    Thread.MemoryBarrier();

                    _queryValues = dictionary;
                }
            }

            return _queryValues;
        }
    }

    public virtual string PathAndQuery
    {
        get
        {
            if (_pathAndQuery is null)
                lock (this)
                {
                    if (_pathAndQuery is null)
                    {
                        var localPathAndQuery = Query == "" ? AbsolutePath : AbsolutePath + '?' + Query;

                        Thread.MemoryBarrier();

                        _pathAndQuery = localPathAndQuery;
                    }
                }

            return _pathAndQuery;
        }
    }

    public virtual string ShortName => NameWithoutQuery;

    public virtual string AbsolutePath => _absolutePath;

    public virtual string Extension
    {
        get
        {
            if (_extension == null)
                lock (this)
                {
                    _extension = ShortName.Right(PredicateUtils.ObjectEquals('.').Not());

                    if (_extension.Length == ShortName.Length) _extension = string.Empty;
                }

            return _extension;
        }
    }

    public virtual int Depth
    {
        get
        {
            if (IsRoot) return 0;

            if (_depth == -1)
                Interlocked.Exchange(ref _depth, _absolutePath.CountChars(c => c == FileSystemManager.SeperatorChar));

            return _depth;
        }
    }

    public virtual string Scheme { get; }

    public virtual string Uri
    {
        get
        {
            if (_uri is not null) return _uri;
            lock (this)
            {
                if (_uri is null)
                {
                    var value = RootUri + _absolutePath + (Query == "" ? "" : "?" + Query);

                    value = TextConversion.ToEscapedHexString(value, TextConversion.IsStandardUrlEscapedChar);

                    Thread.MemoryBarrier();

                    _uri = value;
                }
            }

            return _uri;
        }
    }

    public virtual string RootUri
    {
        get
        {
            if (_rootUri is not null) return _rootUri;
            lock (this)
            {
                if (_rootUri is null)
                {
                    var value = GetRootUri();

                    Thread.MemoryBarrier();

                    _rootUri = value;
                }
            }

            return _rootUri;
        }
    }

    public virtual bool IsRoot =>
        _absolutePath.Length == 1
        && _absolutePath[0] == FileSystemManager.SeperatorChar;

    public virtual INodeAddress Parent
    {
        get
        {
            if (IsRoot) throw new InvalidOperationException("Root directory has no parent");

            lock (this)
            {
                var parentPath = AbsolutePath.SplitAroundCharFromRight(PredicateUtils.ObjectEquals('/')).Left;

                if (parentPath.Length == 0) parentPath = FileSystemManager.SeperatorString;

                return CreateAddress(parentPath, "");
            }
        }
    }

    public virtual INodeAddress ResolveAddress(string name) => ResolveAddress(name, AddressScope.FileSystem);

    public virtual INodeAddress ResolveAddress(string name, AddressScope scope)
    {
        int x;
        var query = "";

        if (name.Length == 0 || (name.Length > 0 && name[0] != FileSystemManager.RootChar))
        {
            // Path is relative.

            if (IsRoot)
                name = FileSystemManager.RootChar + name;
            else
                name = _absolutePath + FileSystemManager.SeperatorChar + name;
        }

        if ((x = name.IndexOf('?')) >= 0)
        {
            query = name.Substring(x + 1);
            name = name.Substring(0, x);
        }

        name = StringUriUtils.NormalizePath(name);

        if (!CheckPathScope(AbsolutePath, name, scope)) throw new AddressScopeValidationException(name, scope);

        return CreateAddress(name, query);
    }

    public virtual string GetRelativePathTo(INodeAddress name)
    {
        if (!RootUri.Equals(name.RootUri)) throw new ArgumentOutOfRangeException(name.ToString());

        return GetRelativePathTo(name.AbsolutePath);
    }

    // ReSharper disable once CognitiveComplexity
    public virtual string GetRelativePathTo(string absolutePath)
    {
        var pathLen = absolutePath.Length;
        var basePathLen = _absolutePath.Length;

        // When base path is root

        if (basePathLen == 1)
            return pathLen == 1 ? "." : absolutePath[1..];

        var pos = 0;
        var maxLen = Math.Min(basePathLen, pathLen);

        for (; pos < maxLen && _absolutePath[pos] == absolutePath[pos]; pos++)
        {
            // Just counting.
        }

        if (pos == basePathLen && pos == pathLen)
            // Same names.

            //return path;
            return ".";
        if (pos == basePathLen && pos < pathLen && absolutePath[pos] == FileSystemManager.SeperatorChar)
            // path is a descendent.

            return absolutePath[(pos + 1)..];

        var builder = new StringBuilder(absolutePath.Length);

        if (pathLen > 1 && (pos < pathLen || _absolutePath[pos] != FileSystemManager.SeperatorChar))
        {
            // Not a direct ancestor.  Trace backwards.

            pos = _absolutePath.LastIndexOf(FileSystemManager.SeperatorChar, pos);

            builder.Append(absolutePath[pos..]);
        }

        // Prepend '../' for each elementin the base path past the common prefix.
        builder.Insert(0, "..");

        pos = _absolutePath.IndexOf(FileSystemManager.SeperatorChar, pos + 1);

        while (pos != -1)
        {
            builder.Insert(0, "../");
            pos = _absolutePath.IndexOf(FileSystemManager.SeperatorChar, pos + 1);
        }

        return builder.ToString();
    }

    public virtual bool IsAncestorOf(INodeAddress name) => name.IsDescendentOf(this, AddressScope.Descendent);

    public virtual bool IsDescendentOf(INodeAddress name) => IsDescendentOf(name, AddressScope.Descendent);

    public virtual bool IsDescendentOf(INodeAddress name, AddressScope scope) => CheckPathScope(name.AbsolutePath, AbsolutePath, scope);

    public virtual bool IsDescendentOf(INodeAddress name, StringComparison comparisonType, AddressScope scope) => CheckPathScope(name.AbsolutePath, AbsolutePath, comparisonType, scope);

    public virtual bool RootsAreEqual(INodeAddress nodeAddress) => RootUri == nodeAddress.RootUri;

    public virtual bool ParentsEqual(INodeAddress nodeAddress) => ParentsEqual(nodeAddress, StringComparison.CurrentCulture);

    public virtual bool ParentsEqual(INodeAddress nodeAddress, StringComparison comparisonType)
    {
        if (Depth != nodeAddress.Depth) return false;

        if (IsRoot) return true;

        var x = AbsolutePath.LastIndexOf('/');
        var y = nodeAddress.AbsolutePath.LastIndexOf('/');

        if (x == -1) return false;

        return x == y && string.Equals(AbsolutePath[..x], nodeAddress.AbsolutePath[..y]);
    }

    public virtual string PathToDepth(int depth)
    {
        if (depth == 0) return "/";

        depth++;

        var builder = new StringBuilder();

        foreach (var c in AbsolutePath)
        {
            if (c == '/')
            {
                depth--;

                if (depth == 0) break;
            }

            builder.Append(c);
        }

        return builder.ToString();
    }

    public virtual string DisplayUri => TextConversion.FromEscapedHexString(Uri);

    private bool CheckPathScope(string basePath, string comparePath, AddressScope scope)
    {
        return CheckPathScope(basePath, comparePath, StringComparison.CurrentCulture, scope);
    }

    // ReSharper disable once CognitiveComplexity
    private bool CheckPathScope(string basePath, string comparePath, StringComparison comparisonType, AddressScope scope)
    {
        if (scope == AddressScope.FileSystem) return true;

        if (!comparePath.StartsWith(basePath, comparisonType)) return false;

        var baseLength = basePath.Length;

        switch (scope)
        {
            case AddressScope.Child:

                if ( /* ComparePath is the same as BasePath */
                    comparePath.Length == baseLength
                    /* ComparePath has same parent as base path but different short name */
                    || (baseLength > 1 && comparePath[baseLength] != FileSystemManager.SeperatorChar)
                    /* ComparePath is a (grand)*child of basePath */
                    || comparePath.IndexOf(FileSystemManager.SeperatorChar, baseLength + 1) >= 0)
                    return false;

                break;

            case AddressScope.Descendent:

                if ( /* ComparePath is the same as base path */
                    comparePath.Length == baseLength
                    /* ComparePath has same parent as base path but different short name */
                    || (baseLength > 1 && comparePath[baseLength] != FileSystemManager.SeperatorChar))
                    return false;

                break;

            case AddressScope.DescendentOrSelf:

                if (
                    /* ComparePath has same parent as base path but different short name */
                    baseLength > 1
                    && comparePath.Length > baseLength
                    && comparePath[baseLength] != FileSystemManager.SeperatorChar)
                    return false;

                break;

            default:

                return false;
        }

        return true;
    }

    /// <summary>
    ///     Create and return a new filename of the same type and schema as this file name
    ///     but but with a different path.
    /// </summary>
    /// <remarks>
    ///     The only difference between the current <c>INodeAddress</c> and the returned
    ///     <c>INodeAddress</c> is the path.
    /// </remarks>
    /// <param name="absolutePath">The absolute path to the node</param>
    /// <param name="query">The query part of the path (empty string if there is no query part)</param>
    /// <returns></returns>
    protected abstract INodeAddress CreateAddress(string absolutePath, string query);

    /// <summary>
    ///     Gets a string representing the root URI of the filesytem this filename belongs to.
    /// </summary>
    /// <returns></returns>
    protected abstract string GetRootUri();

    public override string ToString() => TextConversion.FromEscapedHexString(Uri);

    public override int GetHashCode() => RootUri.GetHashCode() ^ _absolutePath.GetHashCode();

    public override bool Equals(object? obj)
    {
        if (obj == this) return true;

        return obj is AbstractNodeAddress address && Uri.Equals(address.Uri);
    }
}