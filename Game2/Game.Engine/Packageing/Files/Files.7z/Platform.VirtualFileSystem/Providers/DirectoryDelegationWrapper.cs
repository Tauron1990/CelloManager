using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public abstract class DirectoryDelegationWrapper
    : NodeDelegationWrapper, IDirectory
{
    private NodeActivityEventHandler DirectoryActivityEvent;
    private JumpPointEventHandler JumpPointAddedEvent;
    private JumpPointEventHandler JumpPointRemovedEvent;
    private NodeActivityEventHandler RecursiveActivityEvent;

    protected DirectoryDelegationWrapper(IDirectory innerDirectory)
        : base(innerDirectory)
    {
    }

    protected DirectoryDelegationWrapper(IDirectory innerDirectory, INodeResolver resolver, Converter<INode, INode> nodeAdapter)
        : base(innerDirectory, resolver, nodeAdapter)
    {
    }

    public new virtual IDirectory Wrappee => (IDirectory)base.Wrappee;

    public virtual event NodeActivityEventHandler RecursiveActivity
    {
        add
        {
            lock (this)
            {
                if (RecursiveActivityEvent == null) Wrappee.Renamed += DelegateRecursiveActivityEvent;

                RecursiveActivityEvent = (NodeActivityEventHandler)Delegate.Combine(RecursiveActivityEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                RecursiveActivityEvent = (NodeActivityEventHandler)Delegate.Remove(RecursiveActivityEvent, value);

                if (RecursiveActivityEvent == null) Wrappee.Renamed -= DelegateRecursiveActivityEvent;
            }
        }
    }

    public virtual event NodeActivityEventHandler DirectoryActivity
    {
        add
        {
            lock (this)
            {
                if (DirectoryActivityEvent == null) Wrappee.Renamed += DelegateDirectoryActivityEvent;

                DirectoryActivityEvent = (NodeActivityEventHandler)Delegate.Combine(DirectoryActivityEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                DirectoryActivityEvent = (NodeActivityEventHandler)Delegate.Remove(DirectoryActivityEvent, value);

                if (DirectoryActivityEvent == null) Wrappee.Renamed -= DelegateDirectoryActivityEvent;
            }
        }
    }

    public virtual event JumpPointEventHandler JumpPointAdded
    {
        add
        {
            lock (this)
            {
                if (JumpPointAddedEvent == null) Wrappee.JumpPointAdded += DelegateJumpPointAddedEvent;

                JumpPointAddedEvent = (JumpPointEventHandler)Delegate.Combine(JumpPointAddedEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                JumpPointAddedEvent = (JumpPointEventHandler)Delegate.Remove(JumpPointAddedEvent, value);

                if (JumpPointAddedEvent == null) Wrappee.JumpPointAdded -= DelegateJumpPointAddedEvent;
            }
        }
    }

    public virtual event JumpPointEventHandler JumpPointRemoved
    {
        add
        {
            lock (this)
            {
                if (JumpPointRemovedEvent == null) Wrappee.JumpPointRemoved += DelegateJumpPointRemovedEvent;

                JumpPointRemovedEvent = (JumpPointEventHandler)Delegate.Combine(JumpPointRemovedEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                JumpPointRemovedEvent = (JumpPointEventHandler)Delegate.Remove(JumpPointRemovedEvent, value);

                if (JumpPointRemovedEvent == null) Wrappee.JumpPointRemoved -= DelegateJumpPointRemovedEvent;
            }
        }
    }

    public virtual IEnumerable<INode> Walk()
    {
        if (NodeAdapter == ConverterUtils<INode, INode>.NoConvert)
            return Wrappee.Walk();
        return AdaptedWalk();
    }

    IDirectory IDirectory.Refresh()
    {
        return (IDirectory)Refresh();
    }

    public virtual IEnumerable<INode> Walk(NodeType nodeType)
    {
        if (NodeAdapter == ConverterUtils<INode, INode>.NoConvert)
            return Wrappee.Walk(nodeType);
        return AdaptedWalk(nodeType);
    }

    public virtual IEnumerable<IFile> GetFiles()
    {
        return GetFiles(PredicateUtils<IFile>.AlwaysTrue);
    }

    public virtual IEnumerable<IFile> GetFiles(Predicate<IFile> acceptFile)
    {
        foreach (var node in GetChildren(NodeType.File, PredicateUtils<INode>.AlwaysTrue))
        {
            var file = (IFile)node;
            var adaptedFile = (IFile)NodeAdapter(file);

            if (acceptFile(adaptedFile)) yield return adaptedFile;
        }
    }

    public virtual IEnumerable<IDirectory> GetDirectories()
    {
        return GetDirectories(PredicateUtils<IDirectory>.AlwaysTrue);
    }

    public virtual IEnumerable<IDirectory> GetDirectories(Predicate<IDirectory> acceptDirectory)
    {
        foreach (var node in GetChildren(NodeType.Directory, PredicateUtils<INode>.AlwaysTrue))
        {
            var dir = (IDirectory)node;
            var adaptedDir = (IDirectory)NodeAdapter(dir);

            if (acceptDirectory(adaptedDir)) yield return adaptedDir;
        }
    }

    public virtual bool ChildExists(string name)
    {
        var node = Wrappee.Resolve(name);

        node.Refresh();

        node.CheckAccess(FileSystemSecuredOperation.View);

        return node.Exists;
    }

    public virtual IEnumerable<string> GetChildNames()
    {
        return GetChildNames(NodeType.Any);
    }

    public virtual IEnumerable<string> GetChildNames(NodeType nodeType)
    {
        return GetChildNames(nodeType, PredicateUtils<string>.AlwaysTrue);
    }

    public virtual IEnumerable<string> GetChildNames(Predicate<string> acceptName)
    {
        return GetChildNames(NodeType.Any, acceptName);
    }

    public virtual IEnumerable<string> GetChildNames(NodeType nodeType, Predicate<string> acceptName)
    {
        return Wrappee.GetChildNames(nodeType, acceptName);
    }

    public virtual IEnumerable<INode> GetChildren()
    {
        return GetChildren(NodeType.Any);
    }

    public virtual IEnumerable<INode> GetChildren(NodeType nodeType)
    {
        return GetChildren(nodeType, PredicateUtils<INode>.AlwaysTrue);
    }

    public virtual IEnumerable<INode> GetChildren(Predicate<INode> acceptNode)
    {
        return GetChildren(NodeType.Any, acceptNode);
    }

    public virtual IEnumerable<INode> GetChildren(NodeType nodeType, Predicate<INode> acceptNode)
    {
        foreach (var node in Wrappee.GetChildren(nodeType))
        {
            var adaptedNode = NodeAdapter(node);

            if (acceptNode(adaptedNode)) yield return adaptedNode;
        }
    }

    public override INode? Refresh()
    {
        Refresh(DirectoryRefreshMask.All);

        return this;
    }

    public virtual IDirectory Refresh(DirectoryRefreshMask mask)
    {
        Wrappee.Refresh(mask);

        return this;
    }

    public virtual IDirectory Delete(bool recursive)
    {
        Wrappee.Delete(recursive);

        return this;
    }

    IDirectory IDirectory.Create()
    {
        return Wrappee.Create();
    }

    IDirectory IDirectory.Create(bool createParent)
    {
        return Wrappee.Create(createParent);
    }

    public virtual IFileSystem CreateView()
    {
        return CreateView(Address.Scheme);
    }

    public virtual IFileSystem CreateView(string scheme, FileSystemOptions? options)
    {
        return Wrappee.CreateView(scheme, options);
    }

    public IFileSystem CreateView(string scheme)
    {
        return CreateView(scheme, FileSystemOptions.Default);
    }

    public IFileSystem CreateView(FileSystemOptions? options)
    {
        return CreateView(Address.Scheme, options);
    }

    public virtual INode? AddJumpPoint(INode node)
    {
        return Wrappee.AddJumpPoint(node);
    }

    public virtual INode? AddJumpPoint(string name, INode node)
    {
        return Wrappee.AddJumpPoint(name, node);
    }

    private void DelegateRecursiveActivityEvent(object sender, NodeActivityEventArgs eventArgs)
    {
        OnRecursiveActivityEvent(eventArgs);
    }

    protected void OnRecursiveActivityEvent(NodeActivityEventArgs eventArgs)
    {
        lock (this)
        {
            if (RecursiveActivityEvent != null) RecursiveActivityEvent(this, eventArgs);
        }
    }

    private void DelegateDirectoryActivityEvent(object sender, NodeActivityEventArgs eventArgs)
    {
        OnDirectoryActivityEvent(eventArgs);
    }

    protected void OnDirectoryActivityEvent(NodeActivityEventArgs eventArgs)
    {
        lock (this)
        {
            if (DirectoryActivityEvent != null) DirectoryActivityEvent(this, eventArgs);
        }
    }

    private void DelegateJumpPointAddedEvent(object sender, JumpPointEventArgs eventArgs)
    {
        OnJumpPointAddedEvent(eventArgs);
    }

    protected void OnJumpPointAddedEvent(JumpPointEventArgs eventArgs)
    {
        lock (this)
        {
            if (JumpPointAddedEvent != null) JumpPointAddedEvent(this, eventArgs);
        }
    }

    private void DelegateJumpPointRemovedEvent(object sender, JumpPointEventArgs eventArgs)
    {
        OnJumpPointRemovedEvent(eventArgs);
    }

    protected void OnJumpPointRemovedEvent(JumpPointEventArgs eventArgs)
    {
        lock (this)
        {
            if (JumpPointRemovedEvent != null) JumpPointRemovedEvent(this, eventArgs);
        }
    }

    private IEnumerable<INode> AdaptedWalk()
    {
        foreach (var node in Wrappee.Walk()) yield return NodeAdapter(node);
    }

    private IEnumerable<INode> AdaptedWalk(NodeType nodeType)
    {
        foreach (var node in Wrappee.Walk(nodeType)) yield return NodeAdapter(node);
    }
}