using Platform;
using Platform.IO;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public enum TransferState
{
    NotStarted,
    Preparing,
    Comparing,
    Transferring,
    Copying,
    Tidying,
    Finished,
    Stopped
}

public class StandardFileTransferService
    : AbstractRunnableService, IFileTransferService
{
    private readonly IFile destination;
    private readonly TransferProgress progress;
    private readonly FileTransferServiceType serviceType;
    private readonly IFile source;
    private readonly long bytesTransferred = 0L;

    private StreamCopier copier;
    private long offset;

    public StandardFileTransferService(IFile source, IFile destination)
        : this(source, new FileTransferServiceType(destination, true))
    {
    }

    public StandardFileTransferService(IFile source, FileTransferServiceType serviceType)
    {
        this.serviceType = serviceType;
        this.source = source;
        destination = this.serviceType.Destination;
        HashAlgorithmName = serviceType.HashAlgorithmName;

        progress = new TransferProgress(this);
    }

    public virtual string HashAlgorithmName { get; set; }

    public virtual event FileTransferServiceEventHandler TransferStateChanged;

    public virtual INode OperatingNode => source;

    public virtual INode TargetNode => destination;

    public override IMeter Progress => progress;

    public TransferState TransferState { get; private set; } = TransferState.NotStarted;

    public override bool RequestTaskState(TaskState taskState, TimeSpan timeout)
    {
        if (copier != null && copier.TaskState != TaskState.NotStarted
                           && copier.TaskState != TaskState.Finished && copier.TaskState != TaskState.Stopped)
            copier.RequestTaskState(taskState, timeout);

        return base.RequestTaskState(taskState, timeout);
    }

    public virtual void OnTransferStateChanged(FileTransferServiceEventArgs eventArgs)
    {
        if (TransferStateChanged != null) TransferStateChanged(this, eventArgs);
    }

    protected static TaskState ToTaskState(TransferState transferState)
    {
        switch (transferState)
        {
            case TransferState.NotStarted:
                return TaskState.NotStarted;
            case TransferState.Preparing:
            case TransferState.Comparing:
            case TransferState.Transferring:
            case TransferState.Copying:
            case TransferState.Tidying:
                return TaskState.Running;
            case TransferState.Finished:
                return TaskState.Finished;
            case TransferState.Stopped:
                return TaskState.Stopped;
            default:
                return TaskState.Unknown;
        }
    }

    private void SetTransferState(TransferState value)
    {
        lock (this)
        {
            var oldValue = TransferState;

            if (TransferState != value)
            {
                TransferState = value;

                OnTransferStateChanged(new FileTransferServiceEventArgs(oldValue, TransferState));

                SetTaskState(ToTaskState(TransferState));

                Monitor.PulseAll(this);

                progress.RaiseStateChanged();
            }
        }
    }

    private long GetBytesTransferred()
    {
        if (copier != null)
            return Convert.ToInt64(copier.Progress.CurrentValue) + offset;
        return bytesTransferred + offset;
    }

    private long GetBytesToTransfer()
    {
        if (copier != null)
            return Convert.ToInt64(copier.Progress.MaximumValue) + offset;
        return source.Length ?? 0;
    }

    public override void DoRun()
    {
        IFile destinationTemp;
        Stream destinationTempStream;
        string sourceHash;

        try
        {
            lock (this)
            {
                SetTransferState(TransferState.Preparing);
            }

            var transferAttributes = delegate(IFile dest)
            {
                using (dest.Attributes.AquireUpdateContext())
                {
                    foreach (var s in serviceType.AttributesToTransfer) dest.Attributes[s] = source.Attributes[s];
                }
            };

            Stream sourceStream = null;

            for (var i = 0; i < 4; i++)
            {
                try
                {
                    sourceStream = OperatingNode.GetContent().GetInputStream(FileMode.Open, FileShare.Read);

                    break;
                }
                catch (NodeNotFoundException)
                {
                    throw;
                }
                catch (Exception)
                {
                    if (i == 3) throw;
                }

                ProcessTaskStateRequest();
            }

            using (sourceStream)
            {
                var sourceHashingService = (IHashingService)OperatingNode.GetService(new StreamHashingServiceType(sourceStream, HashAlgorithmName));

                // Compute the hash of the source file

                SetTransferState(TransferState.Comparing);
                ProcessTaskStateRequest();

                sourceHash = sourceHashingService.ComputeHash().TextValue;

                // Try to open the destination file

                ProcessTaskStateRequest();

                var destinationHashingService = (IHashingService)TargetNode.GetService(new FileHashingServiceType(HashAlgorithmName));

                string destinationHash;

                try
                {
                    destinationHash = destinationHashingService.ComputeHash().TextValue;
                }
                catch (DirectoryNodeNotFoundException)
                {
                    TargetNode.ParentDirectory.Create(true);

                    try
                    {
                        destinationHash = destinationHashingService.ComputeHash().TextValue;
                    }
                    catch (NodeNotFoundException)
                    {
                        destinationHash = null;
                    }
                }
                catch (NodeNotFoundException)
                {
                    destinationHash = null;
                }

                ProcessTaskStateRequest();

                // Source and destination are identical

                if (sourceHash == destinationHash)
                {
                    SetTransferState(TransferState.Transferring);

                    progress.RaiseValueChanged(0, GetBytesToTransfer());

                    SetTransferState(TransferState.Tidying);

                    // Transfer attributes

                    try
                    {
                        transferAttributes((IFile)TargetNode);
                    }
                    catch (FileNotFoundException)
                    {
                    }

                    // Done

                    SetTransferState(TransferState.Finished);
                    ProcessTaskStateRequest();

                    return;
                }

                // Get a temp file for the destination based on the source's hash

                destinationTemp = ((ITempIdentityFileService)destination.GetService(new TempIdentityFileServiceType(sourceHash))).GetTempFile();

                // Get the stream for the destination temp file

                try
                {
                    if (!destinationTemp.ParentDirectory.Exists) destinationTemp.ParentDirectory.Create(true);
                }
                catch (IOException)
                {
                }

                using (destinationTempStream = destinationTemp.GetContent().OpenStream(FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None))
                {
                    Action finishUp = delegate
                    {
                        SetTransferState(TransferState.Tidying);

                        destinationTempStream.Close();

                        for (var i = 0; i < 4; i++)
                        {
                            try
                            {
                                // Save hash value
                                StandardFileHashingService.SaveHashToCache(destinationTemp, HashAlgorithmName,
                                    sourceHash, (IFile)TargetNode);

                                try
                                {
                                    // Transfer attributes
                                    transferAttributes(destinationTemp);
                                }
                                catch (FileNotFoundException e)
                                {
                                    Console.WriteLine(e);
                                }

                                // Move destination temp to destination
                                destinationTemp.MoveTo(TargetNode, true);

                                break;
                            }
                            catch (Exception)
                            {
                                if (i == 3) throw;
                            }

                            ProcessTaskStateRequest();
                        }

                        // Done

                        SetTransferState(TransferState.Finished);
                        ProcessTaskStateRequest();
                    };

                    // Get the hash for the destination temp file

                    var destinationTempHashingService =
                        (IHashingService)destinationTemp.GetService(new StreamHashingServiceType(destinationTempStream));

                    // If the destination temp and the source aren't the same
                    // then complete the destination temp

                    string destinationTempHash;

                    if (destinationTempStream.Length >= sourceStream.Length)
                    {
                        // Destination is longer than source but starts source (unlikely)

                        destinationTempHash = destinationTempHashingService.ComputeHash(0, sourceStream.Length).TextValue;

                        if (destinationTempHash == sourceHash)
                        {
                            if (destinationTempStream.Length != sourceStream.Length) destinationTempStream.SetLength(sourceStream.Length);

                            finishUp();

                            return;
                        }

                        destinationTempStream.SetLength(0);
                    }

                    if (destinationTempStream.Length > 0)
                    {
                        destinationTempHash = destinationTempHashingService.ComputeHash().TextValue;

                        // Destination shorter than the source but is a partial copy of source

                        sourceHash = sourceHashingService.ComputeHash(0, destinationTempStream.Length).TextValue;

                        if (sourceHash == destinationTempHash)
                        {
                            offset = destinationTempStream.Length;
                        }
                        else
                        {
                            offset = 0;
                            destinationTempStream.SetLength(0);
                        }
                    }
                    else
                    {
                        offset = 0;
                    }

                    progress.RaiseValueChanged(0, offset);

                    // Transfer over the remaining part needed (or everything if offset is 0)

                    offset = destinationTempStream.Length;

                    Stream sourcePartialStream = new PartialStream(sourceStream, destinationTempStream.Length);
                    Stream destinationTempPartialStream = new PartialStream(destinationTempStream, destinationTempStream.Length);

                    copier =
                        new StreamCopier(new BufferedStream(sourcePartialStream, serviceType.BufferSize), destinationTempPartialStream,
                            false, false, serviceType.ChunkSize);

                    copier.TaskStateChanged += delegate(object sender, TaskEventArgs eventArgs)
                    {
                        if (eventArgs.TaskState == TaskState.Running
                            || eventArgs.TaskState == TaskState.Paused
                            || eventArgs.TaskState == TaskState.Stopped)
                            SetTaskState(eventArgs.TaskState);
                    };

                    SetTransferState(TransferState.Transferring);
                    ProcessTaskStateRequest();

                    copier.Run();

                    if (copier.TaskState == TaskState.Stopped) throw new StopRequestedException();

                    finishUp();
                }
            }
        }
        catch (StopRequestedException)
        {
        }
        finally
        {
            if (TransferState != TransferState.Finished) SetTransferState(TransferState.Stopped);
        }
    }

    private void Pump_TaskStateChanged(object sender, TaskEventArgs eventArgs)
    {
        if (eventArgs.TaskState == TaskState.Running || eventArgs.TaskState == TaskState.Paused) SetTaskState(eventArgs.TaskState);
    }

    private sealed class TransferProgress
        : AbstractMeter
    {
        private readonly StandardFileTransferService service;

        private bool pumpRegistered;

        public TransferProgress(StandardFileTransferService service)
        {
            this.service = service;
        }

        public override object Owner => service;

        public override object MaximumValue => service.GetBytesToTransfer();

        public override object MinimumValue => 0;

        public override object CurrentValue => service.GetBytesTransferred();

        public override string Units => "bytes";

        public override string ToString()
        {
            switch (service.TransferState)
            {
                case TransferState.Finished:
                    return string.Format("Finished {0}/{1} bytes ({2:0}%)", CurrentValue, MaximumValue,
                        Convert.ToDouble(CurrentValue) / Convert.ToDouble(MaximumValue) * 100.0);
                case TransferState.Transferring:
                    return string.Format("Transferring {0}/{1} bytes ({2:0.##}%)", CurrentValue, MaximumValue,
                        Convert.ToDouble(CurrentValue) / Convert.ToDouble(MaximumValue) * 100.0);
                default:
                    return Enum.GetName(typeof(TransferState), service.TransferState);
            }
        }

        public void RaiseValueChanged(object oldValue, object newValue)
        {
            OnValueChanged(oldValue, newValue);
        }

        public void RaiseMajorChange()
        {
            OnMajorChange();
        }

        public void RaiseStateChanged()
        {
            if (service.TransferState == TransferState.Transferring)
                lock (this)
                {
                    if (!pumpRegistered && service.copier != null)
                    {
                        service.copier.Progress.ValueChanged += PumpProgress_ValueChanged;
                        service.copier.Progress.MajorChange += PumpProgress_MajorChange;

                        pumpRegistered = true;
                    }
                }
        }

        private void PumpProgress_ValueChanged(object sender, MeterEventArgs eventArgs)
        {
            OnValueChanged((long)eventArgs.OldValue + service.offset, (long)eventArgs.NewValue + service.offset);
        }

        private void PumpProgress_MajorChange(object sender, EventArgs e)
        {
            OnMajorChange();
        }
    }
}