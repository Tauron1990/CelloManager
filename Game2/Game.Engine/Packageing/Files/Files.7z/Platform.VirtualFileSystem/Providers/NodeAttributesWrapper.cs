using System.Collections;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class NodeAttributesWrapper
    : MarshalByRefObject, INodeAttributes
{
    public NodeAttributesWrapper(INodeAttributes innerMutableNodeAttributes)
    {
        Wrappee = innerMutableNodeAttributes;
    }

    protected virtual INodeAttributes Wrappee { get; }

    public virtual object SyncLock => Wrappee.SyncLock;

    IEnumerator IEnumerable.GetEnumerator()
    {
        return ((IEnumerable)Wrappee).GetEnumerator();
    }

    public virtual DateTime? CreationTime
    {
        get => Wrappee.CreationTime;
        set => Wrappee.CreationTime = value;
    }

    public virtual DateTime? LastAccessTime
    {
        get => Wrappee.LastAccessTime;
        set => Wrappee.LastAccessTime = value;
    }

    public virtual DateTime? LastWriteTime
    {
        get => Wrappee.LastWriteTime;
        set => Wrappee.LastWriteTime = value;
    }

    public virtual object this[string name]
    {
        get => Wrappee[name];
        set => Wrappee[name] = value;
    }

    public virtual bool Exists => Wrappee.Exists;

    public virtual IEnumerable<string> Names => Wrappee.Names;

    public virtual IEnumerable<object> Values => Wrappee.Values;

    public virtual bool Supports(string name)
    {
        return Wrappee.Supports(name);
    }

    void IRefreshable.Refresh()
    {
        Wrappee.Refresh();
    }

    public virtual INodeAttributes Refresh()
    {
        Wrappee.Refresh();

        return this;
    }

    public virtual IAutoLock AquireAutoLock()
    {
        return Wrappee.AquireAutoLock();
    }

    public virtual INodeAttributesUpdateContext AquireUpdateContext()
    {
        return Wrappee.AquireUpdateContext();
    }

    public bool? ReadOnly
    {
        get => Wrappee.ReadOnly;
        set => Wrappee.ReadOnly = value;
    }

    public virtual bool? IsHidden
    {
        get => Wrappee.IsHidden;
        set => Wrappee.IsHidden = value;
    }

    object ISyncLocked.SyncLock => SyncLock;

    IAutoLock ISyncLocked.GetAutoLock()
    {
        return GetAutoLock();
    }

    IEnumerator<KeyValuePair<string, object>> IEnumerable<KeyValuePair<string, object>>.GetEnumerator()
    {
        return GetEnumerator();
    }

    public virtual IEnumerator<KeyValuePair<string, object>> GetEnumerator()
    {
        return Wrappee.GetEnumerator();
    }

    public override bool Equals(object obj)
    {
        return Wrappee.Equals(obj);
    }

    public override int GetHashCode()
    {
        return Wrappee.GetHashCode();
    }

    public override string ToString()
    {
        return Wrappee.ToString();
    }

    public virtual IAutoLock GetAutoLock()
    {
        return Wrappee.GetAutoLock();
    }
}