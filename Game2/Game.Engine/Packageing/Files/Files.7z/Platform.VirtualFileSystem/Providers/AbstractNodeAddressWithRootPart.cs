namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

[Serializable]
public abstract class AbstractNodeAddressWithRootPart
    : AbstractNodeAddress
{
    private readonly string rootPart;
    private volatile string absolutePathIncludingRootPart;

    protected AbstractNodeAddressWithRootPart(string scheme, string rootPart, string absolutePath, string query)
        : base(scheme, absolutePath, query)
    {
        this.rootPart = rootPart;
    }

    public virtual string RootPart => rootPart;

    public virtual string AbsolutePathIncludingRootPart
    {
        get
        {
            if (absolutePathIncludingRootPart == null)
                lock (this)
                {
                    if (absolutePathIncludingRootPart == null) absolutePathIncludingRootPart = rootPart + AbsolutePath;
                }

            return absolutePathIncludingRootPart;
        }
    }

    public virtual INodeAddress CreateAsRoot()
    {
        return CreateAsRoot(Scheme);
    }

    public abstract INodeAddress CreateAsRoot(string scheme);
}