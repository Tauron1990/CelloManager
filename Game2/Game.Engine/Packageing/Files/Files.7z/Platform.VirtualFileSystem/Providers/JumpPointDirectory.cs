using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class JumpPointDirectory
    : DirectoryDelegationWrapper
{
    public JumpPointDirectory(IDirectory dir, INodeAddress address)
        : base(dir, new JumpPointResolver(dir), ConverterUtils<INode, INode>.NoConvert)
    {
        this.Address = address;
    }

    public override INodeAddress Address { get; }
}