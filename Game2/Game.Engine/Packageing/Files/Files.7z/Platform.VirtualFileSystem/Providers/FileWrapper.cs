namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public abstract class FileWrapper
    : NodeDelegationWrapper, IFile
{
    protected FileWrapper(IFile innerFile)
        : base(innerFile)
    {
    }

    public new virtual IFile Wrappee => (IFile)base.Wrappee;

    public new IFileAttributes Attributes => Wrappee.Attributes;

    IFile IFile.Refresh()
    {
        return (IFile)Refresh();
    }

    IFile IFile.Create()
    {
        return Wrappee.Create();
    }

    IFile IFile.Create(bool createParent)
    {
        return Wrappee.Create(createParent);
    }

    public virtual long? Length => Wrappee.Length;

    public virtual bool IdenticalTo(IFile file, FileComparingFlags flags)
    {
        return Wrappee.IdenticalTo(file, flags);
    }

    public virtual IFile CreateAsHardLink(IFile file)
    {
        Wrappee.CreateAsHardLink(file);

        return this;
    }

    public virtual IFile CreateAsHardLink(IFile file, bool overwrite)
    {
        Wrappee.CreateAsHardLink(file, overwrite);

        return this;
    }

    public virtual IFile CreateAsHardLink(string path)
    {
        Wrappee.CreateAsHardLink(path);

        return this;
    }

    public virtual IFile CreateAsHardLink(string path, bool overwrite)
    {
        Wrappee.CreateAsHardLink(path, overwrite);

        return this;
    }
}