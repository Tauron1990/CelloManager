namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class JumpPointFile
    : FileWrapper
{
    public JumpPointFile(IFile file, INodeAddress address)
        : base(file)
    {
        Address = address;
    }

    public override INodeAddress Address { get; }
}