using System.Reactive.Disposables;
using System.Text;
using JetBrains.Annotations;
// ReSharper disable VirtualMemberCallInConstructor

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

/// <summary>
///     This class provides a skeletal implementation of the <c>INode</c>interface to minimize the effort
///     required to implement the interface.
///     <seealso cref="INode" />
/// </summary>
[PublicAPI]
public abstract class AbstractNode : AbstractResolver, INode
{
    protected NodeActivityEventHandler? ActivityEvent;

    private int _activityListenerCount;

    private volatile INodeAttributes? _attributes;
    protected NodeActivityEventHandler? ChangedEvent;
    protected NodeActivityEventHandler? CreatedEvent;
    protected NodeActivityEventHandler? DeletedEvent;
    protected volatile int EventCount;

    private volatile IDictionary<string, INodeContent>? _nodeContents;
    protected NodeActivityEventHandler? RenamedEvent;

    protected AbstractNode(IFileSystem fileSystem, INodeAddress nodeAddress)
    {
        Address = nodeAddress;
        FileSystem = fileSystem;
    }

    public virtual event NodeActivityEventHandler Renamed
    {
        add
        {
            lock (this)
            {
                PreAddActivityEvent();

                RenamedEvent += value;

                PostAddActivityEvent();
            }
        }

        remove
        {
            lock (this)
            {
                PreRemoveActivityEvent();

                RenamedEvent -= value;

                PostRemoveActivityEvent();
            }
        }
    }

    public virtual event NodeActivityEventHandler Created
    {
        add
        {
            lock (this)
            {
                PreAddActivityEvent();

                CreatedEvent += value;

                PostAddActivityEvent();
            }
        }

        remove
        {
            lock (this)
            {
                PreRemoveActivityEvent();

                CreatedEvent -= value;

                PostRemoveActivityEvent();
            }
        }
    }

    public virtual event NodeActivityEventHandler Deleted
    {
        add
        {
            lock (this)
            {
                PreAddActivityEvent();

                DeletedEvent += value;

                PostAddActivityEvent();
            }
        }

        remove
        {
            lock (this)
            {
                PreRemoveActivityEvent();

                DeletedEvent -= value;

                PostRemoveActivityEvent();
            }
        }
    }

    public virtual event NodeActivityEventHandler Changed
    {
        add
        {
            lock (this)
            {
                PreAddActivityEvent();

                ChangedEvent += value;

                PostAddActivityEvent();
            }
        }

        remove
        {
            lock (this)
            {
                PreRemoveActivityEvent();

                ChangedEvent -= value;

                PostRemoveActivityEvent();
            }
        }
    }

    public virtual event NodeActivityEventHandler Activity
    {
        add
        {
            lock (this)
            {
                PreAddActivityEvent();

                ActivityEvent += value;

                PostAddActivityEvent();
            }
        }

        remove
        {
            lock (this)
            {
                PreRemoveActivityEvent();

                ActivityEvent -= value;

                PostRemoveActivityEvent();
            }
        }
    }

    public virtual string DefaultContentName => "";

    public virtual IEnumerable<string> GetContentNames()
    {
        yield return DefaultContentName;
    }

    public virtual INodeContent GetContent() => CheckAndCreateContent("");

    public virtual INodeContent GetContent(string contentName)
    {
        if (contentName != DefaultContentName
            && !SupportsAlternateContent())
            throw new NotSupportedException();

        return CheckAndCreateContent(contentName);
    }

    public virtual bool SupportsActivityEvents => FileSystem.SupportsActivityEvents;

    public virtual INode Refresh()
    {
        Attributes.Refresh();

        return this;
    }

    /// <summary>
    ///     <see cref="INode.Exists" />
    /// </summary>
    public virtual bool Exists => Attributes.Exists;

    /// <summary>
    ///     <see cref="INode.NodeType" />
    /// </summary>
    public abstract NodeType NodeType { get; }

    public virtual string Name => Address.Name;

    public virtual INodeAddress Address { get; }

    public virtual IFileSystem FileSystem { get; protected set; }

    public virtual INode Create() => Create(false);

    public virtual void CheckAccess(FileSystemSecuredOperation operation)
    {
        if (!FileSystem.SecurityManager.CurrentContext.HasAccess
            (
                new AccessVerificationContext(this, operation)
            ))
            throw new FileSystemSecurityException(Address);
    }

    public virtual INode Create(bool createParent)
    {
        CheckAccess(FileSystemSecuredOperation.Write);

        return FileSystem.Extenders.CompositeNodeOperationFilter.Create(this, createParent, out _, DoCreate);
    }

    public virtual object SyncLock { get; } = new();

    public virtual IEnumerable<INode> GetAlternates()
    {
        yield return this;
    }

    public virtual IDirectory ParentDirectory
    {
        get
        {
            lock (this)
                return ResolveDirectory(NodeType.IsLikeDirectory ? ".." : ".");
        }
    }

    public abstract IFile ResolveFile(string name, AddressScope scope);
    public abstract IDirectory ResolveDirectory(string name, AddressScope scope);
    public abstract INode Resolve(string name, AddressScope scope);

    /// <summary>
    ///     <see cref="INode.Resolve(string, NodeType, AddressScope)" />
    /// </summary>
    /// <remarks>
    ///     The default implementation validates the AddressScope by calling IsScopeValid(Uri, AddressScope)
    ///     and then calls the current object's FileSystem's <c>Resolve(string, NodeType)</c>
    ///     method.
    /// </remarks>
    public virtual INode Resolve(string name, NodeType nodeType, AddressScope scope)
    {
        var nodeAddress = ResolveAddress(name, scope);

        return Resolve(nodeAddress, nodeType, scope);
    }

    public virtual INode RenameTo(string name, bool overwrite) => FileSystem.Extenders.CompositeNodeOperationFilter.RenameTo(this, name, overwrite, out _, DoRenameTo);

    public virtual INode MoveTo(INode target, bool overwrite)
    {
        CheckAccess(FileSystemSecuredOperation.Write);

        return FileSystem.Extenders.CompositeNodeOperationFilter.MoveTo(this, target, overwrite, out _, DoMoveTo);
    }

    public virtual INode CopyTo(INode target, bool overwrite)
    {
        CheckAccess(FileSystemSecuredOperation.Write);

        return FileSystem.Extenders.CompositeNodeOperationFilter.CopyTo(this, target, overwrite, out _, DoCopyTo);
    }

    public virtual INode MoveToDirectory(IDirectory directory, bool overwrite) => DoMoveTo(GetDirectoryOperationTargetNode(directory), overwrite);

    public virtual INode CopyToDirectory(IDirectory directory, bool overwrite) => DoCopyTo(GetDirectoryOperationTargetNode(directory), overwrite);

    public virtual INode Delete()
    {
        return FileSystem.Extenders.CompositeNodeOperationFilter.Delete(this, out _, DoDelete);
    }

    public virtual IService GetService(ServiceType serviceType) => FileSystem.GetService(this, serviceType);

    public virtual T GetService<T>()
        where T : IService =>
        (T)GetService(ServiceType.FromRuntimeType(typeof(T)));

    public virtual T GetService<T>(ServiceType serviceType)
        where T : IService =>
        (T)GetService(serviceType);

    public abstract IDirectory OperationTargetDirectory { get; }

    public virtual INodeAttributes Attributes
    {
        get
        {
            if (_attributes == null)
                lock (this)
                {
                    if (_attributes == null) _attributes = CreateAttributes();
                }

            return _attributes;
        }
    }
    public virtual IDisposable AquireLock()
    {
        Monitor.Enter(SyncLock);
        
        return Disposable.Create(this, self => Monitor.Exit(self.SyncLock));
    }

    public virtual int CompareTo(INode? other) => string.Compare(Name, other?.Name, StringComparison.OrdinalIgnoreCase);

    public virtual void CreateGlobalLock(string name)
    {
    }

    public abstract INode GetDirectoryOperationTargetNode(IDirectory directory);

    protected virtual void PreAddActivityEvent()
    {
        if (!SupportsActivityEvents) throw new NotSupportedException();
    }

    protected virtual bool AcceptsActivity(FileSystemActivityEventArgs eventArgs)
    {
        return (Equals(eventArgs.NodeType, NodeType) || Equals(eventArgs.NodeType, NodeType.Any))
               && (FileSystem.PathsEqual(eventArgs.Path, Address.AbsolutePath, Math.Max(Address.AbsolutePath.Length, eventArgs.Path.Length)) ||
                   eventArgs.Path == "*");
    }

    protected virtual void PostAddActivityEvent()
    {
        if (_activityListenerCount == 0) FileSystem.Activity += FileSystem_Activity;

        _activityListenerCount++;
    }

    protected virtual void FileSystem_Activity(object sender, FileSystemActivityEventArgs eventArgs)
    {
        if (!FileSystem.SecurityManager.CurrentContext.HasAccess(new AccessVerificationContext(this, FileSystemSecuredOperation.View))) return;

        if (!AcceptsActivity(eventArgs)) return;

        Refresh();

        switch (eventArgs.Activity)
        {
            case FileSystemActivity.Changed:
                OnActivity(new NodeActivityEventArgs(eventArgs.Activity, this));
                OnChanged(new NodeActivityEventArgs(eventArgs.Activity, this));
                break;
            case FileSystemActivity.Created:
                OnActivity(new NodeActivityEventArgs(eventArgs.Activity, this));
                OnCreated(new NodeActivityEventArgs(eventArgs.Activity, this));
                break;
            case FileSystemActivity.Deleted:
                OnActivity(new NodeActivityEventArgs(eventArgs.Activity, this));
                OnDeleted(new NodeActivityEventArgs(eventArgs.Activity, this));
                break;
            case FileSystemActivity.Renamed:
                var renamedEventArgs = (FileSystemRenamedActivityEventArgs)eventArgs;
                OnActivity(new NodeActivityEventArgs(eventArgs.Activity, this, renamedEventArgs.Name));
                OnRenamed(new NodeActivityEventArgs(eventArgs.Activity, this, renamedEventArgs.Name));
                break;
        }
    }

    protected virtual void PreRemoveActivityEvent()
    {
        if (!SupportsActivityEvents) throw new NotSupportedException();
    }

    protected virtual void PostRemoveActivityEvent()
    {
        _activityListenerCount--;

        if (_activityListenerCount == 0) FileSystem.Activity -= FileSystem_Activity;
    }

    protected void PreCheckEvents()
    {
        throw new NotSupportedException();
    }

    protected void PostCheckEvents()
    {
    }

    private INodeContent CheckAndCreateContent(string contentName)
    {
        if (_nodeContents == null)
            lock (this)
            {
                if (_nodeContents == null)
                {
                    var alternateContents = new Dictionary<string, INodeContent>();

                    Thread.MemoryBarrier();

                    _nodeContents = alternateContents;
                }
            }

        lock (_nodeContents)
        {
            INodeContent retval;

            if (_nodeContents.TryGetValue(contentName, out retval))
            {
                return retval;
            }

            retval = CreateContent(contentName);
            _nodeContents[contentName] = retval;

            return retval;
        }
    }

    protected virtual INodeContent CreateContent(string contentName)
    {
        if (!string.IsNullOrEmpty(contentName) && !SupportsAlternateContent()) throw new NotSupportedException($"CONTENT: {contentName}");

        return new StandardNodeContent(this, contentName);
    }

    protected virtual bool SupportsAlternateContent()
    {
        return false;
    }

    protected virtual void DeleteContent(string contentName)
    {
        if (contentName == DefaultContentName)
        {
            Delete();

            return;
        }

        throw new NotSupportedException();
    }

    protected virtual Stream OpenStream(string contentName, FileMode fileMode, FileAccess fileAccess, FileShare fileShare)
    {
        switch (fileAccess)
        {
            case FileAccess.Read:
                return DoGetInputStream(contentName, out _, fileMode, fileShare);
            case FileAccess.Write:
                return DoGetOutputStream(contentName, null, fileMode, fileShare);
            default:
                return DoOpenStream(contentName, fileMode, fileAccess, fileShare);
        }
    }

    protected virtual Stream DoOpenStream(string contentName, FileMode fileMode, FileAccess fileAccess, FileShare fileShare) => throw new NotSupportedException();

    protected virtual Stream DoGetInputStream(string contentName, out string encoding, FileMode fileMode, FileShare fileShare) => throw new NotSupportedException();

    protected virtual Stream DoGetOutputStream(string contentName, string? encoding, FileMode fileMode, FileShare fileShare) => throw new NotSupportedException();

    protected virtual void OnActivity(NodeActivityEventArgs eventArgs) => ActivityEvent?.Invoke(this, eventArgs);

    protected virtual void OnRenamed(NodeActivityEventArgs eventArgs) => RenamedEvent?.Invoke(this, eventArgs);

    protected virtual void OnCreated(NodeActivityEventArgs eventArgs) => CreatedEvent?.Invoke(this, eventArgs);

    protected virtual void OnDeleted(NodeActivityEventArgs eventArgs) => DeletedEvent?.Invoke(this, eventArgs);

    protected virtual void OnChanged(NodeActivityEventArgs eventArgs) => ChangedEvent?.Invoke(this, eventArgs);

    public virtual INode DoCreate(bool createParent) => throw new NotSupportedException();

    private string Unescape(string path)
    {
        var builder = new StringBuilder(path.Length + 10);

        for (var x = 0; x < path.Length;) builder.Append(Uri.HexUnescape(path, ref x));

        return builder.ToString();
    }

    protected virtual INodeAddress ResolveAddress(string name, AddressScope scope) => NodeType.IsLikeDirectory ? Address.ResolveAddress(name, scope) : Address.Parent.ResolveAddress(name, scope);

    protected virtual INode Resolve(INodeAddress address, NodeType nodeType, AddressScope scope) => FileSystem.Resolve(address, nodeType);

    protected virtual INode DoRenameTo(string name, bool overwrite)
    {
        CheckAccess(FileSystemSecuredOperation.Write);

        if (name.Contains(FileSystemManager.SeperatorChar)) throw new ArgumentException("Name can not contain paths", name);

        MoveTo(Resolve(name), overwrite);

        return this;
    }

    protected virtual INode DoMoveTo(INode target, bool overwrite)
    {
        ((INodeMovingService)GetService(new NodeMovingServiceType(target, overwrite))).Run();

        return this;
    }

    protected virtual INode DoCopyTo(INode target, bool overwrite)
    {
        ((INodeCopyingService)GetService(new NodeCopyingServiceType(target, overwrite))).Run();

        return this;
    }

    protected virtual INode DoDelete()
    {
        CheckAccess(FileSystemSecuredOperation.Write);

        throw new NotSupportedException(GetType().Name + "_Delete_NotSupported");
    }

    public override int GetHashCode() => Address.GetHashCode();

    public override bool Equals(object? obj)
    {
        if (obj is not INode node) return false;

        if (obj == this) return true;

        return NodeType.Equals(node.NodeType) && Address.Equals(node.Address);
    }

    protected abstract INodeAttributes CreateAttributes();

    public override string ToString() => $"{NodeType}: {Address}";

    protected class StandardNodeContent : AbstractNodeContent
    {
        private readonly string _contentName;
        private readonly AbstractNode _node;

        public StandardNodeContent(AbstractNode node, string contentName)
        {
            _node = node;
            _contentName = contentName;
        }

        public override void Delete()
        {
            _node.CheckAccess(FileSystemSecuredOperation.Write);

            _node.DeleteContent(_contentName);
        }

        protected override Stream DoOpenStream(FileMode fileMode, FileAccess fileAccess, FileShare fileShare)
        {
            var operation = FileSystemSecuredOperation.None;

            if ((fileAccess & FileAccess.Read) == FileAccess.Read) operation = FileSystemSecuredOperation.Read;

            _node.CheckAccess(operation);

            return _node.OpenStream(_contentName, fileMode, fileAccess, fileShare);
        }

        protected override Stream DoGetInputStream(out string encoding, FileMode mode, FileShare sharing)
        {
            _node.CheckAccess(FileSystemSecuredOperation.Read);

            return _node.DoGetInputStream(_contentName, out encoding, mode, sharing);
        }

        protected override Stream DoGetOutputStream(string? encoding, FileMode mode, FileShare sharing)
        {
            _node.CheckAccess(FileSystemSecuredOperation.Write);

            return _node.DoGetOutputStream(_contentName, encoding, mode, sharing);
        }
    }
}