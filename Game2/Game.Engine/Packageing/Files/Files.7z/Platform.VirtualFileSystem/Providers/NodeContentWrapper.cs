using System.Text;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class NodeContentWrapper
    : MarshalByRefObject, INodeContent
{
    public NodeContentWrapper(INodeContent wrappee)
    {
        Wrappee = wrappee;
    }

    protected virtual INodeContent Wrappee { get; }

    public virtual void Delete()
    {
        Wrappee.Delete();
    }

    public virtual Stream OpenStream(FileMode fileMode, FileAccess fileAccess, FileShare fileShare)
    {
        return Wrappee.OpenStream(fileMode, fileAccess, fileShare);
    }

    public virtual Stream GetInputStream()
    {
        return Wrappee.GetInputStream();
    }

    public virtual Stream GetInputStream(out string encoding)
    {
        return Wrappee.GetInputStream(out encoding);
    }

    public virtual Stream GetInputStream(FileShare sharing)
    {
        return Wrappee.GetInputStream(sharing);
    }

    public virtual Stream GetInputStream(out string encoding, FileShare sharing)
    {
        return Wrappee.GetInputStream(out encoding, sharing);
    }

    public virtual Stream GetInputStream(FileMode mode)
    {
        return Wrappee.GetInputStream(mode);
    }

    public virtual Stream GetInputStream(FileMode mode, FileShare sharing)
    {
        return Wrappee.GetInputStream(mode, sharing);
    }

    public virtual Stream GetInputStream(out string encoding, FileMode mode)
    {
        return Wrappee.GetInputStream(out encoding, mode);
    }

    public virtual Stream GetInputStream(out string encoding, FileMode mode, FileShare sharing)
    {
        return Wrappee.GetInputStream(out encoding, mode, sharing);
    }

    public virtual Stream GetOutputStream()
    {
        return Wrappee.GetOutputStream();
    }

    public virtual Stream GetOutputStream(FileShare sharing)
    {
        return Wrappee.GetOutputStream(sharing);
    }

    public virtual Stream GetOutputStream(FileMode mode)
    {
        return Wrappee.GetOutputStream(mode);
    }

    public virtual Stream GetOutputStream(string? encoding, FileMode mode)
    {
        return Wrappee.GetOutputStream(encoding, mode);
    }

    public virtual Stream GetOutputStream(string? encoding)
    {
        return Wrappee.GetOutputStream(encoding);
    }

    public virtual Stream GetOutputStream(string? encoding, FileShare sharing)
    {
        return Wrappee.GetOutputStream(encoding, sharing);
    }

    public virtual Stream GetOutputStream(string? encoding, FileMode mode, FileShare sharing)
    {
        return Wrappee.GetOutputStream(encoding, mode, sharing);
    }

    public virtual Stream GetOutputStream(FileMode mode, FileShare sharing)
    {
        return Wrappee.GetOutputStream(mode, sharing);
    }

    public virtual TextReader GetReader()
    {
        return Wrappee.GetReader();
    }

    public virtual TextReader GetReader(FileShare sharing)
    {
        return Wrappee.GetReader(sharing);
    }

    public virtual TextReader GetReader(out Encoding encoding)
    {
        return Wrappee.GetReader(out encoding);
    }

    public virtual TextReader GetReader(out Encoding encoding, FileShare sharing)
    {
        return Wrappee.GetReader(out encoding, sharing);
    }

    public virtual TextWriter GetWriter()
    {
        return Wrappee.GetWriter();
    }

    public virtual TextWriter GetWriter(FileShare sharing)
    {
        return Wrappee.GetWriter(sharing);
    }

    public virtual TextWriter GetWriter(Encoding encoding)
    {
        return Wrappee.GetWriter(encoding);
    }

    public virtual TextWriter GetWriter(Encoding encoding, FileShare sharing)
    {
        return Wrappee.GetWriter(encoding, sharing);
    }

    public override bool Equals(object obj)
    {
        return Wrappee.Equals(obj);
    }

    public override int GetHashCode()
    {
        return Wrappee.GetHashCode();
    }

    public override string ToString()
    {
        return Wrappee.ToString();
    }
}