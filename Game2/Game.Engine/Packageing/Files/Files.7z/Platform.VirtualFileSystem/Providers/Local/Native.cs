﻿using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Local;

public abstract class Native
{
    private static readonly Native Instance;

    static Native()
    {
        if (Environment.OSVersion.Platform == PlatformID.Win32NT
            || Environment.OSVersion.Platform == PlatformID.Win32S
            || Environment.OSVersion.Platform == PlatformID.Win32Windows
            || Environment.OSVersion.Platform == PlatformID.WinCE)
            Instance = new NativeWin32();
        else
            Instance = new NativePosix();
    }

    public virtual string DefaultContentName => "";

    public virtual bool SupportsAlternateContentStreams => false;

    public static Native GetInstance()
    {
        return Instance;
    }

    public virtual IEnumerable<ContentInfo> GetContentInfos(string path)
    {
        throw new NotSupportedException();
    }

    public virtual string GetShortPath(string path)
    {
        return path;
    }

    public virtual void DeleteFileContent(string path, string contentName)
    {
        if (contentName.IsNullOrEmpty())
            File.Delete(path);
        else
            throw new NotSupportedException();
    }

    public virtual string GetSymbolicLinkTarget(string path)
    {
        return null;
    }

    public virtual NodeType GetSymbolicLinkTargetType(string path)
    {
        return null;
    }

    public virtual void CreateHardLink(string path, string target)
    {
        throw new NotSupportedException();
    }

    public virtual Stream OpenAlternateContentStream(string path, string contentName, FileMode fileMode, FileAccess fileAccess, FileShare fileShare)
    {
        if (contentName.IsNullOrEmpty())
            return new FileStream(path, fileMode, fileAccess, fileShare);
        throw new NotSupportedException();
    }

    public virtual IEnumerable<string> ListExtendedAttributes(string path)
    {
        if (SupportsAlternateContentStreams)
        {
            foreach (var contentInfo in GetContentInfos(path))
                if (IsAlternateStreamExtendedAttribute(contentInfo.Name))
                    yield return contentInfo.Name.Substring(4);
        }
        else
        {
            throw new NotSupportedException();
        }
    }

    private bool IsAlternateStreamExtendedAttribute(string contentName)
    {
        return contentName.Length > 4 && contentName.StartsWith("$XA.");
    }

    private string GetExtendedAttributeAlternateStreamName(string attributeName)
    {
        return "$XA." + attributeName;
    }

    public virtual void SetExtendedAttribute(string path, string attributeName, byte[] value, int offset, int count)
    {
        if (SupportsAlternateContentStreams)
        {
            if (value == null)
                try
                {
                    DeleteFileContent(path, GetExtendedAttributeAlternateStreamName(attributeName));
                }
                catch (FileNodeNotFoundException)
                {
                }
            else
                for (var i = 0; i < 16; i++)
                {
                    using (var stream = OpenAlternateContentStream(path, GetExtendedAttributeAlternateStreamName(attributeName),
                               FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None))
                    {
                        stream.Write(value, 0, value.Length);
                    }

                    Thread.Sleep(50);
                }
        }
        else
        {
            throw new NotSupportedException();
        }
    }

    public virtual byte[] GetExtendedAttribute(string path, string attributeName)
    {
        if (SupportsAlternateContentStreams)
        {
            var bytes = new List<byte>();

            try
            {
                using (var stream = OpenAlternateContentStream(path, GetExtendedAttributeAlternateStreamName(attributeName), FileMode.Open,
                           FileAccess.ReadWrite, FileShare.None))
                {
                    int x;

                    while ((x = stream.ReadByte()) != -1) bytes.Add((byte)x);
                }
            }
            catch (IOException)
            {
                return null;
            }

            return bytes.ToArray();
        }

        throw new NotSupportedException();
    }

    public struct ContentInfo
    {
        public string Name { get; set; }

        public long Length { get; set; }

        public ContentInfo(string name, long length) : this()
        {
            Name = name;
            Length = length;
        }
    }
}