namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Local;

public class LocalFileSystemEventArgs
    : EventArgs
{
    public LocalFileSystemEventArgs(IDirectory directory)
    {
        Directory = directory;
    }

    public IDirectory Directory { get; set; }
}