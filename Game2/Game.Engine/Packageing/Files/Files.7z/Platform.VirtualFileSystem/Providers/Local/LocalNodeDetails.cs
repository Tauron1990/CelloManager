#region License

/*
 * LocalDetails.cs
 * 
 * Copyright (c) 2004 Thong Nguyen (tum@veridicus.com)
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * The license is packaged with the program archive in a file called LICENSE.TXT
 * 
 * You can also view a copy of the license online at:
 * http://www.opensource.org/licenses/gpl-license.php
 */

#endregion

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Local;

internal class LocalNodeDetails
    : AbstractNodeDetails
{
    protected FileSystemInfo m_FsInfo;

    public LocalNodeDetails(FileSystemInfo fsInfo)
    {
        m_FsInfo = fsInfo;
    }

    public override DateTime CreationTime
    {
        get => m_FsInfo.CreationTime;
        set => m_FsInfo.CreationTime = value;
    }

    public override bool Exists => m_FsInfo.Exists;

    public override DateTime LastAccessTime
    {
        get => m_FsInfo.LastAccessTime;
        set => m_FsInfo.LastAccessTime = value;
    }

    public override DateTime LastWriteTime
    {
        get => m_FsInfo.LastWriteTime;
        set => m_FsInfo.LastWriteTime = value;
    }

    public override void Refresh()
    {
        m_FsInfo.Refresh();
    }
}