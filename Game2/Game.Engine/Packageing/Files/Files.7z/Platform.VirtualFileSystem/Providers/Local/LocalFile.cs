using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Local;

/// <summary>
///     Implementation of <see cref="IFile" /> for <see cref="LocalFileSystem" />s.
/// </summary>
public class LocalFile
    : AbstractFile, INativePathService
{
    private readonly FileInfo fileInfo;

    public LocalFile(LocalFileSystem fileSystem, LocalNodeAddress address)
        : base(address, fileSystem)
    {
        FileSystem = fileSystem;
        fileInfo = new FileInfo(address.AbsoluteNativePath);
    }

    public override bool SupportsActivityEvents => true;

    public override string DefaultContentName => Native.GetInstance().DefaultContentName;

    string INativePathService.GetNativePath()
    {
        return ((LocalNodeAddress)Address).AbsoluteNativePath;
    }

    string INativePathService.GetNativeShortPath()
    {
        return Native.GetInstance().GetShortPath(((LocalNodeAddress)Address).AbsoluteNativePath);
    }

    public override INode DoCreate(bool createParent)
    {
        if (createParent)
        {
            ParentDirectory.Refresh();

            if (!ParentDirectory.Exists) ParentDirectory.Create(true);

            try
            {
                fileInfo.Create().Close();
            }
            catch (DirectoryNotFoundException)
            {
            }

            ParentDirectory.Create(true);

            try
            {
                fileInfo.Create().Close();
            }
            catch (DirectoryNotFoundException)
            {
                throw new DirectoryNodeNotFoundException(Address);
            }
            catch (FileNotFoundException)
            {
                throw new FileNodeNotFoundException(Address);
            }

            Refresh();
        }
        else
        {
            try
            {
                fileInfo.Create().Close();
            }
            catch (DirectoryNotFoundException)
            {
                throw new DirectoryNodeNotFoundException(Address);
            }
            catch (FileNotFoundException)
            {
                throw new FileNodeNotFoundException(Address);
            }
        }

        return this;
    }

    protected override INode DoDelete()
    {
        try
        {
            Native.GetInstance().DeleteFileContent(fileInfo.FullName, null);

            Refresh();
        }
        catch (FileNotFoundException)
        {
            throw new FileNodeNotFoundException(Address);
        }
        catch (DirectoryNotFoundException)
        {
            throw new DirectoryNodeNotFoundException(Address);
        }

        return this;
    }

    protected override INode DoCopyTo(INode target, bool overwrite)
    {
        return CopyTo(target, overwrite, false);
    }

    private INode CopyTo(INode target, bool overwrite, bool deleteOriginal)
    {
        string targetLocalPath = null;

        if (target.NodeType.IsLikeDirectory) target = target.ResolveFile(Address.Name);

        try
        {
            var service = (INativePathService)target.GetService(typeof(INativePathService));

            targetLocalPath = service.GetNativePath();
        }
        catch (NotSupportedException)
        {
        }

        var thisLocalPath = ((LocalNodeAddress)Address).AbsoluteNativePath;

        if (targetLocalPath == null
            || !Path.GetPathRoot(thisLocalPath).EqualsIgnoreCase(Path.GetPathRoot(targetLocalPath)))
        {
            if (deleteOriginal)
                base.DoMoveTo(target, overwrite);
            else
                base.DoCopyTo(target, overwrite);
        }
        else
        {
            target.Refresh();

            if (overwrite && target.Exists)
                try
                {
                    target.Delete();
                }
                catch (FileNodeNotFoundException)
                {
                }

            try
            {
                if (deleteOriginal)
                    try
                    {
                        File.Move(thisLocalPath, targetLocalPath);
                    }
                    catch (DirectoryNotFoundException)
                    {
                        throw new DirectoryNodeNotFoundException(Address);
                    }
                    catch (FileNotFoundException)
                    {
                        throw new FileNodeNotFoundException(Address);
                    }
                else
                    try
                    {
                        File.Copy(thisLocalPath, targetLocalPath);
                    }
                    catch (DirectoryNotFoundException)
                    {
                        throw new DirectoryNodeNotFoundException(Address);
                    }
                    catch (FileNotFoundException)
                    {
                        throw new FileNodeNotFoundException(Address);
                    }

                return this;
            }
            catch (IOException)
            {
                if (overwrite && target.Exists)
                    try
                    {
                        target.Delete();
                    }
                    catch (FileNotFoundException)
                    {
                    }
                else
                    throw;
            }

            if (deleteOriginal)
                try
                {
                    File.Move(thisLocalPath, targetLocalPath);
                }
                catch (DirectoryNotFoundException)
                {
                    throw new DirectoryNodeNotFoundException(Address);
                }
                catch (FileNotFoundException)
                {
                    throw new FileNodeNotFoundException(Address);
                }
            else
                try
                {
                    File.Copy(thisLocalPath, targetLocalPath);
                }
                catch (DirectoryNotFoundException)
                {
                    throw new DirectoryNodeNotFoundException(Address);
                }
                catch (FileNotFoundException)
                {
                    throw new FileNodeNotFoundException(Address);
                }
        }

        return this;
    }

    protected override INode DoMoveTo(INode target, bool overwrite)
    {
        return CopyTo(target, overwrite, true);
    }

    public override IService GetService(ServiceType serviceType)
    {
        var typedServiceType = serviceType as NodeMovingServiceType;

        if (typedServiceType != null)
        {
            if (typedServiceType.Destination is LocalFile)
                if (typedServiceType.Destination.Address.RootUri.Equals(Address.RootUri))
                    return new LocalFileMovingService(this, (LocalFile)typedServiceType.Destination, typedServiceType.Overwrite);
        }
        else if (serviceType.Is(typeof(INativePathService)))
        {
            return this;
        }

        return base.GetService(serviceType);
    }

    protected override Stream DoOpenStream(string contentName, FileMode fileMode, FileAccess fileAccess, FileShare fileShare)
    {
        try
        {
            if (string.IsNullOrEmpty(contentName) || contentName == Native.GetInstance().DefaultContentName)
                return new FileStream(fileInfo.FullName, fileMode, fileAccess, fileShare);
            return Native.GetInstance().OpenAlternateContentStream
            (
                fileInfo.FullName,
                contentName,
                fileMode, fileAccess, fileShare
            );
        }
        catch (FileNotFoundException)
        {
            throw new FileNodeNotFoundException(Address);
        }
    }

    protected override Stream DoGetInputStream(string contentName, out string encoding, FileMode mode, FileShare sharing)
    {
        encoding = null;

        try
        {
            if (string.IsNullOrEmpty(contentName)
                || contentName == Native.GetInstance().DefaultContentName)
            {
                for (var i = 0; i < 10; i++)
                    try
                    {
                        return new FileStream(fileInfo.FullName, mode, FileAccess.Read, sharing);
                    }
                    catch (DirectoryNotFoundException)
                    {
                        throw;
                    }
                    catch (FileNotFoundException)
                    {
                        throw;
                    }
                    catch (IOException)
                    {
                        if (i == 9) throw;

                        Thread.Sleep(500);
                    }

                throw new IOException();
            }

            return Native.GetInstance().OpenAlternateContentStream
            (
                fileInfo.FullName,
                contentName,
                mode, FileAccess.Read, sharing
            );
        }
        catch (FileNotFoundException)
        {
            throw new FileNodeNotFoundException(Address);
        }
        catch (DirectoryNotFoundException)
        {
            throw new DirectoryNodeNotFoundException(Address);
        }
    }

    protected override Stream DoGetOutputStream(string contentName, string? encoding, FileMode mode, FileShare sharing)
    {
        try
        {
            if (string.IsNullOrEmpty(contentName) || contentName == Native.GetInstance().DefaultContentName)
                return new FileStream(fileInfo.FullName, mode, FileAccess.Write, sharing);
            return Native.GetInstance().OpenAlternateContentStream
            (
                fileInfo.FullName,
                contentName,
                mode, FileAccess.Write, sharing
            );
        }
        catch (FileNotFoundException)
        {
            throw new FileNodeNotFoundException(Address);
        }
        catch (DirectoryNotFoundException)
        {
            throw new DirectoryNodeNotFoundException(Address);
        }
    }

    protected override INodeAttributes CreateAttributes()
    {
        return new AutoRefreshingFileAttributes(new LocalFileAttributes(this, fileInfo), -1);
    }

    protected override bool SupportsAlternateContent()
    {
        return true;
    }

    public override IEnumerable<string> GetContentNames()
    {
        return Native.GetInstance().GetContentInfos(((LocalNodeAddress)Address).AbsoluteNativePath).Select(contentInfo => contentInfo.Name);
    }

    protected override void DeleteContent(string contentName)
    {
        if (contentName == null) contentName = Native.GetInstance().DefaultContentName;

        try
        {
            Native.GetInstance().DeleteFileContent(((LocalNodeAddress)Address).AbsoluteNativePath, contentName);
        }
        catch (FileNotFoundException)
        {
            throw new FileNodeNotFoundException(Address);
        }
        catch (DirectoryNotFoundException)
        {
            throw new DirectoryNodeNotFoundException(Address);
        }
    }

    protected override INode DoRenameTo(string name, bool overwrite)
    {
        name = StringUriUtils.RemoveQuery(name);

        var destPath = Path.Combine(fileInfo.DirectoryName, name);

        for (var i = 0; i < 5; i++)
            try
            {
                if (overwrite) File.Delete(destPath);

                //
                // Don't use FileInfo.MoveTo as it changes the existing FileInfo
                // use the new path.
                //

                File.Move(fileInfo.FullName, destPath);
                fileInfo.Refresh();

                break;
            }
            catch (IOException)
            {
                if (i == 4) throw;

                Thread.Sleep(500);
            }

        return this;
    }

    protected override IFile DoCreateHardLink(IFile targetFile, bool overwrite)
    {
        string target;
        var path = fileInfo.FullName;

        try
        {
            var service = (INativePathService)targetFile.GetService(typeof(INativePathService));

            target = service.GetNativePath();
        }
        catch (NotSupportedException)
        {
            throw new NotSupportedException();
        }

        targetFile.Refresh();

        if (Exists && !overwrite)
            throw new IOException("Hardlink already exists");
        ActionUtils.ToRetryAction<object>
        (
            delegate
            {
                if (Exists) Delete();

                try
                {
                    Native.GetInstance().CreateHardLink(path, target);
                }
                catch (TooManyLinksException)
                {
                    throw new TooManyLinksException(this, targetFile);
                }
            },
            TimeSpan.FromSeconds(3), TimeSpan.FromSeconds(0.25)
        )(null);

        return this;
    }

    private class LocalFileMovingService
        : AbstractRunnableService
    {
        private readonly LocalFile destinationFile;
        private readonly LocalFile localFile;
        private readonly bool overwrite;
        private readonly MutableMeter progress = new(0, 1, 0, "files");

        public LocalFileMovingService(LocalFile localFile, LocalFile destinationFile, bool overwrite)
        {
            this.localFile = localFile;
            this.destinationFile = destinationFile;
            this.overwrite = overwrite;
        }

        public override IMeter Progress => progress;

        public override void DoRun()
        {
            progress.SetCurrentValue(0);
            localFile.DoMoveTo(destinationFile, overwrite);
            progress.SetCurrentValue(1);
        }
    }
}