using System.Diagnostics;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Local;

public class LocalFileSystem
    : AbstractFileSystem
{
    private FileSystemActivityEventHandler ActivityEvent;

    private volatile int activityListenerCount;

    private volatile bool disposed;

    private object fileSystemMonitorLock = new();
    private FileSystemWatcher fileSystemWatcherDirectory;
    private FileSystemWatcher fileSystemWatcherFile;

    private volatile bool fileSystemWatcherInitialised;

    public LocalFileSystem(INodeAddress rootAddress, FileSystemOptions? options)
        : base(rootAddress, null, options)
    {
    }

    public override bool SupportsSeeking => true;

    public override bool SupportsActivityEvents => true;

    public override int MaximumPathLength
    {
        get
        {
            switch (Environment.OSVersion.Platform)
            {
                case PlatformID.Win32NT:
                    return 255 - ((LocalNodeAddress)RootAddress).RootPart.Length - 1;
                case PlatformID.Win32S:
                case PlatformID.Win32Windows:
                case PlatformID.WinCE:
                default:
                    return 255 - ((LocalNodeAddress)RootAddress).RootPart.Length - 1;
            }
        }
    }

    public override bool IsDisposed => disposed;

    internal static event EventHandler<LocalFileSystemEventArgs> DirectoryDeleted;

    internal static void OnDirectoryDeleted(LocalFileSystemEventArgs eventArgs)
    {
        if (DirectoryDeleted != null) DirectoryDeleted(null, eventArgs);
    }

    public override event FileSystemActivityEventHandler Activity
    {
        add
        {
            lock (this)
            {
                if (!fileSystemWatcherInitialised) InitializeFsw();

                ActivityEvent += value;

                if (activityListenerCount == 0)
                    try
                    {
                        fileSystemWatcherFile.EnableRaisingEvents = true;
                        fileSystemWatcherDirectory.EnableRaisingEvents = true;
                    }
                    catch (Exception)
                    {
                    }

                activityListenerCount++;
            }
        }
        remove
        {
            lock (this)
            {
                if (!fileSystemWatcherInitialised) InitializeFsw();

                ActivityEvent -= value;

                activityListenerCount--;

                if (activityListenerCount == 0)
                {
                    fileSystemWatcherFile.EnableRaisingEvents = false;
                    fileSystemWatcherDirectory.EnableRaisingEvents = false;
                }
            }
        }
    }

    protected virtual void OnActivityEvent(FileSystemActivityEventArgs eventArgs)
    {
        if (ActivityEvent != null)
        {
            if (SecurityManager.CurrentContext.IsEmpty)
            {
                ActivityEvent(this, eventArgs);
            }
            else
            {
                INode node;

                node = Resolve(eventArgs.Path, eventArgs.NodeType);

                if (SecurityManager.CurrentContext.HasAccess(new AccessVerificationContext(node, FileSystemSecuredOperation.View)))
                    ActivityEvent(this, eventArgs);
            }
        }
    }

    private void InitializeFsw()
    {
        lock (this)
        {
            if (fileSystemWatcherInitialised) return;

            WeakReference weakref;
            EventHandler<LocalFileSystemEventArgs> handler = null;

            weakref = new WeakReference(this);

            handler = delegate(object sender, LocalFileSystemEventArgs eventArgs)
            {
                var _this = (LocalFileSystem)weakref.Target;

                if (_this == null)
                {
                    DirectoryDeleted -= handler;

                    return;
                }

                string s;

                s = ((LocalDirectory)eventArgs.Directory).directoryInfo.FullName;

                if (PathsEqual(((LocalNodeAddress)RootAddress).AbsoluteNativePath, s, s.Length))
                {
                    // This allows the directory to be deleted

                    fileSystemWatcherDirectory.EnableRaisingEvents = false;
                    fileSystemWatcherFile.EnableRaisingEvents = false;

                    // TODO: Use file system watcher from level above to allow
                    // events to still be fired if the directory gets recreated
                }
            };

            DirectoryDeleted += handler;

            // We need two different watchers since we need to determine if the renamed/created/deleted events
            // occured on a file or a directory.
            // Changed events occur on both dirs and files regardless of the NotifyFilters setting so the
            // File watcher will be responsible for handling that.

            DriveInfo driveInfo;

            try
            {
                driveInfo = new DriveInfo(((LocalNodeAddress)RootAddress).AbsoluteNativePath);
            }
            catch (ArgumentException)
            {
                driveInfo = null;
            }

            if (driveInfo == null || (driveInfo != null && driveInfo.DriveType != DriveType.Removable))
            {
                if (!Directory.Exists(((LocalNodeAddress)RootAddress).AbsoluteNativePath))
                    // TODO: Use directory above

                    return;

                string path;

                path = ((LocalNodeAddress)RootAddress).AbsoluteNativePath;

                path = path.TrimEnd('/', '\\');

                if (Environment.OSVersion.Platform != PlatformID.Unix)
                    if (Path.GetDirectoryName(path) != null)
                        path = Path.GetDirectoryName(path);

                if (!path.EndsWith(Path.DirectorySeparatorChar.ToString())) path += Path.DirectorySeparatorChar;

                fileSystemWatcherFile = new FileSystemWatcher(path);
                fileSystemWatcherFile.InternalBufferSize = 64 * 1024 /* 128K buffer */;
                fileSystemWatcherFile.IncludeSubdirectories = true;
                fileSystemWatcherFile.NotifyFilter =
                    NotifyFilters.Attributes | NotifyFilters.CreationTime | NotifyFilters.FileName /* Files only */
                    | NotifyFilters.LastAccess | NotifyFilters.LastWrite /*| NotifyFilters.Security | NotifyFilters.Size*/;

                fileSystemWatcherFile.Renamed += FileSystemWatcher_Renamed;
                fileSystemWatcherFile.Changed += FileSystemWatcher_Changed;
                fileSystemWatcherFile.Created += FileSystemWatcher_Created;
                fileSystemWatcherFile.Deleted += FileSystemWatcher_Deleted;
                fileSystemWatcherFile.Error += FileSystemWatcher_Error;

                fileSystemWatcherDirectory = new FileSystemWatcher(path);
                fileSystemWatcherDirectory.InternalBufferSize = 64 * 1024;
                fileSystemWatcherDirectory.IncludeSubdirectories = true;
                fileSystemWatcherDirectory.NotifyFilter =
                    NotifyFilters.Attributes | NotifyFilters.CreationTime | NotifyFilters.DirectoryName /* Dirs only */
                    | NotifyFilters.LastAccess | NotifyFilters.LastWrite /*| NotifyFilters.Security | NotifyFilters.Size*/;

                fileSystemWatcherDirectory.Filter = "*";
                fileSystemWatcherDirectory.Renamed += FileSystemWatcher_Renamed;
                fileSystemWatcherDirectory.Created += FileSystemWatcher_Created;
                fileSystemWatcherDirectory.Deleted += FileSystemWatcher_Deleted;
                //fileSystemWatcherDirectory.Changed += new FileSystemEventHandler(FileSystemWatcher_Changed);
                fileSystemWatcherDirectory.Error += FileSystemWatcher_Error;

                fileSystemWatcherInitialised = true;
            }
        }
    }

    private void FileSystemWatcher_Error(object sender, ErrorEventArgs e)
    {
        Trace.WriteLine("FileSystemWatcher generated an error: " + e.GetException().Message, "FileSystemWatcher");
    }

    private void FileSystemWatcher_Renamed(object sender, RenamedEventArgs e)
    {
        if (ActivityEvent != null)
        {
            NodeType nodeType;

            if (!e.FullPath.StartsWith(((LocalNodeAddress)RootAddress).AbsoluteNativePath)) return;

            nodeType = sender == fileSystemWatcherFile ? NodeType.File : NodeType.Directory;

            OnActivityEvent(new FileSystemRenamedActivityEventArgs(FileSystemActivity.Renamed,
                nodeType,
                Path.GetFileName(e.OldName),
                StringUriUtils.NormalizePath(
                    e.OldFullPath.Substring(
                        fileSystemWatcherFile.Path.Length - 1)),
                Path.GetFileName(e.Name),
                StringUriUtils.NormalizePath(
                    e.FullPath.Substring(
                        ((LocalNodeAddress)RootAddress).AbsoluteNativePath.Length - 1))));
        }
    }

    private void FileSystemWatcher_Changed(object sender, FileSystemEventArgs e)
    {
        if (ActivityEvent != null)
        {
            NodeType nodeType;

            if (!e.FullPath.StartsWith(((LocalNodeAddress)RootAddress).AbsoluteNativePath)) return;

            /*
             * There is a race here between when the watcher sees the event and when it is processed
             * which may mean that a changed event meant for a dir goes to a file (or vice versa).
             * There's nothing we can do about it but since the Changed event is pretty opaque
             * (users will have to figure what has changed anyway) it doesn't matter too much.
             */

            nodeType = GetNodeType(e.FullPath.Substring(((LocalNodeAddress)RootAddress).AbsoluteNativePath.Length - 1));

            if (nodeType == NodeType.None)
            {
                OnActivityEvent(new FileSystemActivityEventArgs(FileSystemActivity.Changed, NodeType.File, e.Name,
                    StringUriUtils.NormalizePath(
                        e.FullPath.Substring(
                            ((LocalNodeAddress)RootAddress).AbsoluteNativePath.Length -
                            1))));

                OnActivityEvent(new FileSystemActivityEventArgs(FileSystemActivity.Changed, NodeType.Directory, e.Name,
                    StringUriUtils.NormalizePath(
                        e.FullPath.Substring(
                            ((LocalNodeAddress)RootAddress).AbsoluteNativePath.Length -
                            1))));

                return;
            }

            OnActivityEvent(new FileSystemActivityEventArgs(FileSystemActivity.Changed, nodeType, e.Name,
                StringUriUtils.NormalizePath(
                    e.FullPath.Substring(
                        ((LocalNodeAddress)RootAddress).AbsoluteNativePath.Length -
                        1))));
        }
    }

    private void FileSystemWatcher_Created(object sender, FileSystemEventArgs e)
    {
        if (ActivityEvent != null)
        {
            NodeType nodeType;

            if (!e.FullPath.StartsWith(((LocalNodeAddress)RootAddress).AbsoluteNativePath)) return;

            nodeType = sender == fileSystemWatcherFile ? NodeType.File : NodeType.Directory;

            OnActivityEvent(new FileSystemActivityEventArgs(FileSystemActivity.Created, nodeType, e.Name,
                StringUriUtils.NormalizePath(
                    e.FullPath.Substring(
                        ((LocalNodeAddress)RootAddress).AbsoluteNativePath.Length -
                        1))));
        }
    }

    private void FileSystemWatcher_Deleted(object sender, FileSystemEventArgs e)
    {
        if (ActivityEvent != null)
        {
            NodeType nodeType;

            if (!e.FullPath.StartsWith(((LocalNodeAddress)RootAddress).AbsoluteNativePath)) return;

            nodeType = sender == fileSystemWatcherFile ? NodeType.File : NodeType.Directory;

            OnActivityEvent(new FileSystemActivityEventArgs(FileSystemActivity.Deleted, nodeType, e.Name,
                StringUriUtils.NormalizePath(
                    e.FullPath.Substring(
                        ((LocalNodeAddress)RootAddress).AbsoluteNativePath.Length -
                        1))));
        }
    }

    public override INode Resolve(INodeAddress address, NodeType nodeType)
    {
        if (nodeType == NodeType.Any)
        {
            INode node;

            node = Resolve(address, NodeType.File);

            if (node.Exists) return node;

            node = Resolve(address, NodeType.Directory);

            if (node.Exists) return node;

            return base.Resolve(address, NodeType.File);
        }

        // LocalFileSystem always refreshes node before returning it

        return base.Resolve(address, nodeType).Refresh();
    }

    /// <summary>
    ///     <see cref="INode.Resolve(string, NodeType, AddressScope)" />
    /// </summary>
    protected override INode CreateNode(INodeAddress address, NodeType nodeType)
    {
        if (nodeType == NodeType.File) return new LocalFile(this, (LocalNodeAddress)address);

        if (nodeType == NodeType.Directory) return new LocalDirectory(this, (LocalNodeAddress)address);

        if (nodeType == NodeType.Any)
        {
            if (Directory.Exists(address.RootUri + address.AbsolutePath))
                return new LocalDirectory(this, (LocalNodeAddress)address);
            return new LocalFile(this, (LocalNodeAddress)address);
        }

        throw new NodeTypeNotSupportedException(nodeType);
    }

    public override bool PathsEqual(string path1, string path2, int length)
    {
        if (Environment.OSVersion.Platform == PlatformID.Unix)
        {
            if (length > path1.Length || length > path2.Length) return false;

            for (var i = 0; i < length; i++)
                if (!path1[i].Equals(path2[i]))
                    return false;

            return true;
        }

        return base.PathsEqual(path1, path2, length);
    }

    protected internal virtual void CheckDisposed()
    {
        if (disposed) throw new ObjectDisposedException("LocalFileSystem: " + RootAddress.Uri);
    }

    protected override void Dispose(bool disposing)
    {
        try
        {
            disposed = true;

            fileSystemWatcherDirectory.EnableRaisingEvents = false;
            fileSystemWatcherFile.EnableRaisingEvents = false;
        }
        catch
        {
        }
    }
}