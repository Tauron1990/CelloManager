namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Local;

public class NativeManaged
    : Native
{
}