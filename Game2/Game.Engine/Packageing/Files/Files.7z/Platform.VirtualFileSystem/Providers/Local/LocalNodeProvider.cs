namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Local;

public class LocalNodeProvider
    : AbstractMultiFileSystemNodeProvider
{
    private readonly Configuration configuration;
    private readonly Dictionary<FileSystemOptions?, FileSystemOptions> modifiedFileSystemOptions = new();

    public LocalNodeProvider(IFileSystemManager manager)
        : this(manager, new Configuration())
    {
    }

    public LocalNodeProvider(IFileSystemManager manager, Configuration config)
        : base(manager)
    {
        configuration = config;
    }

    public override string[] SupportedUriSchemas
    {
        get
        {
            return new[] { "file" };
            ;
        }
    }

    public override bool SupportsUri(string uri)
    {
        if (LocalNodeAddress.CanParse(uri)) return true;

        return base.SupportsUri(uri);
    }

    protected override INodeAddress ParseUri(string uri)
    {
        return LocalNodeAddress.Parse(uri);
    }

    protected override IFileSystem NewFileSystem(INodeAddress rootAddress, FileSystemOptions? options, out bool cache)
    {
        FileSystemOptions? modifiedOptions;

        if (!modifiedFileSystemOptions.TryGetValue(options, out modifiedOptions))
        {
            modifiedOptions = options.CreateWithAdditionalConfig(configuration);

            modifiedFileSystemOptions[options] = modifiedOptions;
        }

        cache = true;

        return new LocalFileSystem(rootAddress, modifiedOptions);
    }

    public class Configuration
        : NodeProviderConfiguration
    {
    }
}