using System.Text.RegularExpressions;
using Platform;
using Platform.Text;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Local;

[Serializable]
public class LocalNodeAddress
    : AbstractNodeAddressWithRootPart
{
    public const string LowerAlphabet = "abcdefghijklmnopqrstuvwxyz";
    public const string UpperAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static readonly Regex localFileNameRegEx;

    private static readonly char[] validFileNameChars;
    private static readonly string validFileNameString;

    [ThreadStatic]
    private static string lastCanParseUri;

    [ThreadStatic]
    private static Match lastCanParseMatch;

    private readonly bool includeRootPartInUri;

    static LocalNodeAddress()
    {
        string exp;

        validFileNameChars = (@"\-+,;=\[\].$%_@~`!(){}^#&-" + UpperAlphabet + LowerAlphabet).ToCharArray();

        Array.Sort(validFileNameChars);

        validFileNameString = validFileNameChars.ToString();

        exp =
            @"
						# The optional file:// part

						[ ]*

						^(((?<scheme>[a-z]*)\:[\\/]{2,2})?)

						(
							# UNC paths

							(
								([\\/]{2,2})
								(?<uncserver>(([a-zA-Z\-\.0-9]*)|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})))
								#(?<path1>([ \\/][\-+,;=\[\].$%_@~`!(){}^#&a-zA-Z0-9\\/]*)*)  (\?(?<query>(.*)))?$
								#(?<path1>([^\?\""\<\>\|\/\\\*:]*)*)  (\?(?<query>(.*)))?$
								(?<path1>([/\\] [^\?\""\<\>\|\/\*:\\]+)+[/\\]? | [/\\]?)
								(\?(?<query>(.*)))?$
							)

							|

							# Windows paths

							
							(
								(?<root>([a-zA-Z]\:))
								(?<path2>([/\\] [^\?\""\<\>\|\/\*:\\]+)+[/\\]? | [/\\]?)
								#(?<path2>[/\\]? | ([/\\] [ \-\+,;=\[\].$%_@~`!(){}^#&\p{N}\p{L}]+)+[/\\]?)
								(\?(?<query>(.*)))?$
							)

							|

							# UNIX paths

							(
								#(?<path3>/ | /([ \-\+,;=\[\].$%_@~`!(){}^#&a-zA-Z0-9]+)+/?)     (\?(?<query>(.*)))?$
								#(?<path3>/ | /([^\?\""\<\>\|\/\\\*:]+)+/?)     (\?(?<query>(.*)))?$
								(?<path3>([/] [^\?\""\<\>\|\/\*:]+)+[/]? | [/\\]?)
								(\?(?<query>(.*)))?$
							)

							|

							# Relative Paths

							(
								(?<path4>([/\\]? | (([\.]{1,2}[/\\]?)|([\.]{1,2}[/\\])+) (([/] [^\?\""\<\>\|\/\*:]+)+[/]? | [/\\]?)?  ))
								(\?(?<query>(.*)))?$
							)
						)

						[ ]*
				";

        localFileNameRegEx = new Regex
        (
            exp,
            RegexOptions.ExplicitCapture |
            RegexOptions.IgnoreCase |
            RegexOptions.IgnorePatternWhitespace |
            RegexOptions.Compiled |
            RegexOptions.CultureInvariant
        );
    }

    public LocalNodeAddress(string scheme, string rootPart, bool includeRootPartInUri, string path)
        : this(scheme, rootPart, includeRootPartInUri, path, "")
    {
    }

    public LocalNodeAddress(string scheme, string rootPart, bool includeRootPartInUri, string path, string query)
        : base(scheme, rootPart, path, query)
    {
        this.includeRootPartInUri = includeRootPartInUri;
    }

    public virtual string AbsoluteNativePath
    {
        get
        {
            string s;

            s = RootPart + TextConversion.FromEscapedHexString(AbsolutePath);

            if (Path.DirectorySeparatorChar != '/') s = s.Replace(Path.DirectorySeparatorChar, '/');

            s = Path.GetFullPath(s);

            return s;
        }
    }

    public static bool IsValidFileNameChar(char c)
    {
        return Array.BinarySearch(validFileNameChars, c) >= 0;
    }

    public static bool CanParse(string uri)
    {
        return CanParse(uri, "file");
    }

    public static bool CanParse(string uri, string scheme)
    {
        if (!((uri.Length >= 2 && char.IsLetter(uri[0]) && uri[1] == ':') || uri == null || (uri != null
                                                                                             && uri.StartsWith(scheme,
                                                                                                 StringComparison.CurrentCultureIgnoreCase)) ||
              uri.StartsWith("/") || uri.StartsWith(@"\") || uri == "." || uri == ".." || uri.StartsWith("./") || uri.StartsWith("../") ||
              uri.StartsWith(".\\") || uri.StartsWith("..\\")))
            // Fast fail path out.

            return false;

        if (lastCanParseUri == uri && lastCanParseMatch != null && lastCanParseMatch.Success) return true;

        // Use regular expression to totally verify.

        lastCanParseUri = uri;
        lastCanParseMatch = localFileNameRegEx.Match(uri);

        return lastCanParseMatch.Success;
    }

    public static LocalNodeAddress Parse(string uri)
    {
        Group group;
        Match match = null;
        string root, scheme, query;

        // Often Parse will be called with the exact same URI reference that was last passed
        // to CanParse.  If this is the case then use the results cached by the last call to
        // CanParse from this thread.

        if (uri == (object)lastCanParseUri) match = lastCanParseMatch;

        while (true)
        {
            if (match == null) match = localFileNameRegEx.Match(uri);

            if (!match.Success) throw new MalformedUriException(uri);

            bool schemeExplicitlyProvided;

            group = match.Groups["scheme"];

            if (group.Value == "")
            {
                scheme = "file";
                schemeExplicitlyProvided = false;
            }
            else
            {
                scheme = group.Value;
                schemeExplicitlyProvided = true;
            }

            group = match.Groups["uncserver"];

            if (group.Success)
            {
                string path;
                Pair<string, string> result;

                path = match.Groups["path1"].Value;

                result = path.SplitAroundCharFromLeft(1, PredicateUtils.ObjectEqualsAny('\\', '/'));

                root = "//" + group.Value + result.Left.Replace('\\', '/');
                path = "/" + result.Right;

                if (path == "") path = "/";

                query = match.Groups["query"].Value;

                return new LocalNodeAddress(scheme, root, true, StringUriUtils.NormalizePath(path), query);
            }
            else
            {
                string path;

                group = match.Groups["root"];

                if (group.Captures.Count > 0)
                {
                    //
                    // Windows path specification
                    //

                    root = group.Value;

                    path = match.Groups["path2"].Value;

                    if (path.Length == 0) path = FileSystemManager.SeperatorString;

                    query = match.Groups["query"].Value;

                    path = StringUriUtils.NormalizePath(path);

                    if (schemeExplicitlyProvided)
                    {
                        //
                        // Explicitly provided scheme means
                        // special characters are hexcoded
                        //

                        path = TextConversion.FromEscapedHexString(path);
                        query = TextConversion.FromEscapedHexString(query);
                    }

                    return new LocalNodeAddress(scheme, root, true, path, query);
                }

                if (match.Groups["path3"].Value != "")
                {
                    //
                    // Unix path specification
                    //

                    path = match.Groups["path3"].Value;
                    query = match.Groups["query"].Value;

                    path = StringUriUtils.NormalizePath(path);

                    if (schemeExplicitlyProvided)
                    {
                        //
                        // Explicitly provided scheme means
                        // special characters are hexcoded
                        //

                        path = TextConversion.FromEscapedHexString(path);
                        query = TextConversion.FromEscapedHexString(query);
                    }

                    return new LocalNodeAddress(scheme, "", true, path, query);
                }
                //
                // Relative path specification
                //

                path = match.Groups["path4"].Value;
                query = match.Groups["query"].Value;

                path = StringUriUtils.Combine(Environment.CurrentDirectory, path);
                path = StringUriUtils.NormalizePath(path);

                if (!string.IsNullOrEmpty(query))
                    query = "?" + query;
                else
                    query = "";

                if (schemeExplicitlyProvided)
                    uri = scheme + "://" + path + "query";
                else
                    uri = path + query;

                match = null;
            }
        }
    }

    protected override INodeAddress CreateAddress(string path, string query)
    {
        if (GetType() == typeof(LocalNodeAddress))
            return new LocalNodeAddress(Scheme, RootPart, includeRootPartInUri, path, query);
        return (LocalNodeAddress)Activator.CreateInstance(GetType(), Scheme, RootPart, includeRootPartInUri, path, query);
    }

    protected override string GetRootUri()
    {
        if (includeRootPartInUri)
            return Scheme + "://" + RootPart;
        return Scheme + "://";
    }

    public override INodeAddress CreateAsRoot(string scheme)
    {
        if (AbsolutePath == FileSystemManager.RootPath)
            return new LocalNodeAddress(scheme, RootPart, false, "/");
        return new LocalNodeAddress(scheme, RootPart + AbsolutePath, false, "/");
    }
}