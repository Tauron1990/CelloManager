using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

[PublicAPI]
public abstract class AbstractDirectoryHashingService : AbstractHashingService, IDirectoryHashingService
{
    protected AbstractDirectoryHashingService(IDirectory dir, DirectoryHashingServiceType serviceType)
        : base(dir, serviceType)
    {
        ServiceType = serviceType;
    }

    public new DirectoryHashingServiceType ServiceType { get; }

    public new IDirectory OperatingNode => (IDirectory)base.OperatingNode;
}