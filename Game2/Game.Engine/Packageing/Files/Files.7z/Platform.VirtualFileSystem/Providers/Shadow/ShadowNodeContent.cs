using System.Security.Cryptography;
using System.Text;
using System.Timers;
using Platform;
using Platform.IO;
using Platform.Text;
using Timer = System.Threading.Timer;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Shadow;

/// <summary>
///     Summary description for ShadowNodeContent.
/// </summary>
internal class ShadowNodeContent
    : AbstractNodeContent
{
    private readonly ShadowFile shadowFile;
    private readonly IFileSystem tempFileSystem;
    internal DateTime creationTime;
    private IFile file;
    internal bool hasCreationTime;
    internal bool hasLastWriteTime;
    internal DateTime lastWriteTime;

    internal long targetLength = -1;
    internal byte[] targetMd5;

    public ShadowNodeContent(ShadowFile shadowFile, IFile file, IFileSystem tempFileSystem)
    {
        var buffer = new StringBuilder(file.Address.Uri.Length * 3);

        this.shadowFile = shadowFile;
        this.tempFileSystem = tempFileSystem;
        this.file = tempFileSystem.ResolveFile(GenerateName());

        buffer.Append(ComputeHash(file.Address.Uri).TrimRight('='));

        var value = (string)file.Address.QueryValues["length"];

        if (value != null)
        {
            targetLength = Convert.ToInt64(value);

            buffer.Append('_').Append(value);
        }

        value = (string)file.Address.QueryValues["md5sum"];

        if (value != null)
        {
            targetMd5 = Convert.FromBase64String(value);

            buffer.Append('_').Append(value);
        }

        value = (string)file.Address.QueryValues["creationtime"];

        if (value != null)
        {
            hasCreationTime = true;
            creationTime = Convert.ToDateTime(value);

            buffer.Append('_').Append(creationTime.Ticks.ToString());
        }

        value = (string)file.Address.QueryValues["writetime"];

        if (value != null)
        {
            hasLastWriteTime = true;
            lastWriteTime = Convert.ToDateTime(value);

            buffer.Append('_').Append(lastWriteTime.Ticks.ToString());
        }

        value = buffer.ToString();
    }

    private static string ComputeHash(string s)
    {
        var encoding = Encoding.ASCII;
        var algorithm = new MD5CryptoServiceProvider();
        var output = algorithm.ComputeHash(encoding.GetBytes(s));

        return TextConversion.ToBase32String(output);
    }

    protected virtual string GenerateName()
    {
        return "VFSSHADOWS.TMP/" + Guid.NewGuid().ToString("N") + "." + shadowFile.Address.Extension;
    }

    public override Stream GetInputStream()
    {
        string encoding;

        return GetInputStream(out encoding);
    }

    internal IFile GetReadFile(TimeSpan timeout)
    {
        lock (this)
        {
            var timer = new Timer(timeout.TotalMilliseconds);

            timer.Elapsed += new ElapsedEventHandler(new StreamCloser(GetInputStream(), timer).TimerElapsed);
            timer.AutoReset = false;
            timer.Start();

            return file;
        }
    }

    public override void Delete()
    {
        shadowFile.GetContent().Delete();
    }

    protected override Stream DoGetInputStream(out string encoding, FileMode mode, FileShare sharing)
    {
        Stream retval;

        lock (this)
        {
            long? length = 0;
            var error = false;
            DateTime? creationTime = null;
            DateTime? lastWriteTime = null;

            file.Attributes.Refresh();
            shadowFile.Attributes.Refresh();

            try
            {
                if (file.Exists)
                {
                    length = file.Length ?? 0;
                    creationTime = file.Attributes.CreationTime;
                    lastWriteTime = file.Attributes.LastWriteTime;
                }
                else
                {
                    error = true;
                }
            }
            catch (IOException)
            {
                error = true;
            }

            if (!error
                && length == shadowFile.Length
                && creationTime == shadowFile.Attributes.CreationTime
                && lastWriteTime == shadowFile.Attributes.LastWriteTime
                && (mode == FileMode.Open || mode == FileMode.OpenOrCreate))
                try
                {
                    retval = new ShadowInputStream(file.GetContent().GetInputStream(out encoding, sharing), file);

                    return retval;
                }
                catch (IOException)
                {
                }

            file = tempFileSystem.ResolveFile(GenerateName());

            switch (mode)
            {
                case FileMode.Create:
                    file.Create();
                    break;
                case FileMode.CreateNew:
                    if (shadowFile.Exists) throw new IOException("File exists");
                    file.Create();
                    break;
                case FileMode.OpenOrCreate:
                    try
                    {
                        shadowFile.CopyTo(file, true);
                    }
                    catch (FileNotFoundException)
                    {
                        file.Create();
                    }

                    break;
                case FileMode.Open:
                default:
                    file.ParentDirectory.Create(true);
                    shadowFile.CopyTo(file, true);
                    break;
            }

            file.Attributes.CreationTime = shadowFile.Attributes.CreationTime;
            file.Attributes.LastWriteTime = shadowFile.Attributes.LastWriteTime;

            retval = new ShadowInputStream(file.GetContent().GetInputStream(out encoding, sharing), file);

            return retval;
        }
    }

    protected override Stream DoGetOutputStream(string? encoding, FileMode mode, FileShare sharing)
    {
        IFile file;

        file = tempFileSystem.ResolveFile(GenerateName());

        switch (mode)
        {
            case FileMode.Truncate:
                file.Create();
                break;
        }

        return new ShadowOutputStream(file.GetContent().GetOutputStream(encoding, sharing), shadowFile.ShadowedFile, file);
    }

    private class ShadowOutputStream
        : StreamWrapper
    {
        private readonly IFile file;
        private readonly IFile shadowFile;

        public ShadowOutputStream(Stream stream, IFile shadowedFile, IFile file)
            : base(stream)
        {
            this.file = file;
            shadowFile = shadowedFile;
        }

        public override void Close()
        {
            base.Close();

            var dest = shadowFile.ParentDirectory.ResolveFile(file.Address.Name);

            file.MoveTo(dest.ParentDirectory, true);
            dest.RenameTo(shadowFile.Address.Name, true);
        }
    }

    private class ShadowInputStream
        : StreamWrapper
    {
        private readonly IFile file;

        private bool closed;
        private Timer timer;

        public ShadowInputStream(Stream stream, IFile file)
            : base(stream)
        {
            this.file = file;

            SetupTimer();
        }

        ~ShadowInputStream()
        {
            Close();
        }

        private void SetupTimer()
        {
            TimeSpan period;

            period = TimeSpan.FromMinutes(30);

            if (timer != null) timer.Dispose();

            timer = new Timer(period.TotalMilliseconds);

            timer.AutoReset = true;
            timer.Elapsed += new ElapsedEventHandler(TimerElapsed);
            timer.Start();
        }

        protected virtual void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            lock (this)
            {
                try
                {
                    file.Delete();

                    timer.Stop();
                    timer.Close();
                }
                catch (Exception)
                {
                }
            }
        }

        public override void Close()
        {
            lock (this)
            {
                if (closed) return;

                closed = true;
            }

            base.Close();

            file.Refresh();

            try
            {
                if (file.Exists) file.Delete();
            }
            catch (Exception)
            {
                SetupTimer();
            }
        }
    }

    private class StreamCloser
    {
        private readonly Stream stream;
        private readonly Timer timer;

        public StreamCloser(Stream stream, Timer timer)
        {
            this.stream = stream;
            this.timer = timer;
        }

        public void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            stream.Close();
            timer.Close();
        }
    }
}