using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public interface ITaskService
    : IService, IRunnable
{
}