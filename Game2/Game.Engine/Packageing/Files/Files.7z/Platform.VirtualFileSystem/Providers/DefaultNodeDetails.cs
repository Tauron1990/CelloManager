namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class DefaultNodeAttributes
    : AbstractTypeBasedNodeAttributes
{
    public DefaultNodeAttributes(INode node)
        : base(node)
    {
    }
}