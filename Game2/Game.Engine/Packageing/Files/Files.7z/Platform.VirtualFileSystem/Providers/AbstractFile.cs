using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

/// <summary>
///     This class provides a skeletal implementation of the <c>IFile</c>interface to minimize the effort
///     required to implement the interface.
///     <seealso cref="IFile" />
/// </summary>
[PublicAPI]
public abstract class AbstractFile : AbstractNode, IFile
{
    protected AbstractFile(INodeAddress fileName, IFileSystem fileSystem)
        : base(fileSystem, fileName)
    {
    }

    IFile IFile.Create() => (IFile)Create();

    IFile IFile.Create(bool createParent) => (IFile)Create(createParent);

    IFile IFile.Refresh() => (IFile)Refresh();

    public new IFileAttributes Attributes
    {
        get
        {
            try
            {
                return (IFileAttributes)base.Attributes;
            }
            catch (InvalidCastException)
            {
                return new NodeToFileAttributes(base.Attributes);
            }
        }
    }

    public override NodeType NodeType => NodeType.File;

    public override IDirectory OperationTargetDirectory => ParentDirectory;

    public virtual long? Length => (long?)Attributes[FileAttributes.Length];

    public virtual bool IdenticalTo(IFile file, FileComparingFlags flags) => IdenticalTo(this, file, flags);

    public virtual IFile CreateAsHardLink(IFile targetFile) => CreateAsHardLink(targetFile, false);

    public virtual IFile CreateAsHardLink(IFile targetFile, bool overwrite) => DoCreateHardLink(targetFile, overwrite);

    public virtual IFile CreateAsHardLink(string path) => CreateAsHardLink(path, false);

    public virtual IFile CreateAsHardLink(string path, bool overwrite) => CreateAsHardLink(FileSystem.ResolveFile(path), overwrite);

    public override INode GetDirectoryOperationTargetNode(IDirectory directory) => directory.ResolveFile(Address.NameAndQuery);

    protected IFile GetOperationTargetDirectoryFile(INode target) => GetOperationTargetDirectoryFile(this, target);

    public static IFile GetOperationTargetDirectoryFile(INode thisNode, INode target)
    {
        IFile file;

        if (Equals(target.NodeType, NodeType.File))
            file = (IFile)target;
        else if (Equals(target.NodeType, NodeType.Directory))
            file = target.ResolveFile(thisNode.Name);
        else
            throw new ArgumentException("Target must be a file or directory.", nameof(target));

        return file;
    }

    public static bool IdenticalTo(IFile thisFile, IFile file, FileComparingFlags flags)
    {
        var service = (IFileComparingService)thisFile.GetService(new FileComparingServiceType(file, flags));

        return service.Compare();
    }

    protected virtual IFile DoCreateHardLink(IFile targetFile, bool overwrite) => throw new NotSupportedException();
}