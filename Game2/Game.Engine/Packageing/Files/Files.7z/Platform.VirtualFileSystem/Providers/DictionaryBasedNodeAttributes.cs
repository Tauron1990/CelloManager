using System.Collections;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class DictionaryBasedNodeAttributesEventArgs
    : EventArgs
{
    public DictionaryBasedNodeAttributesEventArgs(string name, object oldValue, object newValue, bool userSet)
    {
        AttributeName = name;
        OldValue = oldValue;
        NewValue = newValue;
        UserSet = userSet;
    }

    public virtual string AttributeName { get; set; }

    public virtual object NewValue { get; set; }

    public virtual object OldValue { get; set; }

    public virtual bool UserSet { get; set; }
}

public class DictionaryBasedNodeAttributes
    : AbstractNodeAttributes, IFileAttributes
{
    private readonly IDictionary<string, object> attributes;
    private Func<string, object, object> attributeValueGetFilter;

    public DictionaryBasedNodeAttributes()
        : this(attributeName => true)
    {
    }

    public DictionaryBasedNodeAttributes(Predicate<string> supportsAttribute)
        : this(supportsAttribute, new Dictionary<string, object>(StringComparer.CurrentCultureIgnoreCase))
    {
    }

    public DictionaryBasedNodeAttributes(Predicate<string> supportsAttribute, IDictionary<string, object> dictionary)
    {
        attributes = dictionary;
        this.SupportsAttribute = supportsAttribute;
        attributeValueGetFilter = DefaultAttributeValueGetFilter;
    }

    public virtual Func<string, object, object> AttributeValueGetFilter
    {
        get => attributeValueGetFilter;
        set => attributeValueGetFilter = value;
    }

    protected virtual Predicate<string> SupportsAttribute { get; }

    #region IRefreshable Members

    void IRefreshable.Refresh()
    {
        Refresh();
    }

    #endregion

    #region IEnumerable<KeyValuePair<string,object>> Members

    public override IEnumerator<KeyValuePair<string, object>> GetEnumerator()
    {
        foreach (var keyValuePair in attributes)
            if (keyValuePair.Value != null)
                yield return keyValuePair;
    }

    #endregion

    #region IEnumerable Members

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

    #endregion

    public virtual event EventHandler<DictionaryBasedNodeAttributesEventArgs> AttributeValueChanged;

    public virtual void OnAttributeValueChanged(DictionaryBasedNodeAttributesEventArgs eventArgs)
    {
        if (AttributeValueChanged != null) AttributeValueChanged(this, eventArgs);
    }

    public object DefaultAttributeValueGetFilter(string name, object value)
    {
        return value;
    }

    public static bool DefaultSupportsAttribute(string attributeName)
    {
        if (attributeName == "CreationTime"
            || attributeName == "LastAccessTime"
            || attributeName == "LastWriteTime"
            || attributeName == "ReadOnly"
            || attributeName == "Hidden"
            || attributeName == "Exists")
            return true;

        return typeof(INodeAttributes).GetProperty(attributeName) != null;
    }

    #region INodeAttributes Members

    public override INodeAttributesUpdateContext AquireUpdateContext()
    {
        return new StandardNodeAttributesUpdateContext(this);
    }

    public virtual void Clear()
    {
        lock (SyncLock)
        {
            attributes.Clear();
        }
    }

    public override bool? ReadOnly
    {
        get => GetValue<bool?>("ReadOnly");
        set => SetValue("ReadOnly", value, true);
    }

    public override bool? IsHidden
    {
        get => GetValue<bool?>("Hidden");
        set => SetValue("Hidden", value, true);
    }

    public override DateTime? CreationTime
    {
        get => GetValue<DateTime?>("CreationTime");
        set => SetValue("CreationTime", value, true);
    }

    public override DateTime? LastAccessTime
    {
        get => GetValue<DateTime?>("LastWriteTime");
        set => SetValue("LastWriteTime", value, true);
    }

    public override DateTime? LastWriteTime
    {
        get => GetValue<DateTime?>("LastWriteTime");
        set => SetValue("LastWriteTime", value, true);
    }

    public virtual T GetValue<T>(string attributeName)
    {
        object retval;

        if (attributes.TryGetValue(attributeName, out retval))
        {
            if (retval == null)
            {
                return (T)AttributeValueGetFilter(attributeName, default(T));
            }

            if (retval == null) return (T)AttributeValueGetFilter(attributeName, default(T));

            if (typeof(T) == typeof(object)) return (T)AttributeValueGetFilter(attributeName, (T)retval);

            return (T)AttributeValueGetFilter(attributeName, (T)retval);
        }

        return (T)AttributeValueGetFilter(attributeName, default(T));
    }

    public virtual void SetValue<T>(string attributeName, T value)
    {
        SetValue(attributeName, value, false);
    }

    public virtual void SetValue<T>(string attributeName, T value, bool user)
    {
        object oldValue, newValue;

        if (!SupportsAttribute(attributeName.SplitAroundFirstCharFromLeft(':').Left)) return;

        if (!attributes.TryGetValue(attributeName, out oldValue)) oldValue = null;

        if (value == null)
        {
            newValue = null;

            attributes.Remove(attributeName);

            OnAttributeValueChanged(new DictionaryBasedNodeAttributesEventArgs(attributeName, oldValue, newValue, user));
        }
        else if (value.Equals(default(T)))
        {
            newValue = default(T);

            attributes[attributeName] = default(T);

            OnAttributeValueChanged(new DictionaryBasedNodeAttributesEventArgs(attributeName, oldValue, newValue, user));
        }
        else
        {
            if (typeof(T) == typeof(object))
            {
                attributes[attributeName] = newValue = value;
            }
            else if (value.GetType() == typeof(T))
            {
                attributes[attributeName] = newValue = value;
            }
            else
            {
                newValue = Convert.ChangeType
                (
                    value,
                    Nullable.GetUnderlyingType(typeof(T)) ?? typeof(T)
                );

                attributes[attributeName] = newValue;
            }

            OnAttributeValueChanged(new DictionaryBasedNodeAttributesEventArgs(attributeName, oldValue, newValue, user));
        }
    }

    public override bool Exists => GetValue<bool>("Exists");

    protected override object GetValue(string name)
    {
        return GetValue<object>(name);
    }

    protected override void SetValue(string name, object value)
    {
        if (!SupportsAttribute(name)) return;

        SetValue(name, value, true);
    }

    public override INodeAttributes Refresh()
    {
        return this;
    }

    public override IEnumerable<string> Names
    {
        get
        {
            foreach (var pair in attributes)
                if (pair.Value != null)
                    yield return pair.Key;
        }
    }

    public override IEnumerable<object> Values
    {
        get
        {
            foreach (var pair in attributes)
                if (pair.Value != null)
                    yield return pair.Value;
        }
    }

    public override bool Supports(string name)
    {
        object retval;

        if (!attributes.TryGetValue(name, out retval)) return false;

        return retval != null;
    }

    #endregion

    #region ISyncLocked Members

    public override object SyncLock => this;

    public override IAutoLock GetAutoLock()
    {
        if (autoLock == null)
            lock (SyncLock)
            {
                autoLock = FuncUtils.VolatileAssign(() => new AutoLock(this));
            }

        return autoLock;
    }

    private IAutoLock autoLock;

    #endregion

    #region IFileAttributes Members

    public virtual long? Length => GetValue<long?>("length");

    IFileAttributes IFileAttributes.Refresh()
    {
        Refresh();

        return this;
    }

    #endregion
}