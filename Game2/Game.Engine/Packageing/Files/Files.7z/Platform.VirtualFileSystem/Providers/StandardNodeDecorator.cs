namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class StandardNodeDecorator
    : INodeDecorator
{
    public virtual INode Decorate(INode node)
    {
        return node;
    }
}