using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

[PublicAPI]
public abstract class AbstractHashingService : AbstractNodeService, IHashingService
{
    protected AbstractHashingService(INode node, HashingServiceType hashingServiceType)
        : base(node)
    {
        ServiceType = hashingServiceType;
    }

    public HashingServiceType ServiceType { get; }

    public virtual byte[] ComputeHash() => ComputeHash(0, -1);

    public abstract byte[] ComputeHash(long offset, long length);
}