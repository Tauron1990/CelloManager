using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class NodeBackedFileDeletingService
    : AbstractTask, INodeTaskService, INodeDeletingService
{
    private readonly MutableMeter meter;
    private readonly bool recursive;

    public NodeBackedFileDeletingService(INode node, bool recursive)
    {
        this.OperatingNode = node;
        this.recursive = recursive;
        meter = new MutableMeter(0, 1, 0, "nodes");
    }

    public override IMeter Progress => meter;

    public INode OperatingNode { get; }

    public object SyncLock => this;

    public virtual IAutoLock GetAutoLock()
    {
        return new AutoLock(this);
    }

    public virtual IAutoLock AquireAutoLock()
    {
        return GetAutoLock().Lock();
    }

    public override void DoRun()
    {
        lock (this)
        {
            meter.SetCurrentValue(0);

            if (OperatingNode.NodeType == NodeType.Directory && recursive)
                ((IDirectory)OperatingNode).Delete(recursive);
            else
                OperatingNode.Delete();

            meter.SetCurrentValue(1);
        }
    }
}