using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

[PublicAPI]
public abstract class AbstractFileHashingService : AbstractHashingService, IFileHashingService
{
    protected AbstractFileHashingService(IFile file, FileHashingServiceType serviceType)
        : base(file, serviceType) =>
        ServiceType = serviceType;

    public new FileHashingServiceType ServiceType { get; }

    public new IFile OperatingNode => (IFile)base.OperatingNode;
}