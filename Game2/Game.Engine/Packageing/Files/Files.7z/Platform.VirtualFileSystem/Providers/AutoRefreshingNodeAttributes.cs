namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class AutoRefreshingFileAttributes
    : AutoRefreshingNodeAttributes, IFileAttributes
{
    public AutoRefreshingFileAttributes(INodeAttributes details, int autoRefreshCount)
        : base(details, autoRefreshCount)
    {
    }

    public new IFileAttributes Wrappee => (IFileAttributes)base.Wrappee;

    IFileAttributes IFileAttributes.Refresh()
    {
        return (IFileAttributes)Refresh();
    }

    public virtual long? Length
    {
        get
        {
            if (autoRefreshCount == -1 || autoRefreshCount > 0)
            {
                if (autoRefreshCount != -1) autoRefreshCount--;

                Wrappee.Refresh();
            }

            return Wrappee.Length;
        }
    }
}

public class AutoRefreshingNodeAttributes
    : NodeAttributesWrapper
{
    protected int autoRefreshCount;
    protected int orignalAutoRefreshCount;

    /// <summary>
    ///     Construct a new <c>AutoRefreshingNodeAttributes</c> class that automatically
    ///     refreshes the details on every query for a set number of queries.
    /// </summary>
    /// <remarks>
    ///     When <c>localAutoRefreshCount</c> is specified
    /// </remarks>
    /// <param name="details">The underlying details implementation to use.</param>
    /// <param name="autoRefreshCount">
    ///     The minimum number of future queries in which to auto refresh.  -1 means infininty.
    /// </param>
    public AutoRefreshingNodeAttributes(INodeAttributes details, int autoRefreshCount)
        : base(details)
    {
        if (autoRefreshCount < -1) throw new ArgumentOutOfRangeException("Can't be less than -1", "localAutoRefreshCount");

        orignalAutoRefreshCount = this.autoRefreshCount = autoRefreshCount;
    }

    #region INodeAttributes Members

    /// <summary>
    ///     Ensures that the current object will auto refresh for at least the next
    ///     <c>localAutoRefreshCount</c> queries.
    /// </summary>
    /// <remarks>
    ///     If the current object doesn't have an <c>localAutoRefreshCount</c> or if the
    ///     current object already has been set with a higher <c>localAutoRefreshCount</c>
    ///     then this method will have no effect.
    /// </remarks>
    /// <param name="localAutoRefreshCount">The new <c>localAutoRefreshCount</c>.</param>
    public virtual void EnsureAutoRefreshCount(int localAutoRefreshCount)
    {
        lock (this)
        {
            if (autoRefreshCount >= localAutoRefreshCount) return;

            autoRefreshCount = localAutoRefreshCount;
        }
    }

    public override object this[string name]
    {
        get
        {
            if (autoRefreshCount == -1 || autoRefreshCount > 0)
            {
                if (autoRefreshCount != -1) autoRefreshCount--;

                Wrappee.Refresh();
            }

            return base[name];
        }
        set => base[name] = value;
    }

    public override DateTime? CreationTime
    {
        get
        {
            lock (this)
            {
                if (autoRefreshCount == -1 || autoRefreshCount > 0)
                {
                    if (autoRefreshCount != -1) autoRefreshCount--;

                    Wrappee.Refresh();
                }

                return Wrappee.CreationTime;
            }
        }
        set => Wrappee.CreationTime = value;
    }

    public override DateTime? LastAccessTime
    {
        get
        {
            lock (this)
            {
                if (autoRefreshCount == -1 || autoRefreshCount > 0)
                {
                    if (autoRefreshCount != -1) autoRefreshCount--;

                    Wrappee.Refresh();
                }

                return Wrappee.LastAccessTime;
            }
        }
        set => Wrappee.LastAccessTime = value;
    }

    public override DateTime? LastWriteTime
    {
        get
        {
            lock (this)
            {
                if (autoRefreshCount == -1 || autoRefreshCount > 0)
                {
                    if (autoRefreshCount != -1) autoRefreshCount--;

                    Wrappee.Refresh();
                }

                return Wrappee.LastWriteTime;
            }
        }
        set => Wrappee.LastWriteTime = value;
    }

    public override bool Exists
    {
        get
        {
            lock (this)
            {
                if (autoRefreshCount == -1 || autoRefreshCount > 0)
                {
                    if (autoRefreshCount != -1) autoRefreshCount--;

                    Wrappee.Refresh();
                }

                return Wrappee.Exists;
            }
        }
    }

    public override IEnumerator<KeyValuePair<string, object>> GetEnumerator()
    {
        if (autoRefreshCount == -1 || autoRefreshCount > 0) Wrappee.Refresh();

        return base.GetEnumerator();
    }

    public override IEnumerable<string> Names
    {
        get
        {
            if (autoRefreshCount == -1 || autoRefreshCount > 0) Wrappee.Refresh();

            return base.Names;
        }
    }

    public override IEnumerable<object> Values
    {
        get
        {
            if (autoRefreshCount == -1 || autoRefreshCount > 0) Wrappee.Refresh();

            return base.Values;
        }
    }

    public override INodeAttributes Refresh()
    {
        lock (this)
        {
            if (autoRefreshCount == 0) autoRefreshCount = orignalAutoRefreshCount;
        }

        return this;
    }

    #endregion
}