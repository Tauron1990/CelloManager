using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.View;
using Platform.VirtualFileSystem.Providers.View;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Temp;

public class TempNodeProvider : ViewNodeProvider
{
    public TempNodeProvider(IFileSystemManager manager)
        : base(manager, "temp", manager.ResolveDirectory(Path.GetTempPath()).Create(true))
    {
    }

    public TempNodeProvider(IFileSystemManager manager, string scheme, IDirectory root)
        : base(manager, scheme, root)
    {
    }

    public TempNodeProvider(IFileSystemManager manager, string scheme, IDirectory root, FileSystemOptions? options)
        : base(manager, scheme, root, options)
    {
    }

    public TempNodeProvider(IFileSystemManager manager, Configuration options)
        : base(manager, (View.ViewNodeProvider.Configuration)options)
    {
    }

    public new class Configuration
        : View.ViewNodeProvider.Configuration
    {
        public Configuration()
        {
            Create = true;
            Scheme = "temp";
        }

        public Configuration(string scheme, string uri, bool create)
            : base(scheme, uri, create)
        {
        }
    }
}