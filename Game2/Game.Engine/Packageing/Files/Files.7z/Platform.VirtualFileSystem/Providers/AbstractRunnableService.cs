using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public abstract class AbstractRunnableService : ITaskService
{
    public string? Name { get; set; }
}