using System.Collections;
using System.Reflection;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

/// <summary>
///     This class provides a skeletal implementation of the <c>INodeAttributes</c>interface to minimize the effort
///     required to implement the interface.
///     <seealso cref="INodeAttributes" />
/// </summary>
public abstract class AbstractTypeBasedNodeAttributes
    : AbstractNodeAttributes, INodeAttributes
{
    private readonly IList<PropertyInfo> properties;

    protected AbstractTypeBasedNodeAttributes(INode node)
    {
        this.Node = node;

        var type = GetType();

        var propInfos = type.GetProperties(BindingFlags.FlattenHierarchy | BindingFlags.Public | BindingFlags.Instance);

        properties = new List<PropertyInfo>(propInfos.Length);

        foreach (var propInfo in propInfos)
            if (HasCustomAttribute(propInfo, typeof(NodeAttributeAttribute)))
                properties.Add(propInfo);
    }

    protected INode Node { get; }

    public virtual int Count => properties.Count;

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

    public override IEnumerator<KeyValuePair<string, object>> GetEnumerator()
    {
        foreach (var name in Names) yield return new KeyValuePair<string, object>(name, this[name]);
    }

    [NodeAttribute]
    public override bool? ReadOnly
    {
        get => false;
        set { }
    }

    [NodeAttribute]
    public override bool? IsHidden
    {
        get => false;
        set { }
    }

    [NodeAttribute]
    public override DateTime? CreationTime
    {
        get => null;
        set { }
    }

    [NodeAttribute]
    public override DateTime? LastAccessTime
    {
        get => null;
        set { }
    }

    [NodeAttribute]
    public override DateTime? LastWriteTime
    {
        get => null;
        set { }
    }

    [NodeAttribute]
    public override bool Exists => false;

    void IRefreshable.Refresh()
    {
        Refresh();
    }

    public override INodeAttributes Refresh()
    {
        return this;
    }

    public override IEnumerable<string> Names
    {
        get
        {
            foreach (var propInfo in properties) yield return propInfo.Name;
        }
    }

    public override IEnumerable<object> Values
    {
        get
        {
            foreach (var propInfo in properties) yield return propInfo.GetValue(this, null);
        }
    }

    public override bool Supports(string name)
    {
        return this[name] != null;
    }

    public override object SyncLock => this;

    public override IAutoLock GetAutoLock()
    {
        return new AutoLock(this);
    }

    public override INodeAttributesUpdateContext AquireUpdateContext()
    {
        return new StandardNodeAttributesUpdateContext(this);
    }

    protected static bool HasCustomAttribute(PropertyInfo propertyInfo, Type attributeType)
    {
        if (propertyInfo.GetCustomAttributes(attributeType, false).Length > 0)
        {
            return true;
        }

        if (propertyInfo.DeclaringType.BaseType == null) return false;

        propertyInfo = propertyInfo.DeclaringType.BaseType.GetProperty(propertyInfo.Name);

        if (propertyInfo == null) return false;

        return HasCustomAttribute(propertyInfo, attributeType);
    }

    protected override object GetValue(string name)
    {
        switch (name)
        {
            case "CreationTime":
            case "creationtime":
                return CreationTime;
            case "LastAccessTime":
            case "lastaccesstime":
                return LastAccessTime;
            case "LastWriteTime":
            case "lastwritetime":
                return LastWriteTime;
            case "Exists":
            case "exists":
                return Exists;
            case "ReadOnly":
            case "readonly":
                return ReadOnly;
            case "Hidden":
            case "hidden":
                return IsHidden;
        }

        foreach (var propertyInfo in properties)
            if (propertyInfo.Name.Equals(name, StringComparison.CurrentCultureIgnoreCase))
                try
                {
                    var value = propertyInfo.GetValue(this, null);

                    if (value == null) return null;

                    if (value.GetType() != propertyInfo.PropertyType
                        && Nullable.GetUnderlyingType(value.GetType()) != propertyInfo.PropertyType
                        && value.GetType() != Nullable.GetUnderlyingType(propertyInfo.PropertyType))
                        value = Convert.ChangeType(value, propertyInfo.PropertyType);

                    return value;
                }
                catch (TargetInvocationException e)
                {
                    throw e.InnerException;
                }

        return null;
    }

    protected override void SetValue(string name, object value)
    {
        switch (name.ToLower())
        {
            case "CreationTime":
            case "creationtime":
                CreationTime = (DateTime?)value;
                return;
            case "LastAccessTime":
            case "lastaccesstime":
                LastAccessTime = (DateTime?)value;
                return;
            case "LastWriteTime":
            case "lastwritetime":
                LastWriteTime = (DateTime?)value;
                return;
            case "ReadOnly":
            case "readonly":
                ReadOnly = (bool)value;
                return;
            case "Hidden":
            case "hidden":
                IsHidden = (bool)value;
                return;
        }

        foreach (var propertyInfo in properties)
            if (propertyInfo.Name.Equals(name, StringComparison.CurrentCultureIgnoreCase))
                try
                {
                    if (value.GetType() != propertyInfo.PropertyType
                        && Nullable.GetUnderlyingType(value.GetType()) != propertyInfo.PropertyType
                        && value.GetType() != Nullable.GetUnderlyingType(propertyInfo.PropertyType))
                        value = Convert.ChangeType(value, propertyInfo.PropertyType);

                    propertyInfo.SetValue(this, value, null);

                    return;
                }
                catch (TargetInvocationException e)
                {
                    throw e.InnerException;
                }
    }
}