using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Overlayed;

internal class OverlayedFile
    : FileWrapper
{
    private readonly OverlayedFileSystem fileSystem;
    private OverlayedNodeContent content;

    public OverlayedFile(OverlayedFileSystem fileSystem, INodeAddress nodeAddress, IFile file)
        : base(file)
    {
        this.fileSystem = fileSystem;
        Address = nodeAddress;
    }

    public override IFileSystem FileSystem => fileSystem;

    public override INodeAddress Address { get; }

    public override INode? Refresh()
    {
        SetWrappee(fileSystem.RefreshNode(Wrappee));

        base.Refresh();

        return this;
    }

    public override INode Resolve(string name, NodeType nodeType, AddressScope scope)
    {
        var address = Address.ResolveAddress(name, scope);

        return FileSystem.Resolve(address, nodeType);
    }

    public override IEnumerable<INode> GetAlternates()
    {
        return ((OverlayedFileSystem)FileSystem).GetAlternates(this);
    }

    internal INodeContent GetBaseContent()
    {
        return base.GetContent();
    }

    public override INodeContent GetContent()
    {
        if (content == null)
            lock (SyncLock)
            {
                content = FuncUtils.VolatileAssign(() => new OverlayedNodeContent(this));
            }

        return content;
    }

    public override INode Create(bool createParent)
    {
        INode[] nodes;

        if (((OverlayedFileSystem)FileSystem).OverlayedNodeSelector.SelectNodeForOperation((OverlayedFileSystem)FileSystem,
                FileSystemActivity.Created, Address, NodeType, out nodes))
        {
            var count = 0;

            foreach (var node in nodes)
                try
                {
                    node.Create(createParent);
                    count++;
                }
                catch (NodeNotFoundException)
                {
                }

            if (count == 0) throw new NodeNotFoundException(Address);
        }
        else
        {
            return base.Create(createParent);
        }

        return this;
    }

    public override INode Delete()
    {
        INode[] nodes;

        if (((OverlayedFileSystem)FileSystem).OverlayedNodeSelector.SelectNodeForOperation((OverlayedFileSystem)FileSystem,
                FileSystemActivity.Deleted, Address, NodeType, out nodes))
        {
            var count = 0;

            foreach (var node in nodes)
                try
                {
                    node.Delete();
                    count++;
                }
                catch (NodeNotFoundException)
                {
                }

            if (count == 0) throw new NodeNotFoundException(Address);
        }
        else
        {
            return base.Delete();
        }

        return this;
    }

    public override INode RenameTo(string name, bool overwrite)
    {
        INode[] nodes;

        if (((OverlayedFileSystem)FileSystem).OverlayedNodeSelector.SelectNodeForOperation(
                (OverlayedFileSystem)FileSystem, FileSystemActivity.Renamed, Address, NodeType, out nodes))
        {
            var count = 0;

            foreach (var node in nodes)
                try
                {
                    node.RenameTo(name, overwrite);
                    count++;
                }
                catch (NodeNotFoundException)
                {
                }

            if (count == 0) throw new NodeNotFoundException(Address);
        }
        else
        {
            return base.RenameTo(name, overwrite);
        }

        return this;
    }
}