namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Overlayed;

internal class OverlayedNodeContent
    : AbstractNodeContent
{
    private readonly OverlayedFile file;

    public OverlayedNodeContent(OverlayedFile file)
    {
        this.file = file;
    }

    public override void Delete()
    {
        file.GetBaseContent().Delete();
    }

    protected override Stream DoGetInputStream(out string encoding, FileMode mode, FileShare sharing)
    {
        return file.GetBaseContent().GetInputStream(out encoding, mode, sharing);
    }

    protected override Stream DoGetOutputStream(string? encoding, FileMode mode, FileShare sharing)
    {
        return file.GetBaseContent().GetOutputStream(encoding, mode, sharing);
    }
}