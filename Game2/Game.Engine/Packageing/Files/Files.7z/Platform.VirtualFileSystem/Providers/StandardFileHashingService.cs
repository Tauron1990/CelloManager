using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Platform;
using Platform.IO;
using Platform.Text;
using Platform.Xml.Serialization;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class StandardFileHashingService
    : AbstractFileHashingService
{
    public StandardFileHashingService(INode file, FileHashingServiceType serviceType)
        : base((IFile)file, serviceType)
    {
        Algorithm = (HashAlgorithm)Activator.CreateInstance(ServiceType.AlgorithmType);
    }

    protected HashAlgorithm Algorithm { get; }

    public static HashValue? GetHashFromCache(IFile file, string algorithmName)
    {
        if (algorithmName == null) return null;

        if (ConfigurationSection.Default.CanCacheHash(file))
        {
            string s;
            var bytes = (byte[])file.Attributes["extended:" + algorithmName];

            if (bytes == null) return null;

            if ((s = Encoding.ASCII.GetString(bytes)) != "") return new HashValue(TextConversion.FromHexString(s), algorithmName, 0, -1);
        }

        return null;
    }

    public static HashValue SaveHashToCache(IFile file, string algorithmName, HashValue hashValue)
    {
        SaveHashToCache(file, algorithmName, hashValue.TextValue);

        return hashValue;
    }

    public static string SaveHashToCache(IFile file, string algorithmName, string hashValue)
    {
        return SaveHashToCache(file, algorithmName, hashValue, file);
    }

    public static string SaveHashToCache(IFile file, string algorithmName, string hashValue, IFile referenceFile)
    {
        if (ConfigurationSection.Default.CanCacheHash(referenceFile))
        {
            var current = file.Attributes["extended" + algorithmName] as byte[];
            var newvalue = Encoding.ASCII.GetBytes(hashValue);

            if (current != null)
                if (current.ElementsAreEqual(newvalue))
                    return hashValue;

            file.Attributes["extended:" + algorithmName] = newvalue;
        }

        return hashValue;
    }

    public override HashValue ComputeHash(long offset, long length)
    {
        HashValue retval;

        if (length == 0) return new HashValue(Algorithm.ComputeHash(new byte[0]), ServiceType.AlgorithmName, offset, 0L);

        if (offset == 0 && length == -1 && ServiceType.AlgorithmType != null)
        {
            var retvaln = GetHashFromCache(OperatingNode, ServiceType.AlgorithmName);

            if (retvaln != null) return retvaln.Value;
        }

        var stream = OperatingNode.GetContent().GetInputStream();

        if (!(offset == 0 && length == -1 && !stream.CanSeek))
        {
            stream = new PartialStream(stream, offset, length);

            if (length <= 0)
                stream = new BufferedStream(stream, 128 * 1024);
            else
                stream = new BufferedStream(stream, Math.Min(128 * 1024, (int)length));
        }

        var meteringStream = new MeteringStream(stream);

        using (meteringStream)
        {
            retval = new HashValue(Algorithm.ComputeHash(meteringStream), ServiceType.AlgorithmName, offset,
                Convert.ToInt64(meteringStream.ReadMeter.Value));
        }

        if (offset == 0 && length == -1 && ServiceType.AlgorithmType != null)
            try
            {
                //	SaveHashToCache(this.OperatingNode, this.ServiceType.AlgorithmName, retval);
            }
            catch (IOException)
            {
                // TODO: Log
            }

        return retval;
    }

    public class ConfigurationSectionHandler
        : XmlConfigurationBlockSectionHandler<ConfigurationSection>
    {
    }

    [XmlElement("Configuration")]
    public class ConfigurationSection
    {
        private string cacheHashFileUriRegex = "";

        private Regex cacheHashFileUriRegexRegex;

        public static ConfigurationSection Default
        {
            get
            {
                var retval = ConfigurationBlock<ConfigurationSection>.Load("Platform/VirtualFileSystem/StandardFileHashingService/Configuration");

                if (retval == null) retval = new ConfigurationSection();

                return retval;
            }
        }

        [XmlElement]
        public string CacheHashFileUriRegex
        {
            get => cacheHashFileUriRegex;
            set
            {
                cacheHashFileUriRegex = value;

                cacheHashFileUriRegexRegex = new Regex(cacheHashFileUriRegex, RegexOptions.IgnoreCase);
            }
        }

        public virtual bool CanCacheHash(INode node)
        {
            if (cacheHashFileUriRegex == "") return false;

            return cacheHashFileUriRegexRegex.IsMatch(node.Address.Uri);
        }
    }
}