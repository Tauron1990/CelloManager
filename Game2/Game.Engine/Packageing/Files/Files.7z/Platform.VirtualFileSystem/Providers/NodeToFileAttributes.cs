namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class NodeToFileAttributes
    : NodeAttributesWrapper, IFileAttributes
{
    public NodeToFileAttributes(INodeAttributes attributes)
        : base(attributes)
    {
    }

    [NodeAttribute]
    public virtual long? Length => (long?)this[FileAttributes.Length];

    IFileAttributes IFileAttributes.Refresh()
    {
        return (IFileAttributes)Refresh();
    }
}