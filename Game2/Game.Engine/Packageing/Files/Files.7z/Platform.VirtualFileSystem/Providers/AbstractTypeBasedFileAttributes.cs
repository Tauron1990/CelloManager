using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class AbstractTypeBasedFileAttributes
    : AbstractTypeBasedNodeAttributes, IFileAttributes
{
    private INode node;

    public AbstractTypeBasedFileAttributes(INode node)
        : base(node)
    {
        this.node = node;
    }

    [NodeAttribute]
    public virtual long? Length => null;

    IFileAttributes IFileAttributes.Refresh()
    {
        return (IFileAttributes)Refresh();
    }

    public override object this[string item]
    {
        get
        {
            if (item.EqualsIgnoreCase("length")) return Length;

            return base[item];
        }
        set
        {
            if (item.EqualsIgnoreCase("length")) return;

            base[item] = value;
        }
    }
}