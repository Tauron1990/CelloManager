using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public class StandardFileComparingService
    : AbstractRunnableService, IFileComparingService
{
    private readonly IFile file;
    private readonly bool refresh;
    private readonly FileComparingServiceType serviceType;
    private bool value;

    public StandardFileComparingService(IFile file, FileComparingServiceType serviceType, bool refresh = true)
    {
        this.file = file;
        this.refresh = refresh;
        this.serviceType = serviceType;
    }

    public virtual INode OperatingNode => file;

    public virtual INode TargetNode => serviceType.TargetFile;

    public virtual object Value => value;

    public virtual bool Compare()
    {
        lock (this)
        {
            Run();

            return value;
        }
    }

    public override void DoRun()
    {
        lock (this)
        {
            if (refresh)
            {
                OperatingNode.Refresh();
                TargetNode.Refresh();
            }

            if ((serviceType.Flags & FileComparingFlags.CompareLength) != FileComparingFlags.None)
                if (((IFile)OperatingNode).Attributes.Length != ((IFile)TargetNode).Attributes.Length)
                {
                    value = false;

                    return;
                }

            if ((serviceType.Flags & FileComparingFlags.CompareCreationDate) != FileComparingFlags.None)
                if (((IFile)OperatingNode).Attributes.CreationTime != ((IFile)TargetNode).Attributes.CreationTime)
                {
                    value = false;

                    return;
                }

            if ((serviceType.Flags & FileComparingFlags.CompareLastAccessDate) != FileComparingFlags.None)
                if (((IFile)OperatingNode).Attributes.LastAccessTime != ((IFile)TargetNode).Attributes.LastAccessTime)
                {
                    value = false;

                    return;
                }

            if ((serviceType.Flags & FileComparingFlags.CompareLastWriteDate) != FileComparingFlags.None)
                if (((IFile)OperatingNode).Attributes.LastWriteTime != ((IFile)TargetNode).Attributes.LastWriteTime)
                {
                    value = false;

                    return;
                }

            if ((serviceType.Flags & FileComparingFlags.CompareContents) != FileComparingFlags.None
                || (serviceType.Flags & FileComparingFlags.CompareAllExact) != FileComparingFlags.None)
            {
                var fileHasher = (IFileHashingService)OperatingNode.GetService(new FileHashingServiceType("md5"));
                var targetHasher = (IFileHashingService)TargetNode.GetService(new FileHashingServiceType("md5"));

                if (!fileHasher.ComputeHash().Value.ElementsAreEqual(targetHasher.ComputeHash().Value))
                {
                    value = false;

                    return;
                }
            }

            value = true;
        }
    }
}