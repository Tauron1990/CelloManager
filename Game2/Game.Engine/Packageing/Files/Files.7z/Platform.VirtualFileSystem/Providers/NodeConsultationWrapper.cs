using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

/// <summary>
///     Wraps an <i>INode</i> and uses consultation redirect operations
///     to the parent (wrapped) node (also known as the wrappee or target).
/// </summary>
/// <remarks>
///     Implementation redirection is performed using <c>consulation</c>.
///     Consultation means all operations are delegated to the wrappee and
///     evaluated in the context of the wrappee.
///     <para>
///         References:
///         http://javalab.cs.uni-bonn.de/research/darwin/delegation.html
///     </para>
/// </remarks>
public abstract class NodeConsultationWrapper
    : INode, IWrapperObject<INode>
{
    private NodeActivityEventHandler ActivityEvent;
    private NodeActivityEventHandler ChangedEvent;
    private NodeActivityEventHandler CreatedEvent;
    private NodeActivityEventHandler DeletedEvent;
    private NodeActivityEventHandler RenamedEvent;

    protected NodeConsultationWrapper(INode innerNode)
    {
        Wrappee = innerNode;
    }

    protected virtual INode Wrappee { get; private set; }

    public virtual event NodeActivityEventHandler Renamed
    {
        add
        {
            lock (this)
            {
                if (RenamedEvent == null) Wrappee.Renamed += DelegateRenamedEvent;

                RenamedEvent = (NodeActivityEventHandler)Delegate.Combine(RenamedEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                RenamedEvent = (NodeActivityEventHandler)Delegate.Remove(RenamedEvent, value);

                if (RenamedEvent == null) Wrappee.Renamed -= DelegateRenamedEvent;
            }
        }
    }

    public virtual event NodeActivityEventHandler Created
    {
        add
        {
            lock (this)
            {
                if (CreatedEvent == null) Wrappee.Created += DelegateCreatedEvent;

                CreatedEvent = (NodeActivityEventHandler)Delegate.Combine(CreatedEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                CreatedEvent = (NodeActivityEventHandler)Delegate.Remove(CreatedEvent, value);

                if (CreatedEvent == null) Wrappee.Created -= DelegateCreatedEvent;
            }
        }
    }

    public virtual event NodeActivityEventHandler Deleted
    {
        add
        {
            lock (this)
            {
                if (DeletedEvent == null) Wrappee.Deleted += DelegateDeletedEvent;

                DeletedEvent = (NodeActivityEventHandler)Delegate.Combine(DeletedEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                DeletedEvent = (NodeActivityEventHandler)Delegate.Remove(DeletedEvent, value);

                if (DeletedEvent == null) Wrappee.Deleted -= DelegateDeletedEvent;
            }
        }
    }

    public virtual event NodeActivityEventHandler Changed
    {
        add
        {
            lock (this)
            {
                if (ChangedEvent == null) Wrappee.Changed += DelegateChangedEvent;

                ChangedEvent = (NodeActivityEventHandler)Delegate.Combine(ChangedEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                ChangedEvent = (NodeActivityEventHandler)Delegate.Remove(ChangedEvent, value);

                if (ChangedEvent == null) Wrappee.Changed -= DelegateChangedEvent;
            }
        }
    }

    public virtual event NodeActivityEventHandler Activity
    {
        add
        {
            lock (this)
            {
                if (ActivityEvent == null) Wrappee.Activity += DelegateActivityEvent;

                ActivityEvent = (NodeActivityEventHandler)Delegate.Combine(ActivityEvent, value);
            }
        }

        remove
        {
            lock (this)
            {
                ActivityEvent = (NodeActivityEventHandler)Delegate.Remove(ActivityEvent, value);

                if (ActivityEvent == null) Wrappee.Activity -= DelegateActivityEvent;
            }
        }
    }

    public virtual string Name => Address.Name;

    public virtual IFileSystem FileSystem => Wrappee.FileSystem;

    public virtual IDirectory ParentDirectory => Wrappee.ParentDirectory;

    public virtual NodeType NodeType => Wrappee.NodeType;

    public virtual bool Exists => Wrappee.Exists;

    public virtual string DefaultContentName => Wrappee.DefaultContentName;

    public virtual IEnumerable<string> GetContentNames()
    {
        return Wrappee.GetContentNames();
    }

    public virtual INodeContent GetContent()
    {
        return Wrappee.GetContent();
    }

    public virtual INodeContent GetContent(string contentName)
    {
        return Wrappee.GetContent(contentName);
    }

    public virtual IAutoLock GetAutoLock()
    {
        return Wrappee.GetAutoLock();
    }

    public virtual IAutoLock AquireAutoLock()
    {
        return Wrappee.AquireAutoLock();
    }

    public virtual bool SupportsActivityEvents => Wrappee.SupportsActivityEvents;

    public virtual INode Create()
    {
        var operationPerformed = false;

        FileSystem.Extenders.CompositeNodeOperationFilter.Create(this, false, ref operationPerformed, Wrappee.Create);

        if (!operationPerformed) Wrappee.Create();

        return this;
    }

    public virtual INode Create(bool createParent)
    {
        var operationPerformed = false;

        FileSystem.Extenders.CompositeNodeOperationFilter.Create(this, createParent, ref operationPerformed, Wrappee.Create);

        if (!operationPerformed) Wrappee.Create(createParent);

        return this;
    }

    public virtual INode Delete()
    {
        var operationPerformed = false;

        FileSystem.Extenders.CompositeNodeOperationFilter.Delete(this, ref operationPerformed, Wrappee.Delete);

        if (!operationPerformed) Wrappee.Delete();

        return this;
    }

    public virtual IFile ResolveFile(string name)
    {
        return Wrappee.ResolveFile(name);
    }

    public virtual IDirectory ResolveDirectory(string name)
    {
        return Wrappee.ResolveDirectory(name);
    }

    public virtual IFile ResolveFile(string name, AddressScope scope)
    {
        return Wrappee.ResolveFile(name, scope);
    }

    public virtual IDirectory ResolveDirectory(string name, AddressScope scope)
    {
        return Wrappee.ResolveDirectory(name, scope);
    }

    public virtual INode Resolve(string name)
    {
        return Wrappee.Resolve(name);
    }

    public virtual INode Resolve(string name, AddressScope scope)
    {
        return Wrappee.Resolve(name, scope);
    }

    public virtual INode Resolve(string name, NodeType nodeType)
    {
        return Wrappee.Resolve(name, nodeType);
    }

    public virtual INode Resolve(string name, NodeType nodeType, AddressScope scope)
    {
        return Wrappee.Resolve(name, nodeType, scope);
    }

    public virtual INode MoveTo(INode target, bool overwrite)
    {
        var operationPerformed = false;

        FileSystem.Extenders.CompositeNodeOperationFilter.MoveTo(this, target, overwrite, ref operationPerformed, Wrappee.MoveTo);

        if (!operationPerformed) Wrappee.MoveTo(target, overwrite);

        return this;
    }

    public virtual INode CopyTo(INode target, bool overwrite)
    {
        var operationPerformed = false;

        FileSystem.Extenders.CompositeNodeOperationFilter.CopyTo(this, target, overwrite, ref operationPerformed, Wrappee.CopyTo);

        if (!operationPerformed) Wrappee.CopyTo(target, overwrite);

        return this;
    }

    public virtual IDirectory OperationTargetDirectory => Wrappee.OperationTargetDirectory;

    public virtual IService GetService(ServiceType serviceType)
    {
        return Wrappee.GetService(serviceType);
    }

    public virtual T GetService<T>(ServiceType serviceType)
        where T : IService
    {
        return Wrappee.GetService<T>(serviceType);
    }

    public virtual T GetService<T>()
        where T : IService
    {
        return Wrappee.GetService<T>();
    }

    public virtual INodeAddress Address => Wrappee.Address;

    public virtual INode? Refresh()
    {
        Wrappee.Refresh();

        return this;
    }

    public virtual IEnumerable<INode> GetAlternates()
    {
        return Wrappee.GetAlternates();
    }

    public virtual INodeAttributes Attributes => Wrappee.Attributes;

    public virtual object SyncLock => Wrappee.SyncLock;

    public virtual INode RenameTo(string name, bool overwrite)
    {
        var operationPerformed = false;

        FileSystem.Extenders.CompositeNodeOperationFilter.RenameTo(this, name, overwrite, ref operationPerformed, Wrappee.RenameTo);

        if (!operationPerformed) Wrappee.RenameTo(name, overwrite);

        return this;
    }

    public virtual INode MoveToDirectory(IDirectory directory, bool overwrite)
    {
        var operationPerformed = false;
        var target = GetDirectoryOperationTargetNode(directory);

        FileSystem.Extenders.CompositeNodeOperationFilter.MoveTo(this, target, overwrite, ref operationPerformed, Wrappee.MoveTo);

        if (!operationPerformed) Wrappee.MoveTo(target, overwrite);

        return this;
    }

    public virtual INode CopyToDirectory(IDirectory directory, bool overwrite)
    {
        var operationPerformed = false;
        var target = GetDirectoryOperationTargetNode(directory);

        FileSystem.Extenders.CompositeNodeOperationFilter.CopyTo(this, target, overwrite, ref operationPerformed, Wrappee.CopyTo);

        if (!operationPerformed) Wrappee.CopyTo(target, overwrite);

        return this;
    }

    public virtual int CompareTo(INode other)
    {
        return Wrappee.CompareTo(other);
    }

    public virtual void CheckAccess(FileSystemSecuredOperation operation)
    {
        Wrappee.CheckAccess(operation);
    }

    public virtual INode GetDirectoryOperationTargetNode(IDirectory directory)
    {
        return Wrappee.GetDirectoryOperationTargetNode(directory);
    }

    public virtual void CreateGlobalLock(string name)
    {
        Wrappee.CreateGlobalLock(name);
    }

    INode IWrapperObject<INode>.Wrappee => Wrappee;

    private void DelegateRenamedEvent(object sender, NodeActivityEventArgs eventArgs)
    {
        OnRenamedEvent(eventArgs);
    }

    protected virtual void OnRenamedEvent(NodeActivityEventArgs eventArgs)
    {
        lock (this)
        {
            if (RenamedEvent != null) RenamedEvent(this, eventArgs);
        }
    }

    private void DelegateCreatedEvent(object sender, NodeActivityEventArgs eventArgs)
    {
        OnCreatedEvent(eventArgs);
    }

    protected void OnCreatedEvent(NodeActivityEventArgs eventArgs)
    {
        lock (this)
        {
            if (CreatedEvent != null) CreatedEvent(this, eventArgs);
        }
    }

    private void DelegateDeletedEvent(object sender, NodeActivityEventArgs eventArgs)
    {
        OnDeletedEvent(eventArgs);
    }

    protected void OnDeletedEvent(NodeActivityEventArgs eventArgs)
    {
        lock (this)
        {
            if (DeletedEvent != null) DeletedEvent(this, eventArgs);
        }
    }

    private void DelegateChangedEvent(object sender, NodeActivityEventArgs eventArgs)
    {
        OnChangedEvent(eventArgs);
    }

    protected void OnChangedEvent(NodeActivityEventArgs eventArgs)
    {
        lock (this)
        {
            if (ChangedEvent != null) ChangedEvent(this, eventArgs);
        }
    }

    private void DelegateActivityEvent(object sender, NodeActivityEventArgs eventArgs)
    {
        OnActivityEvent(eventArgs);
    }

    protected void OnActivityEvent(NodeActivityEventArgs eventArgs)
    {
        lock (this)
        {
            if (ActivityEvent != null) ActivityEvent(this, eventArgs);
        }
    }

    protected virtual void SetWrappee(INode node)
    {
        Wrappee = node;
    }

    public override bool Equals(object obj)
    {
        return Wrappee.Equals(obj);
    }

    public override int GetHashCode()
    {
        return Wrappee.GetHashCode();
    }

    public override string ToString()
    {
        return Address.ToString();
    }
}