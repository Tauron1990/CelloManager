namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

public abstract class AbstractStreamHashingService
    : AbstractHashingService, IStreamHashingService
{
    protected AbstractStreamHashingService(IFile file, StreamHashingServiceType serviceType)
        : base(file, serviceType)
    {
        ServiceType = serviceType;
    }

    public new StreamHashingServiceType ServiceType { get; }

    public new IFile OperatingNode => (IFile)base.OperatingNode;

    public virtual Stream OperatingStream => ServiceType.Stream;
}