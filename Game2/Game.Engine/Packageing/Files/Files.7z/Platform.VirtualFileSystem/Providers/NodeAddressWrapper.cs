using System.Collections.Specialized;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

[Serializable]
public class NodeAddressWrapper
    : INodeAddress
{
    public NodeAddressWrapper(INodeAddress wrappee)
    {
        this.Wrappee = wrappee;
    }

    public virtual INodeAddress Wrappee { get; }

    public virtual string InnerUri => Wrappee.InnerUri;

    public virtual string Name => Wrappee.Name;

    public virtual string NameWithoutQuery => Wrappee.NameWithoutQuery;


    public virtual string NameWithoutExtension => Wrappee.NameWithoutExtension;

    public virtual string NameAndQuery => Wrappee.NameAndQuery;

    public virtual string Query => Wrappee.Query;

    public virtual NameValueCollection QueryValues => Wrappee.QueryValues;

    public virtual string PathAndQuery => Wrappee.PathAndQuery;

    public virtual string ShortName => Wrappee.ShortName;

    public virtual string AbsolutePath => Wrappee.AbsolutePath;

    public virtual string Extension => Wrappee.Extension;

    public virtual int Depth => Wrappee.Depth;

    public virtual string Scheme => Wrappee.Scheme;

    public virtual string Uri => Wrappee.Uri;

    public virtual string RootUri => Wrappee.RootUri;

    public virtual INodeAddress Parent => Wrappee.Parent;

    public virtual INodeAddress ResolveAddress(string name)
    {
        return Wrappee.ResolveAddress(name);
    }

    public virtual INodeAddress ResolveAddress(string name, AddressScope scope)
    {
        return Wrappee.ResolveAddress(name, scope);
    }

    public virtual string GetRelativePathTo(INodeAddress name)
    {
        return Wrappee.GetRelativePathTo(name);
    }

    public virtual bool IsAncestorOf(INodeAddress name)
    {
        return Wrappee.IsAncestorOf(name);
    }

    public virtual bool IsDescendentOf(INodeAddress name)
    {
        return Wrappee.IsDescendentOf(name);
    }

    public virtual bool IsDescendentOf(INodeAddress name, AddressScope scope)
    {
        return Wrappee.IsDescendentOf(name, scope);
    }

    public virtual bool RootsAreEqual(INodeAddress nodeAddress)
    {
        return Wrappee.RootsAreEqual(nodeAddress);
    }

    public virtual bool IsRoot => Wrappee.IsRoot;

    public virtual bool IsDescendentOf(INodeAddress name, StringComparison comparisonType, AddressScope scope)
    {
        return Wrappee.IsDescendentOf(name, comparisonType, scope);
    }

    public virtual bool ParentsEqual(INodeAddress nodeAddress)
    {
        return Wrappee.ParentsEqual(nodeAddress);
    }

    public virtual bool ParentsEqual(INodeAddress nodeAddress, StringComparison comparisonType)
    {
        return Wrappee.ParentsEqual(nodeAddress, comparisonType);
    }

    public virtual string PathToDepth(int depth)
    {
        return Wrappee.PathToDepth(depth);
    }

    public virtual string GetRelativePathTo(string absolutePath)
    {
        return Wrappee.GetRelativePathTo(absolutePath);
    }

    public virtual string DisplayUri => Wrappee.DisplayUri;
}