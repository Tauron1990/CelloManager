using System.Runtime.CompilerServices;
using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

[PublicAPI]
public abstract class AbstractMultiFileSystemNodeProvider : AbstractNodeProvider
{
    private readonly IDictionary<FileSystemOptionsCacheKey, IFileSystem> _fileSystems =
        new Dictionary<FileSystemOptionsCacheKey, IFileSystem>(FileSystemOptionsCacheKeyComparer.Default);

    protected AbstractMultiFileSystemNodeProvider(IFileSystemManager manager)
        : base(manager)
    {
    }

    protected void AddFileSystem(object key, IFileSystem fileSystem, FileSystemOptions? options) => _fileSystems[new FileSystemOptionsCacheKey(key, options)] = fileSystem;

    protected void RemoveFileSystem(object key, IFileSystem fileSystem, FileSystemOptions? options) => _fileSystems.Remove(new FileSystemOptionsCacheKey(key, options));

    protected virtual IFileSystem? FindFileSystem(object key, FileSystemOptions? options) => _fileSystems.TryGetValue(new FileSystemOptionsCacheKey(key, options), out var retval) ? retval : null;

    public override INode Find(INodeResolver resolver, string uri, NodeType nodeType, FileSystemOptions? options)
    {
        var nodeAddress = ParseUri(uri);

        return Find(nodeAddress, nodeType, options);
    }

    protected virtual INode Find(INodeAddress nodeAddress, NodeType nodeType, FileSystemOptions? options)
    {
        var rootAddress = nodeAddress.ResolveAddress(FileSystemManager.RootPath);

        options ??= FileSystemOptions.Default;

        var fileSystem = FindFileSystem(rootAddress, options);

        if (fileSystem == null)
        {
            fileSystem = NewFileSystem(rootAddress, options, out var cache);

            fileSystem.Closed += FileSystem_Closed;

            if (cache)
            {
                AddFileSystem(rootAddress, fileSystem, options);
                AddFileSystem(rootAddress, fileSystem, fileSystem.Options);
            }
        }

        return fileSystem.Resolve(nodeAddress, nodeType);
    }

    protected abstract IFileSystem NewFileSystem(INodeAddress rootAddress, FileSystemOptions? options, out bool cache);

    protected abstract INodeAddress ParseUri(string uri);

    private void FileSystem_Closed(object? sender, EventArgs e)
    {
        lock (this)
        {
            if(sender is IFileSystem fileSystem)
                RemoveFileSystem(fileSystem.RootDirectory.Address, fileSystem, fileSystem.Options);
        }
    }

    protected struct FileSystemOptionsCacheKey
    {
        public readonly object Key;
        public readonly FileSystemOptions? Options;

        public FileSystemOptionsCacheKey(object key, FileSystemOptions? options)
            : this()
        {
            Key = key;
            Options = options;
        }
    }

    protected class FileSystemOptionsCacheKeyComparer : IEqualityComparer<FileSystemOptionsCacheKey>
    {
        public static readonly FileSystemOptionsCacheKeyComparer Default = new();

        public bool Equals(FileSystemOptionsCacheKey x, FileSystemOptionsCacheKey y) => Equals(x.Key, y.Key) && ReferenceEquals(x.Options, y.Options);

        public int GetHashCode(FileSystemOptionsCacheKey obj)
        {
            var retval = 0;

            retval ^= obj.GetHashCode();

            retval ^= RuntimeHelpers.GetHashCode(obj.Options);

            return retval;
        }
    }
}