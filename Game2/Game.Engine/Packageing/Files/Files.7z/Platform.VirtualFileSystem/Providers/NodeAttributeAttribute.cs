namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

[AttributeUsage(AttributeTargets.Property)]
public class NodeAttributeAttribute
    : Attribute
{
}