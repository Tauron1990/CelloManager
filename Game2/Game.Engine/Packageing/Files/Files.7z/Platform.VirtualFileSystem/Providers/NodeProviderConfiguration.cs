using Platform.Xml.Serialization;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;

[XmlElement("Configuration")]
public class NodeProviderConfiguration
{
    public NodeProviderConfiguration()
    {
        NodeOperationFilters = new ConfigurationSection.NodeOperationFilterEntry[0];
        AccessPermissionVerifiers = new AccessPermissionVerifierConfigurationEntry[0];
        Variables = new Variable[0];
    }

    [XmlElement]
    public virtual Variable[] Variables { get; set; }

    [XmlElement]
    [XmlListElement(typeof(ConfigurationSection.NodeOperationFilterEntry), "NodeOperationFilter")]
    public virtual ConfigurationSection.NodeOperationFilterEntry[] NodeOperationFilters { get; set; }

    [XmlElement]
    [XmlListElement("AccessPermissionVerifier")]
    public virtual AccessPermissionVerifierConfigurationEntry[] AccessPermissionVerifiers { get; set; }

    [XmlElement]
    public class Variable
    {
        [XmlAttribute(MakeNameLowercase = true)]
        public virtual string Name { get; set; }

        [XmlAttribute(MakeNameLowercase = true)]
        public virtual string Value { get; set; }
    }
}