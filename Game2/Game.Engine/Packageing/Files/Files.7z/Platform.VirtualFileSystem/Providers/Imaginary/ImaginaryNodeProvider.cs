using Platform;
using Platform.Text;
using Platform.Xml.Serialization;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Imaginary;

public class ImaginaryNodeProvider
    : AbstractNodeProvider
{
    private readonly IFileSystem imaginaryFileSystem;
    private readonly string[] schemas;

    private IDirectory root;

    public ImaginaryNodeProvider(IFileSystemManager manager, string scheme)
        : base(manager)
    {
        schemas = new[]
        {
            scheme
        };

        imaginaryFileSystem = new ImaginaryFileSystem(scheme);
        root = imaginaryFileSystem.RootDirectory;
    }

    public override string[] SupportedUriSchemas => (string[])schemas.Clone();

    protected virtual IFileSystem ImaginaryFileSystem => imaginaryFileSystem;

    public override INode Find(INodeResolver resolver, string uri, NodeType nodeType, FileSystemOptions? options)
    {
        Pair<string, string> result;

        result = uri.SplitOnFirst("://");

        if (result.Left != imaginaryFileSystem.RootDirectory.Address.Scheme) throw new NotSupportedException(result.Left);

        return imaginaryFileSystem.Resolve(TextConversion.FromEscapedHexString(result.Right), nodeType);
    }

    [XmlElement("Options")]
    public class ConstructionOptions
    {
        public ConstructionOptions()
        {
            Scheme = "";
        }

        public ConstructionOptions(string scheme)
        {
            Scheme = scheme;
        }

        [XmlElement]
        [XmlVariableSubstitution]
        public virtual string Scheme { get; protected set; }
    }
}