using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.View;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Imaginary;

public class ImaginaryFileSystem
    : AbstractFileSystem
{
    private IDirectory root;

    public ImaginaryFileSystem(string scheme)
        : this(scheme, FileSystemOptions.Default)
    {
        root = ResolveDirectory("/").Create();
    }

    public ImaginaryFileSystem(string scheme, FileSystemOptions? options)
        : base(new ViewNodeAddress(scheme, "/", ""), null, options)
    {
    }

    public override event FileSystemActivityEventHandler Activity
    {
        add { }
        remove { }
    }

    protected override INode CreateNode(INodeAddress address, NodeType nodeType)
    {
        if (!address.IsRoot)
        {
            var parent = (IDirectory)Resolve(address.Parent, NodeType.Directory);

            if (parent is ImaginaryDirectory)
            {
                var retval = ((ImaginaryDirectory)parent).GetImaginaryChild(address.Name, nodeType);

                if (retval != null) return retval;
            }
        }

        if (nodeType == NodeType.Directory)
            return new ImaginaryDirectory(this, address);
        if (nodeType == NodeType.File) return new ImaginaryFile(this, address);

        throw new NotSupportedException(string.Format("{0}:{1}", address, nodeType));
    }
}