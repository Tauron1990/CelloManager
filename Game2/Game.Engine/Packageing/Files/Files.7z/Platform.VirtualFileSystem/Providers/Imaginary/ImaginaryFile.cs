namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers.Imaginary;

public class ImaginaryFile : AbstractFile
{
    public ImaginaryFile(IFileSystem fileSystem, INodeAddress address)
        : base(address, fileSystem)
    {
    }
}