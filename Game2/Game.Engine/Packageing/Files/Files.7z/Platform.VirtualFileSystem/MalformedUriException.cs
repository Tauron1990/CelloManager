namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[Serializable]
public class MalformedUriException : FormatException
{
    public MalformedUriException() => Uri = "";

    public MalformedUriException(string uri) => Uri = uri;

    public MalformedUriException(string uri, string message)
        : base(message) =>
        Uri = uri;

    public MalformedUriException(string uri, string message, Exception innerException)
        : base(message, innerException) =>
        Uri = uri;

    public virtual string Uri { get; }
}