using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class DelegatingResolver : AbstractResolver
{
    private readonly INodeResolver _resolver;

    public DelegatingResolver(INodeResolver resolver) => _resolver = resolver;

    public override INode Resolve(string uri, NodeType nodeType, AddressScope scope) => _resolver.Resolve(uri, nodeType, scope);
}