﻿using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public static class NodeExtensions
{
    public static string? GetNativePath(this INode node)
    {
        var service = node.GetService<INativePathService>();

        return service?.GetNativePath();
    }

    public static string? GetNativeShortPath(this INode node)
    {
        var service = node.GetService<INativePathService>();

        return service?.GetNativeShortPath();
    }
}