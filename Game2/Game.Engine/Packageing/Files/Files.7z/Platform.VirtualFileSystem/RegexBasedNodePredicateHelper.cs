using System.Text.RegularExpressions;
using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class RegexBasedNodePredicateHelper : RegexBasedPredicateHelper
{
    private readonly NodeType? _nodeType;

    public RegexBasedNodePredicateHelper(string regex)
        : base(regex)
    {
    }

    public RegexBasedNodePredicateHelper(Regex regex)
        : base(regex)
    {
    }

    internal RegexBasedNodePredicateHelper(Regex regex, NodeType nodeType)
        : base(regex) =>
        _nodeType = nodeType;

    public static RegexBasedNodePredicateHelper New(string regex) => new RegexBasedNodePredicateHelper(regex);

    public virtual bool Accept(INode node)
    {
        if (_nodeType != null)
            if (!node.NodeType.Is(_nodeType))
                return false;

        return Regex.IsMatch(node.Name);
    }

    public static bool IsRegexBasedNodePredicate(Predicate<INode> value) => value.Target is RegexBasedNodePredicateHelper;

    public static Regex? GetRegexFromRegexBasedNodePredicate(Predicate<INode> value) => (value.Target as RegexBasedNodePredicateHelper)?.Regex;

    public static bool PredicateNameBasedOnly(Predicate<INode> value) => (value.Target as RegexBasedNodePredicateHelper)?._nodeType == null;

    public static implicit operator Predicate<INode>(RegexBasedNodePredicateHelper predicateHelper) => predicateHelper.Accept;

    public static implicit operator Predicate<IFile>(RegexBasedNodePredicateHelper predicateHelper) =>
        new RegexBasedNodePredicateHelper(predicateHelper.Regex, NodeType.File).Accept;

    public static implicit operator Predicate<IDirectory>(RegexBasedNodePredicateHelper predicateHelper) =>
        new RegexBasedNodePredicateHelper(predicateHelper.Regex, NodeType.Directory).Accept;
}