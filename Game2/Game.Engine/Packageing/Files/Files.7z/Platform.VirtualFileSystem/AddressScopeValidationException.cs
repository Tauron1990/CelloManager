using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

/// <summary>
///     Thrown when a node to be resolved isn't within the correct AddressScope.
/// </summary>
[PublicAPI]
public class AddressScopeValidationException
    : Exception
{
    public AddressScopeValidationException(string path, AddressScope scope, Exception? innerException = null)
        : base($"The path \"{path}\" is not valid within the scope \"{scope}\"", innerException)
    {
    }
}