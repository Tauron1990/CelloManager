/*using Game.Engine.Packageing.Files.Platform.VirtualFileSystem.Providers;
using Platform;
using Platform.IO;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public class OldStandardFileTransferService : AbstractRunnableService, IFileTransferService
{
    private long _BytesTransferred;
    private readonly IFile? _Destination;

    private long _Offset;
    private readonly TransferProgress _Progress;

    private readonly FileTransferServiceType _ServiceType;
    private readonly IFile _Source;
    private Thread _TaskThread;

    private TransferState _TransferState = TransferState.NotStarted;

    public OldStandardFileTransferService(IFile source, IFile? destination)
        : this(source, new FileTransferServiceType(destination, true))
    {
    }

    public OldStandardFileTransferService(IFile source, FileTransferServiceType serviceType)
    {
        _ServiceType = serviceType;
        _Source = source;
        _Destination = _ServiceType.Destination;

        _Progress = new TransferProgress(this);
    }
    
    public virtual INode OperatingNode => _Source;

    public virtual INode? TargetNode => _Destination;

    public async Task Run()
    {
        long x;
        string id;
        IFile? destTemp;
        ITempIdentityFileService destTempService;
        IFile? dest;
        Stream srcStream = null, destStream = null;
        IFileHashingService hasher;
        string sourceHash, destTempHash;

        try
        {
            lock (this)
            {
                _TaskThread = Thread.CurrentThread;

                if (_TransferState != TransferState.NotStarted) throw new InvalidOperationException();

                SetTransferState(TransferState.Preparing);
            }

            id = _Source.Address.Uri + _Source.Length
                                      + (_Source.Attributes.CreationTime ?? DateTime.MinValue).ToBinary();

            destTempService = (ITempIdentityFileService)_Destination.GetService(new TempIdentityFileServiceType(id));

            destTemp = destTempService.GetTempFile();

            for (;;)
            {
                try
                {
                    x = destTemp.Length;
                }
                catch (FileNotFoundException)
                {
                    x = 0;
                }

                dest = _Destination.ParentDirectory.ResolveFile("$TMP_" + _Destination.Address.Name + "_" + Guid.NewGuid().ToString("N"));

                try
                {
                    if (x == _Source.Length)
                        try
                        {
                            if (_Source.IdenticalTo(destTemp, FileComparingFlags.CompareContents))
                            {
                                SetTransferState(TransferState.Copying);
                                ProcessTaskStateRequest();

                                _Progress.RaiseValueChanged(_Progress.CurrentValue, 0);

                                destTemp.MoveTo(dest, true);

                                if (!_Source.IdenticalTo(dest, FileComparingFlags.CompareContents)) continue;

                                dest.RenameTo(_Destination.Address.NameAndQuery, true);

                                _BytesTransferred = _Destination.Length;

                                _Progress.RaiseValueChanged(_Progress.CurrentValue, _BytesTransferred);

                                SetTransferState(TransferState.Finished);
                                ProcessTaskStateRequest();

                                return;
                            }
                        }
                        catch (IOException)
                        {
                        }

                    srcStream = _Source.GetContent().GetInputStream(FileShare.Read);

                    if (!srcStream.CanSeek)
                    {
                        destStream = destTemp.GetContent().GetOutputStream(FileMode.Create, FileShare.Read);
                    }
                    else
                    {
                        destStream = destTemp.GetContent().GetOutputStream(FileMode.Append, FileShare.Read);

                        SetTransferState(TransferState.Comparing);
                        ProcessTaskStateRequest();

                        hasher = (IFileHashingService)_Source.GetService(new FileHashingServiceType("md5"));

                        sourceHash = hasher.ComputeHash(0, destStream.Length).TextValue;

                        hasher = (IFileHashingService)destTemp.GetService(new FileHashingServiceType("md5"));

                        destTempHash = hasher.ComputeHash().TextValue;

                        if (sourceHash != destTempHash)
                        {
                            destStream.Close();
                            destStream = destTemp.GetContent().GetOutputStream(FileMode.Create, FileShare.Read);
                        }
                        else
                        {
                            _Offset = destStream.Length;

                            if (_Offset > 0) srcStream = new PartialStream(srcStream, _Offset);
                        }
                    }

                    _Progress.RaiseValueChanged(0, _Offset);
                    ProcessTaskStateRequest();

                    _Pump = new StreamPump(srcStream, destStream, true, false, _ServiceType.BufferSize);

                    _Pump.TaskStateChanged += new TaskEventHandler(Pump_TaskStateChanged);

                    SetTransferState(TransferState.Transferring);
                    ProcessTaskStateRequest();

                    _Pump.Run();

                    if (_Pump.TaskState == TaskState.Stopped) throw new StopRequestedException();

                    SetTransferState(TransferState.Copying);
                    ProcessTaskStateRequest();
                }
                finally
                {
                    if (srcStream != null)
                        Routines.IgnoreExceptions(delegate { srcStream.Close(); });

                    if (destStream != null)
                        Routines.IgnoreExceptions(delegate { destStream.Close(); });
                }

                break;
            }

            SetTransferState(TransferState.Tidying);

            destTemp.MoveTo(dest, true);

            ///
            /// Aquire an UpdateContext for the attributes
            /// so that all updates to the attributes are
            /// commited in a single operation
            ///

            using (dest.Attributes.AquireUpdateContext())
            {
                foreach (var s in _ServiceType.AttributesToTransfer) dest.Attributes[s] = _Source.Attributes[s];
            }

            dest.RenameTo(_Destination.Address.Name, true);

            SetTransferState(TransferState.Finished);
        }
        finally
        {
            if (_TransferState != TransferState.Stopped) SetTransferState(TransferState.Finished);
        }
    }

    public override void Stop()
    {
        lock (this)
        {
            if (_Pump != null && _Pump.TaskState == TaskState.Running)
                _Pump.Stop();
            else
                base.Stop();
        }
    }

    public override void Pause()
    {
        lock (this)
        {
            if (_Pump != null && _Pump.TaskState == TaskState.Running)
                _Pump.Pause();
            else
                base.Pause();
        }
    }

    public override void Resume()
    {
        lock (this)
        {
            if (_Pump != null && _Pump.TaskState == TaskState.Running)
                _Pump.Resume();
            else
                base.Resume();
        }
    }

    protected static TaskState ToTaskState(TransferState transferState)
    {
        switch (transferState)
        {
            case TransferState.NotStarted:
                return global::Platform.Models.TaskState.NotStarted;
            case TransferState.Preparing:
            case TransferState.Comparing:
            case TransferState.Transferring:
            case TransferState.Copying:
            case TransferState.Tidying:
                return global::Platform.Models.TaskState.Running;
            case TransferState.Finished:
                return global::Platform.Models.TaskState.Finished;
            case TransferState.Stopped:
                return global::Platform.Models.TaskState.Stopped;
            default:
                return global::Platform.Models.TaskState.Unknown;
        }
    }

    private void SetTransferState(TransferState value)
    {
        lock (this)
        {
            object oldValue;

            oldValue = _TransferState;

            _TransferState = value;

            SetTaskState(ToTaskState(_TransferState));

            Monitor.PulseAll(this);

            _Progress.RaiseStateChanged();
        }
    }

    private long GetBytesTransferred()
    {
        if (_Pump != null)
            return Convert.ToInt64(_Pump.Progress.CurrentValue) + _Offset;
        return _BytesTransferred + _Offset;
    }

    private long GetBytesToTransfer()
    {
        if (_Pump != null)
            return Convert.ToInt64(_Pump.Progress.MaximumValue) + _Offset;
        return _Source.Length;
    }

    protected override Thread GetTaskThread()
    {
        return _TaskThread;
    }

    private void Pump_TaskStateChanged(object sender, TaskEventArgs eventArgs)
    {
        lock (this)
        {
            if (eventArgs.TaskState == TaskState.Running
                || eventArgs.TaskState == TaskState.Paused)
                SetTaskState(eventArgs.TaskState);
        }
    }

    #region Types

    private class TransferProgress
        : AbstractMeter
    {
        private bool m_PumpRegistered;
        private readonly OldStandardFileTransferService m_Service;

        public TransferProgress(OldStandardFileTransferService service)
        {
            m_Service = service;
        }

        public override object Owner => m_Service;

        public override object MaximumValue => m_Service.GetBytesToTransfer();

        public override object MinimumValue => 0;

        public override object CurrentValue => m_Service.GetBytesTransferred();

        public override string Units => "bytes";

        public override string ToString()
        {
            switch (m_Service._TransferState)
            {
                case TransferState.Finished:
                    return string.Format("Finished {0}/{1} bytes ({2:0}%)", CurrentValue, MaximumValue,
                        Convert.ToDouble(CurrentValue) / Convert.ToDouble(MaximumValue) * 100.0);
                case TransferState.Transferring:
                    return string.Format("Transferring {0}/{1} bytes ({2:0.##}%)", CurrentValue, MaximumValue,
                        Convert.ToDouble(CurrentValue) / Convert.ToDouble(MaximumValue) * 100.0);
                default:
                    return Enum.GetName(typeof(TransferState), m_Service._TransferState);
            }
        }

        public virtual void RaiseValueChanged(object oldValue, object newValue)
        {
            OnValueChanged(oldValue, newValue);
        }

        public virtual void RaiseMajorChange()
        {
            OnMajorChange();
        }

        public virtual void RaiseStateChanged()
        {
            if (m_Service._TransferState == TransferState.Transferring)
                lock (this)
                {
                    if (!m_PumpRegistered)
                    {
                        m_Service._Pump.Progress.ValueChanged += PumpProgress_ValueChanged;
                        m_Service._Pump.Progress.MajorChange += new EventHandler(PumpProgress_MajorChange);

                        m_PumpRegistered = true;
                    }
                }
        }

        private void PumpProgress_ValueChanged(object sender, MeterEventArgs eventArgs)
        {
            OnValueChanged((long)eventArgs.OldValue + m_Service._Offset, (long)eventArgs.NewValue + m_Service._Offset);
        }

        private void PumpProgress_MajorChange(object sender, EventArgs e)
        {
            OnMajorChange();
        }
    }

    #endregion

    protected enum TransferState
    {
        NotStarted,
        Preparing,
        Comparing,
        Transferring,
        Copying,
        Tidying,
        Finished,
        Stopped
    }
}*/