using System.Reflection;
using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[Serializable]
[PublicAPI]
public class ServiceType
{
    private static FieldInfo[]? _publicFields;

    protected ServiceType() => RuntimeType = GetType();

    public ServiceType(Type runtimeType) => RuntimeType = runtimeType;

    public static ServiceType NativePathServiceType => new(typeof(INativePathService));

    public static ServiceType NodeDeletingServiceType => new NodeDeletingServiceType();

    public static ServiceType RecursiveNodeDeletingServiceType => new NodeDeletingServiceType(true);

    public virtual Type RuntimeType { get; }

    public virtual string Name => RuntimeType.Name;

    public static ServiceType FromRuntimeType(Type runtimeType) => new ServiceType(runtimeType);

    public static implicit operator ServiceType(Type runtimeType) => FromRuntimeType(runtimeType);

    public virtual bool Is(Type type) => RuntimeType.IsAssignableFrom(type);

    public override bool Equals(object? obj)
    {
        var serviceType = obj as ServiceType;

        if (obj == null) return false;

        return RuntimeType == serviceType?.RuntimeType;
    }

    public override int GetHashCode() => RuntimeType.GetHashCode();

    public override string ToString()
    {
        _publicFields ??= typeof(ServiceType).GetFields(BindingFlags.Static | BindingFlags.Public);

        foreach (var fieldInfo in _publicFields)
        {
            var serviceType = fieldInfo.GetValue(null) as ServiceType;

            if (Equals(serviceType)) return fieldInfo.Name;
        }

        return RuntimeType.Name;
    }
}