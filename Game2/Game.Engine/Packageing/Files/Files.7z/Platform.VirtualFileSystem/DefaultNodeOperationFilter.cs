using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class DefaultNodeOperationFilter : INodeOperationFilter
{
    public virtual INode? CopyTo(INode thisNode, INode target, bool overwrite, out bool operationPerformed, Func<INode, bool, INode> defaultOperator)
    {
        operationPerformed = true;

        return defaultOperator(target, overwrite);
    }

    public virtual INode? MoveTo(INode thisNode, INode target, bool overwrite, out bool operationPerformed, Func<INode, bool, INode> defaultOperator)
    {
        operationPerformed = true;

        return defaultOperator(target, overwrite);
    }

    public virtual INode? Create(INode thisNode, bool createParent, out bool operationPerformed, Func<bool, INode> defaultOperator)
    {
        operationPerformed = true;

        return defaultOperator(createParent);
    }

    public virtual INode? Delete(INode thisNode, out bool operationPerformed, Func<INode> defaultOperator)
    {
        operationPerformed = true;

        return defaultOperator();
    }

    public virtual INode? RenameTo(INode thisNode, string name, bool overwrite, out bool operationPerformed, Func<string, bool, INode> defaultOperator)
    {
        operationPerformed = true;

        return defaultOperator(name, overwrite);
    }
}