using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public interface INodeTaskServiceWithTarget : INodeTaskService
{
    INode TargetNode { get; }
}