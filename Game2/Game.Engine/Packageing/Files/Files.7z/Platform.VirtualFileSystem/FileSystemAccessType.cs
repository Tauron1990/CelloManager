using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[Flags]
[PublicAPI]
public enum FileSystemAccessType
{
    Allow,
    Deny
}