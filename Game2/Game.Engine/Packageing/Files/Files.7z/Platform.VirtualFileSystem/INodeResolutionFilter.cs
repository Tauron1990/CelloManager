namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public interface INodeResolutionFilter
{
    INode Filter(ref INodeResolver resolver, ref INodeAddress address, ref NodeType nodeType, out bool canCache);
}