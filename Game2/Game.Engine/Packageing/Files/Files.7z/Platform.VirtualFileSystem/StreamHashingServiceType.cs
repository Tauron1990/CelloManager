using JetBrains.Annotations;
// ReSharper disable VirtualMemberCallInConstructor

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

 [PublicAPI]
public class StreamHashingServiceType : HashingServiceType
{
    public StreamHashingServiceType(Stream stream)
        : this(stream, "md5") =>
        Stream = stream;

    public StreamHashingServiceType(Stream stream, string algorithmName)
        : base(typeof(IStreamHashingService), algorithmName) =>
        Stream = stream;

    public virtual Stream Stream { get; set; }
}