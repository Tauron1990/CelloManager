using JetBrains.Annotations;
// ReSharper disable VirtualMemberCallInConstructor

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class NodeNotFoundException
    : IOException
{
    public NodeNotFoundException(string? uri)
        : this(null, null)
    {
        Uri = uri;
    }

    public NodeNotFoundException()
        : this(null, null)
    {
    }

    public NodeNotFoundException(INodeAddress? nodeAddress, NodeType? nodeType = null)
        : this(nodeAddress, nodeType, null)
    {
    }

    public NodeNotFoundException(INodeAddress? nodeAddress, NodeType? nodeType, Exception? innerException)
        : base(nodeAddress != null ? "VirtualFileSystem item not found: " + nodeAddress : "", innerException)
    {
        NodeType = nodeType;
        NodeAddress = nodeAddress;

        if (NodeAddress != null) Uri = NodeAddress.Uri;
    }

    public virtual INodeAddress? NodeAddress { get; set; }

    public virtual NodeType? NodeType { get; set; }

    public virtual string? Uri { get; set; }

    public override string ToString() 
        => "NodeNotFound: " + Uri + Environment.NewLine + base.ToString();
}