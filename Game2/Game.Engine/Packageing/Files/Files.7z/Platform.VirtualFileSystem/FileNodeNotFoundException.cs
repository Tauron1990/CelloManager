namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public class FileNodeNotFoundException : NodeNotFoundException
{
    public FileNodeNotFoundException()
        : this(default(INodeAddress))
    {
    }

    public FileNodeNotFoundException(INodeAddress? nodeAddress)
        : base(nodeAddress, NodeType.Directory, null)
    {
    }

    public FileNodeNotFoundException(string uri)
        : base(uri)
    {
    }
}