using Game.Engine.Threading;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public interface INodeTaskService : INodeService, ITaskService, ITask
{
}