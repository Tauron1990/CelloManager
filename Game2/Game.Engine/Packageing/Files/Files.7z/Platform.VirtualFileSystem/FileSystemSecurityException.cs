// ReSharper disable VirtualMemberCallInConstructor

using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class FileSystemSecurityException : IOException
{
    public FileSystemSecurityException(INodeAddress address)
    {
        NodeAddress = address;
    }

    public virtual INodeAddress NodeAddress { get; set; }
}