namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public class DirectoryNodeNotFoundException : NodeNotFoundException
{
    public DirectoryNodeNotFoundException(INodeAddress nodeAddress)
        : base(nodeAddress, NodeType.Directory, null)
    {
    }
}