using JetBrains.Annotations;
// ReSharper disable VirtualMemberCallInConstructor

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class FileSystemExtenders
{
    private readonly IFileSystem _fileSystem;

    public FileSystemExtenders(IFileSystem fileSystem)
    {
        NodeServiceProviders = new List<INodeServiceProvider>();
        NodeTransformationFilters = new List<INodeTransformationFilter>();
        NodeResolutionFilters = new List<INodeResolutionFilter>();
        NodeOperationFilters = new List<INodeOperationFilter>();
        _fileSystem = fileSystem;

        CreateExtenders();

        CompositeNodeOperationFilter = new CompositeNodeOperationFilterImpl(this);
    }

    /// <summary>
    ///     A list of the <see cref="NodeResolutionFilters" /> used by the file system.
    /// </summary>
    public virtual IList<INodeResolutionFilter> NodeResolutionFilters { get; set; }

    /// <summary>
    ///     A list of the <see cref="NodeTransformationFilters" /> used by the file system.
    /// </summary>
    public virtual IList<INodeTransformationFilter> NodeTransformationFilters { get; set; }

    /// <summary>
    ///     A list of the <see cref="NodeServiceProviders" /> used by the file system.
    /// </summary>
    public virtual IList<INodeServiceProvider> NodeServiceProviders { get; set; }

    /// <summary>
    ///     NodeOperationFilters
    /// </summary>
    public virtual IList<INodeOperationFilter> NodeOperationFilters { get; set; }

    public INodeOperationFilter CompositeNodeOperationFilter { get; }

    public virtual object? ConstructExtender(Type type)
    {
        try
        {
            return Activator.CreateInstance(type, _fileSystem);
        }
        catch (MissingMethodException)
        {
        }
        catch (Exception e)
        {
            Console.Error.WriteLine(e);
        }

        return Activator.CreateInstance(type);
    }

    protected virtual void CreateExtenders()
    {
        // Construct NodeServiceProviders

        var types = _fileSystem.Options.NodeServiceProviderTypes;

        NodeServiceProviders = new INodeServiceProvider[types.Count];

        for (var i = 0; i < types.Count; i++)
        {
            if(ConstructExtender(types[i]) is INodeServiceProvider provider)
                NodeServiceProviders[i] = provider;
        }

        // Construct resolution filters

        types = _fileSystem.Options.NodeResolutionFilterTypes;

        NodeResolutionFilters = new INodeResolutionFilter[types.Count];

        for (var i = 0; i < types.Count; i++)
        {
            if (ConstructExtender(types[i]) is INodeResolutionFilter provider)
                NodeResolutionFilters[i] = provider;
        }

        // Construct operation filters

        var typeList = _fileSystem.Options.NodeOperationFilterTypes;

        NodeOperationFilters = new List<INodeOperationFilter>(typeList.Count);

        foreach (var type in typeList)
        {
            if (ConstructExtender(type) is INodeOperationFilter provider)
                NodeOperationFilters.Add(provider);
        }
    }

    private class CompositeNodeOperationFilterImpl : INodeOperationFilter
    {
        private readonly FileSystemExtenders _systemExtenders;

        public CompositeNodeOperationFilterImpl(FileSystemExtenders extenders) => _systemExtenders = extenders;

        #region INodeOperationFilter Members

        public INode? CopyTo(INode thisNode, INode target, bool overwrite, out bool operationPerformed, Func<INode, bool, INode> defaultOperator)
        {
            INode? retval = null;
            operationPerformed = false;

            foreach (INodeOperationFilter filter in _systemExtenders.NodeOperationFilters)
                retval = filter.CopyTo(thisNode, target, overwrite, out operationPerformed, defaultOperator);

            if (!operationPerformed)
            {
                operationPerformed = true;

                return defaultOperator(target, overwrite);
            }

            return retval;
        }

        public INode? MoveTo(INode thisNode, INode target, bool overwrite, out bool operationPerformed, Func<INode, bool, INode> defaultOperator)
        {
            INode? retval = null;
            operationPerformed = false;

            foreach (INodeOperationFilter filter in _systemExtenders.NodeOperationFilters)
                retval = filter.MoveTo(thisNode, target, overwrite, out operationPerformed, defaultOperator);

            if (!operationPerformed)
            {
                operationPerformed = true;

                return defaultOperator(target, overwrite);
            }

            return retval;
        }

        public INode? Create(INode thisNode, bool createParent, out bool operationPerformed, Func<bool, INode> defaultOperator)
        {
            INode? retval = null;
            operationPerformed = false;
            
            foreach (INodeOperationFilter filter in _systemExtenders.NodeOperationFilters)
                retval = filter.Create(thisNode, createParent, out operationPerformed, defaultOperator);

            if (!operationPerformed)
            {
                operationPerformed = true;

                return defaultOperator(createParent);
            }

            return retval;
        }

        public INode? Delete(INode thisNode, out bool operationPerformed, Func<INode> defaultOperator)
        {
            INode? retval = null;
            operationPerformed = false;
            
            foreach (INodeOperationFilter filter in _systemExtenders.NodeOperationFilters)
                retval = filter.Delete(thisNode, out operationPerformed, defaultOperator);

            if (!operationPerformed)
            {
                operationPerformed = true;

                return defaultOperator();
            }

            return retval;
        }

        public INode? RenameTo(INode thisNode, string name, bool overwrite, out bool operationPerformed, Func<string, bool, INode> defaultOperator)
        {
            INode? retval = null;
            operationPerformed = false;

            foreach (INodeOperationFilter filter in _systemExtenders.NodeOperationFilters)
                retval = filter.RenameTo(thisNode, name, overwrite, out operationPerformed, defaultOperator);

            if (!operationPerformed)
            {
                operationPerformed = true;

                return defaultOperator(name, overwrite);
            }

            return retval;
        }

        #endregion
    }
}