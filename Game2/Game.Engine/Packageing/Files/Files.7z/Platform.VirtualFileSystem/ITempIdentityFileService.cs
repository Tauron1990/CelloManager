using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public interface ITempIdentityFileService : IService
{
    IFile GetTempFile();
    IFile GetOriginalFile();
}