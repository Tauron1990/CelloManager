using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class TooManyLinksException : IOException
{
    public TooManyLinksException()
    {
    }

    public TooManyLinksException(IFile linkfile, IFile target)
    {
    }
}