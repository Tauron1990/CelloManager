using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

/// <summary>
///     Summary description for AbstractService.
/// </summary>
[PublicAPI]
public abstract class AbstractService
{
    protected INode ServiceRoot;

    protected AbstractService(INode serviceRoot)
    {
        ServiceRoot = serviceRoot;
    }

    /// <summary>
    ///     Property Name (string)
    /// </summary>
    public string Name { get; set; } = string.Empty;
}