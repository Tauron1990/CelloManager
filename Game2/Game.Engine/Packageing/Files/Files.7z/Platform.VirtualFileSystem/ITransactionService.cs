using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public interface ITransactionService : IService
{
    void Commit();
    void Rollback();
}