using System.Collections;
using System.Collections.Specialized;
using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public class AttributeChangeDeterminer
{
    private readonly string[] _attributeNames;
    private readonly IDictionary _attributes;
    private readonly INode _node;

    public AttributeChangeDeterminer(INode node, params string[] attributeNames)
    {
        _node = node;

        _attributeNames = attributeNames;
        _attributes = CollectionsUtil.CreateCaseInsensitiveHashtable();

        // ReSharper disable once VirtualMemberCallInConstructor
        MakeUnchanged();
    }

    public virtual bool IsUnchanged() => IsUnchanged(_attributeNames);

    public virtual bool IsUnchanged(params string[] attributeNames)
    {
        _node.Refresh();

        return attributeNames.All(name => _node.Attributes[name].Equals(_attributes[name]));
    }

    public virtual void MakeUnchanged() => MakeUnchanged(_attributeNames);

    public virtual void MakeUnchanged(params string[] attributeNames)
    {
        foreach (var name in attributeNames) _attributes[name] = _node.Attributes[name];
    }
}