// ReSharper disable VirtualMemberCallInConstructor

using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public delegate void NodeActivityEventHandler(object sender, NodeActivityEventArgs eventArgs);

[PublicAPI]
public class NodeActivityEventArgs : EventArgs
{
    public NodeActivityEventArgs(FileSystemActivity activity, INode node, string? name = null)
    {
        Node = node;

        OriginalName = Node.Address.Name;

        CurrentName = name ?? node.Name;

        Activity = activity;
    }

    public virtual INode Node { get; set; }

    public FileSystemActivity Activity { get; }

    /// <summary>
    ///     Gets the name of the node.
    /// </summary>
    /// <remarks>
    ///     This property returns the current name of the node.  If the node has been renamed
    ///     then this property reflects the new name of the node.  To get the object representing
    ///     the renamed node, the node should be resolved with the new name.
    /// </remarks>
    public string CurrentName { get; set; }

    /// <summary>
    ///     OriginalName
    /// </summary>
    public string OriginalName { get; set; }

    /// <summary>
    ///     Resolves the node.
    /// </summary>
    /// <remarks>
    ///     If this node has been renamed then this method will return the new node representing
    ///     the renamed node otherwise this method will return the current node.
    /// </remarks>
    public virtual INode Resolve() => Node.ParentDirectory.Resolve(CurrentName);

    public override string ToString()
    {
        return $"{Activity} {Node.Address.AbsolutePath}";
    }
}