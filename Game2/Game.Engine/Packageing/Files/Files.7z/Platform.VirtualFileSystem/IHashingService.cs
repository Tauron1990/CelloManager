namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

public interface IHashingService : INodeService
{
    byte[] ComputeHash();
    byte[] ComputeHash(long offset, long length);
}