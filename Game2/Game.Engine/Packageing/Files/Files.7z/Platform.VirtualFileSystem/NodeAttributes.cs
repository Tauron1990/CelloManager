using JetBrains.Annotations;
using Platform;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

 [PublicAPI]
public static class NodeAttributes
{
    public const string CreationTime = "CreationTime";
    public const string LastAccessTime = "LastAccessTime";
    public const string LastWriteTime = "LastWriteTime";
    public const string Exists = "Exists";

    public static void Copy(INodeAttributes source, INodeAttributes destination)
    {
        foreach (var attributePair in source) destination[attributePair.Key] = attributePair.Value;
    }
}