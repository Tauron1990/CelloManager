using JetBrains.Annotations;

namespace Game.Engine.Packageing.Files.Platform.VirtualFileSystem;

[PublicAPI]
public readonly struct AccessVerificationContext
{
    public INode Node { get; }
    public FileSystemSecuredOperation Operation { get; }

    public AccessVerificationContext(INode node, FileSystemSecuredOperation operation)
        : this()
    {
        Node = node;
        Operation = operation;
    }
}