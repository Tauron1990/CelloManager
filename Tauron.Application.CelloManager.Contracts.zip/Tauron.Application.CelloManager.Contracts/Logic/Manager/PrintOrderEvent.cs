﻿
namespace Tauron.Application.CelloManager.Logic.Manager
{
    public sealed class PrintOrderEvent : SharedEvent<PrintOrderEventArgs>
    {
    }
}