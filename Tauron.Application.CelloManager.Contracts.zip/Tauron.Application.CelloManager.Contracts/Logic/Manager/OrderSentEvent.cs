﻿using Tauron.Application.CelloManager.Data.Historie;

namespace Tauron.Application.CelloManager.Logic.Manager
{
    public sealed class OrderSentEvent : SharedEvent<CommittedRefill>
    {
    }
}