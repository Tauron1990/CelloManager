﻿namespace Tauron.Application.CelloManager
{
    public static class AppConststands
    {
        public const string MainWindowName = "MainWindow";
        public const string ManagerEnviromentPolicy = "ManagerEnviromentPolicy";

        public const string OptionsWindow = "Options";
        public const string SpoolDataEditingView = "SpoolDataEditing";
        public const string UpdateView = "AutoUpdateOptions";

        public const string SpoolView = "SpoolView";
        public const string SpoolViewWorkspaceViewModel = "SpoolViewWorkspaceViewModel";
        //public const string SingleUISpoolViwName = "SingleUISpoolView";
    }
}