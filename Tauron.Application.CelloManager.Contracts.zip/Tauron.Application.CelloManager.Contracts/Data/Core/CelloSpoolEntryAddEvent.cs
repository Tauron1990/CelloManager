﻿using Tauron.Application.CelloManager.Logic.Manager;

namespace Tauron.Application.CelloManager.Data.Core
{
    public sealed class CelloSpoolEntryAddEvent : SharedEvent<CelloSpoolBase>
    {
    }
}