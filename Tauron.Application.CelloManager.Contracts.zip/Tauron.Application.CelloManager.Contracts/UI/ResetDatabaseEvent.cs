﻿using System;

namespace Tauron.Application.CelloManager.UI
{
    public sealed class ResetDatabaseEvent : SharedEvent<EventArgs>
    {
    }
}